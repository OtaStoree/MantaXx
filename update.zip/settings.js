module.exports = {
  OWNER_URL: "https://t.me/", // Link Telegram kamu
  owner: "",     // ID Telegram kamu (angka)
  domain: "",    // Domain/link bot (opsional)
  plta: "",      // Nomor PLT A (opsional)
  pltc: "",      // Nomor PLT C (opsional)
  qris: "",      // Link/gambar QRIS (opsional)
  dana: "",      // Nomor Dana (opsional)
  gopay: "",     // Nomor GoPay (opsional)
  ovo: "",       // Nomor OVO (opsional)
};
