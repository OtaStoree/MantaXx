module.exports = {
  BOT_TOKEN: "...",   // Token bot Telegram kamu
  OWNER_ID: ["7045639623"],  // ID Telegram kamu (angka)
  OWN: "Zeppeliorg", // Username Telegram kamu (tanpa @)
};
