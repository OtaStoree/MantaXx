module.exports = {
  BOT_TOKEN: "",   // Token bot Telegram kamu
  OWNER_ID: [""],  // ID Telegram kamu (angka)
  OWN: "",         // Username Telegram kamu (tanpa @)
};
